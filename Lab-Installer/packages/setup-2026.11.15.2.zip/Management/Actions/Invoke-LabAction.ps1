﻿#Requires -RunAsAdministrator
[CmdletBinding()]
param(
 [Parameter(Mandatory)][ValidateSet('class','class-ai','exam','free','cleanup','status','uwf-status','uwf-enable','uwf-disable','uwf-purge-swap','uwf-repair','uwf-reset-stage1','uwf-reset-stage2','windows-update')][string]$Action,
 [switch]$PolicyOnly
)
$ErrorActionPreference='Stop'
if($env:COMPUTERNAME -notmatch '^(?:UEPLV-|LEV-VIGOTSKY-)(0[1-9]|[12][0-9]|3[0-3])$'){throw 'This action helper is only for enrolled UEPLV lab computers.'}
$result=[ordered]@{success=$false;detail=$null;restartRequired=$false;resetPhase=$null;needsUpdateCheck=$false}
$script:CleanupSkippedLinks=[Collections.Generic.List[string]]::new()
$script:CleanupSkippedBusy=[Collections.Generic.List[string]]::new()
$stateRoot=Join-Path $env:ProgramData 'UEPLV\Management'
$reportRoot=Join-Path $env:ProgramData 'UEPLV\Reports'
[IO.Directory]::CreateDirectory($reportRoot)|Out-Null
function Run-Native([string]$File,[string[]]$Arguments,[int[]]$Allowed=@(0)){
 $log=Join-Path $reportRoot ('action-'+$Action+'.log')
 $old=$ErrorActionPreference;try{$ErrorActionPreference='Continue';& $File @Arguments 2>&1|Out-File -LiteralPath $log -Append -Encoding UTF8;$code=$LASTEXITCODE}finally{$ErrorActionPreference=$old}
 if($code -notin $Allowed){throw ([IO.Path]::GetFileName($File)+' returned '+$code+'; see action report.')};return [int]$code
}
function Uwf-State {
 $f=Get-CimInstance -Namespace 'root\standardcimv2\embedded' -ClassName UWF_Filter -ErrorAction Stop
 $v=@(Get-CimInstance -Namespace 'root\standardcimv2\embedded' -ClassName UWF_Volume|Where-Object DriveLetter -eq 'C:')
 $s=@(Get-CimInstance -Namespace 'root\standardcimv2\embedded' -ClassName UWF_Servicing)
 [pscustomobject]@{current=[bool]$f.CurrentEnabled;next=[bool]$f.NextEnabled;currentC=[bool]($v|Where-Object CurrentSession|Select-Object -ExpandProperty Protected);nextC=[bool]($v|Where-Object {-not $_.CurrentSession}|Select-Object -ExpandProperty Protected);servicing=[bool]@($s|Where-Object ServicingEnabled).Count}
}
function Require-Unprotected {
 $f=Get-WindowsOptionalFeature -Online -FeatureName Client-UnifiedWriteFilter
 if($f.State -eq 'DisablePending' -or $f.State -eq 'EnablePending'){throw 'A UWF feature restart is pending. Restart before this action.'}
 if($f.State -eq 'Enabled'){$s=Uwf-State;if($s.current -or $s.next -or $s.servicing){throw 'This action requires UWF disabled now and for the next boot, with servicing off.'}}
}
function Get-Student {
 $account=Get-LocalUser -Name 'LEV VIGOTSKY' -ErrorAction Stop
 $p=Get-CimInstance Win32_UserProfile|Where-Object SID -eq $account.SID.Value|Select-Object -First 1
 if(-not $p){throw 'Student profile has not been created yet. Sign in to LEV VIGOTSKY first.'}
 $root=[IO.Path]::GetFullPath($p.LocalPath).TrimEnd('\')
 if(-not $root.StartsWith(($env:SystemDrive+'\Users\'),[StringComparison]::OrdinalIgnoreCase) -or ($p.Special) -or ((Get-Item -LiteralPath $root -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Student profile is not an ordinary local user directory.'}
 [pscustomobject]@{Root=$root;Sid=$account.SID.Value}
}
function Ensure-CleanupNative {
 if('UEPLV.CheckedDelete' -as [type]){return}
 Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Text;
using System.ComponentModel;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
namespace UEPLV {
 public static class CheckedDelete {
  [StructLayout(LayoutKind.Sequential)]struct TagInfo{public uint Attributes;public uint Tag;}
  [StructLayout(LayoutKind.Sequential)]struct Disposition{[MarshalAs(UnmanagedType.U1)]public bool Delete;}
  [StructLayout(LayoutKind.Sequential)]struct BasicInfo{public long Created,Accessed,Written,Changed;public uint Attributes;}
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern SafeFileHandle CreateFile(string p,uint access,uint share,IntPtr security,uint creation,uint flags,IntPtr template);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern uint GetFinalPathNameByHandle(SafeFileHandle h,StringBuilder p,uint length,uint flags);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetFileInformationByHandleEx(SafeFileHandle h,int kind,out TagInfo info,uint size);
  [DllImport("kernel32.dll",EntryPoint="SetFileInformationByHandle",SetLastError=true)]static extern bool SetDisposition(SafeFileHandle h,int kind,ref Disposition info,uint size);
  [DllImport("kernel32.dll",EntryPoint="SetFileInformationByHandle",SetLastError=true)]static extern bool SetBasic(SafeFileHandle h,int kind,ref BasicInfo info,uint size);
  static void Check(SafeFileHandle h,string root,bool allowRoot){if(h.IsInvalid)throw new Win32Exception(Marshal.GetLastWin32Error(),"Cannot acquire safe cleanup handle");var path=new StringBuilder(32768);uint n=GetFinalPathNameByHandle(h,path,(uint)path.Capacity,0);if(n==0||n>=path.Capacity)throw new Win32Exception(Marshal.GetLastWin32Error(),"Cannot resolve cleanup handle");string resolved=path.ToString();if(resolved.StartsWith(@"\\?\"))resolved=resolved.Substring(4);string expected=Path.GetFullPath(root).TrimEnd('\\');if(!(resolved.StartsWith(expected+"\\",StringComparison.OrdinalIgnoreCase)||(allowRoot&&resolved.Equals(expected,StringComparison.OrdinalIgnoreCase))))throw new IOException("Resolved cleanup handle escaped the approved student root");TagInfo info;if(!GetFileInformationByHandleEx(h,9,out info,8))throw new Win32Exception(Marshal.GetLastWin32Error());if((info.Attributes&0x400)!=0)throw new IOException("Cleanup refused a reparse point");}
  public static SafeFileHandle LockDirectory(string path,string root){var h=CreateFile(path,0x81,1,IntPtr.Zero,3,0x02200000,IntPtr.Zero);try{Check(h,root,true);return h;}catch{h.Dispose();throw;}}
  public static void Delete(string path,string root,bool directory){using(var h=CreateFile(path,0x10180,7,IntPtr.Zero,3,0x02200000,IntPtr.Zero)){if(h.IsInvalid)throw new Win32Exception(Marshal.GetLastWin32Error(),"Cannot open cleanup item: "+path);Check(h,root,false);if(!directory){var basic=new BasicInfo{Attributes=0x80};if(!SetBasic(h,0,ref basic,(uint)Marshal.SizeOf(typeof(BasicInfo))))throw new Win32Exception(Marshal.GetLastWin32Error());}var d=new Disposition{Delete=true};if(!SetDisposition(h,4,ref d,(uint)Marshal.SizeOf(typeof(Disposition))))throw new Win32Exception(Marshal.GetLastWin32Error(),"Cleanup could not delete the checked item");}}
 }
}
'@
}
function Get-CleanupLease([string]$Path,[string]$AllowedRoot){
 Ensure-CleanupNative
 $full=[IO.Path]::GetFullPath($Path).TrimEnd('\');$root=[IO.Path]::GetFullPath($AllowedRoot).TrimEnd('\')
 if($full -ne $root -and -not $full.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Cleanup path escaped the approved student root.'}
 $handles=[Collections.Generic.List[object]]::new()
 try{
  $current=$root;$handles.Add([UEPLV.CheckedDelete]::LockDirectory($current,$root))
  if($full.Length -gt $root.Length){foreach($segment in $full.Substring($root.Length+1).Split('\')){$current=Join-Path $current $segment;$handles.Add([UEPLV.CheckedDelete]::LockDirectory($current,$root))}}
  return ,$handles
 }catch{foreach($h in $handles){$h.Dispose()};throw}
}
function Close-CleanupLease($Lease){if($Lease){foreach($h in $Lease){$h.Dispose()}}}
function Invoke-CheckedCleanupDelete([string]$Path,[string]$Root,[bool]$Directory){
 try{[UEPLV.CheckedDelete]::Delete($Path,$Root,$Directory)}catch{
  $cause=$_.Exception.GetBaseException()
  if($Path -match '\\AppData\\(Local|Roaming)\\' -and $cause -is [ComponentModel.Win32Exception] -and $cause.NativeErrorCode -in @(5,32,33)){
   $script:CleanupSkippedBusy.Add($Path)
  }else{throw}
 }
}
function Clear-CheckedDirectory([string]$Path,[string]$AllowedRoot){
 $full=[IO.Path]::GetFullPath($Path).TrimEnd('\');$allowed=[IO.Path]::GetFullPath($AllowedRoot).TrimEnd('\')
 if(-not $full.StartsWith($allowed+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Cleanup path escaped the approved student area.'}
 if(-not(Test-Path -LiteralPath $full)){return}
 if((Get-Item -LiteralPath $full -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){$script:CleanupSkippedLinks.Add($full);return}
 $lease=Get-CleanupLease $full $AllowedRoot;$directoryHandles=@{}
 try{
  $stack=[Collections.Generic.Stack[string]]::new();$stack.Push($full);$items=[Collections.Generic.List[object]]::new()
  while($stack.Count){$dir=$stack.Pop();foreach($item in Get-ChildItem -LiteralPath $dir -Force){if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){$script:CleanupSkippedLinks.Add($item.FullName);continue};$items.Add($item);if($item.PSIsContainer){$directoryHandles[$item.FullName]=[UEPLV.CheckedDelete]::LockDirectory($item.FullName,$AllowedRoot);$stack.Push($item.FullName)}}}
  foreach($item in @($items|Sort-Object @{Expression={$_.FullName.Length};Descending=$true})){
   if($item.PSIsContainer){$directoryHandles[$item.FullName].Dispose();$directoryHandles.Remove($item.FullName)}
   if($item.PSIsContainer -and @($script:CleanupSkippedLinks|Where-Object {$_.StartsWith($item.FullName+'\',[StringComparison]::OrdinalIgnoreCase)}).Count){continue}
   if($item.PSIsContainer -and @($script:CleanupSkippedBusy|Where-Object {$_.StartsWith($item.FullName+'\',[StringComparison]::OrdinalIgnoreCase)}).Count){continue}
   Invoke-CheckedCleanupDelete $item.FullName $AllowedRoot ([bool]$item.PSIsContainer)
  }
 }finally{foreach($h in $directoryHandles.Values){$h.Dispose()};Close-CleanupLease $lease}
}
function Delete-CheckedFile([string]$Path,[string]$Root){
 $full=[IO.Path]::GetFullPath($Path);$base=[IO.Path]::GetFullPath($Root).TrimEnd('\')
 if(-not $full.StartsWith($base+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Browser cleanup path escaped student profile.'}
 if(Test-Path -LiteralPath $full){$lease=Get-CleanupLease ([IO.Path]::GetDirectoryName($full)) $Root;try{Invoke-CheckedCleanupDelete $full $Root $false}finally{Close-CleanupLease $lease}}
}
$classGames='friv.com voxiom.io shellshock.io poki.com roblox.com veck.io msn.com games.msn.com zone.msn.com disneyplus.com twitch.tv steamcommunity.com steampowered.com epicgames.com blizzboygames.net krunker.io paper-io.com slither.io agar.io hole-io.com crazygames.com minijuegos.com poki.es badtimesimulator.io jcw87.github.io doodles.google'.Split(' ')
$classSocial='facebook.com instagram.com tiktok.com youtube.com twitter.com x.com snapchat.com kwai.com'.Split(' ')
$classAdult='pornhub.com xnxx.com xvideos.com stripchat.com chaturbate.com xhamster.com youporn.com redtube.com spankbang.com tnaflix.com beeg.com cam4.com bongacams.com rule34.xxx e621.net'.Split(' ')
$ai='chat.openai.com chatgpt.com openai.com gemini.google.com bard.google.com copilot.microsoft.com claude.ai poe.com perplexity.ai you.com meta.ai'.Split(' ')
$examWeb='google.com bing.com yahoo.com duckduckgo.com ask.com baidu.com yandex.com brave.com search.brave.com youtube.com facebook.com instagram.com tiktok.com x.com twitter.com whatsapp.com web.whatsapp.com discord.com netflix.com disneyplus.com twitch.tv reddit.com'.Split(' ')
$patterns=@('*://jcw87.github.io/c2-sans-fight/*','*://badtimesimulator.io/*','*://*.badtimesimulator.io/*','*://www.google.com/logos/*','*://google.com/logos/*','*://www.google.com/doodles/*','*://google.com/doodles/*','*://doodles.google/*','*://*.doodles.google/*')
function Set-OwnedRegistryValue([string]$Path,[string]$Name,$Value,[string]$Kind='DWord'){
 $backupPath=Join-Path $stateRoot 'mode-registry-before.json'
 $backup=@();if(Test-Path -LiteralPath $backupPath){$parsed=Get-Content -LiteralPath $backupPath -Raw|ConvertFrom-Json;$backup=@($parsed)}
 if(-not @($backup|Where-Object {$_.path -eq $Path -and $_.name -eq $Name}).Count){$exists=$false;$old=$null;$oldKind=$null;if(Test-Path -LiteralPath $Path){$key=Get-Item -LiteralPath $Path;try{if($key.GetValueNames() -contains $Name){$exists=$true;$old=$key.GetValue($Name);$oldKind=$key.GetValueKind($Name).ToString()}}finally{$key.Close()}};$backup+=@{path=$Path;name=$Name;exists=$exists;value=$old;kind=$oldKind};[IO.File]::WriteAllText($backupPath,(ConvertTo-Json -InputObject @($backup) -Depth 6),[Text.UTF8Encoding]::new($false))}
 if(-not(Test-Path -LiteralPath $Path)){New-Item -Path $Path -Force|Out-Null};New-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -PropertyType $Kind -Force|Out-Null
}
function Restore-OwnedRegistryValue([string]$Path,[string]$Name){
 $backupPath=Join-Path $stateRoot 'mode-registry-before.json';if(-not(Test-Path -LiteralPath $backupPath)){return}
 $records=Get-Content -LiteralPath $backupPath -Raw|ConvertFrom-Json
 $record=$records|Where-Object {$_.path -eq $Path -and $_.name -eq $Name}|Select-Object -First 1
 if(-not $record){return};if($record.exists){if(-not(Test-Path -LiteralPath $Path)){New-Item -Path $Path -Force|Out-Null};New-ItemProperty -LiteralPath $Path -Name $Name -Value $record.value -PropertyType $record.kind -Force|Out-Null}else{Remove-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction SilentlyContinue}
}
function Sync-InstalledUserSettings {
 # Delivered inside the signed action-module update; never read executable code from cloud settings.
 $target=Join-Path $env:ProgramFiles 'UEPLV\Provisioning\Apply-UserSettings.ps1'
 if(-not(Test-Path -LiteralPath (Split-Path $target))){throw 'Installed classroom provisioning folder is missing.'}
 $expected='639D473A68560F884F45A0E289DD8ECBAB7A7CC1E1FC4B62B1275FC53C9E5957'
 if((Test-Path -LiteralPath $target) -and (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -eq $expected){return}
 if([IO.File]::Exists($target)){[IO.File]::SetAttributes($target,([IO.File]::GetAttributes($target) -band (-bnot [IO.FileAttributes]::ReadOnly)))}
 [IO.File]::WriteAllBytes($target,[Convert]::FromBase64String('77u/IyBSdW5zIGluIHRoZSBzaWduZWQtaW4gdXNlcidzIGNvbnRleHQ7IG5vIGFkbWluaXN0cmF0b3IgcmlnaHRzIGFyZSByZXF1aXJlZCBvciByZXF1ZXN0ZWQuDQojIENvcGllZCB0byBQcm9ncmFtIEZpbGVzIGJ5IEFwcGx5LUxhYlNldHRpbmdzLnBzMSBhbmQgaW5oZXJpdGVkIHZpYSBEZWZhdWx0IHVzZXIgUnVuIHZhbHVlLg0KcGFyYW0oW3N0cmluZ10kV2FsbHBhcGVyID0gKEpvaW4tUGF0aCAkZW52OlByb2dyYW1GaWxlcyAnVUVQTFZcUHJvdmlzaW9uaW5nXFdhbGxwYXBlci5wbmcnKSkNCiRFcnJvckFjdGlvblByZWZlcmVuY2UgPSAnU3RvcCcNCiRuYW1lID0gW1NlY3VyaXR5LlByaW5jaXBhbC5XaW5kb3dzSWRlbnRpdHldOjpHZXRDdXJyZW50KCkuTmFtZS5TcGxpdCgnXCcpWy0xXQ0KaWYgKCRuYW1lIC1ub3RpbiBAKCdNQUlOVEVOQU5DRScsJ0xFViBWSUdPVFNLWScpKSB7IGV4aXQgMCB9DQokbG9nUm9vdD1Kb2luLVBhdGggJGVudjpMT0NBTEFQUERBVEEgJ1VFUExWJw0KW0lPLkRpcmVjdG9yeV06OkNyZWF0ZURpcmVjdG9yeSgkbG9nUm9vdCl8T3V0LU51bGwNClN0YXJ0LVRyYW5zY3JpcHQgLVBhdGggKEpvaW4tUGF0aCAkbG9nUm9vdCAndXNlci1zZXR0aW5ncy5sb2cnKSAtQXBwZW5kIC1Gb3JjZXxPdXQtTnVsbA0KdHJ5IHsNCmZ1bmN0aW9uIFNldC1Vc2VyVmFsdWUoW3N0cmluZ10kUGF0aCxbc3RyaW5nXSROYW1lLCRWYWx1ZSxbc3RyaW5nXSRUeXBlPSdEV29yZCcpIHsNCiAgICBpZiAoLW5vdCAoVGVzdC1QYXRoIC1MaXRlcmFsUGF0aCAkUGF0aCkpIHsgTmV3LUl0ZW0gLVBhdGggJFBhdGggLUZvcmNlIHwgT3V0LU51bGwgfQ0KICAgIE5ldy1JdGVtUHJvcGVydHkgLUxpdGVyYWxQYXRoICRQYXRoIC1OYW1lICROYW1lIC1WYWx1ZSAkVmFsdWUgLVByb3BlcnR5VHlwZSAkVHlwZSAtRm9yY2UgfCBPdXQtTnVsbA0KfQ0KU2V0LVVzZXJWYWx1ZSAnSEtDVTpcU29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cVGhlbWVzXFBlcnNvbmFsaXplJyAnQXBwc1VzZUxpZ2h0VGhlbWUnIDANClNldC1Vc2VyVmFsdWUgJ0hLQ1U6XFNvZnR3YXJlXE1pY3Jvc29mdFxXaW5kb3dzXEN1cnJlbnRWZXJzaW9uXFNlYXJjaCcgJ1NlYXJjaGJveFRhc2tiYXJNb2RlJyAyDQpTZXQtVXNlclZhbHVlICdIS0NVOlxTb2Z0d2FyZVxNaWNyb3NvZnRcV2luZG93c1xDdXJyZW50VmVyc2lvblxFeHBsb3JlclxBZHZhbmNlZCcgJ1Nob3dUYXNrVmlld0J1dHRvbicgMA0KZm9yZWFjaCgkcnVuS2V5IGluIEAoJ1J1bicsJ1J1bk9uY2UnKSl7Zm9yZWFjaCgkZW50cnkgaW4gQCgnT25lRHJpdmVTZXR1cCcsJ09uZURyaXZlJykpe1JlbW92ZS1JdGVtUHJvcGVydHkgLUxpdGVyYWxQYXRoICgnSEtDVTpcU29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cJyskcnVuS2V5KSAtTmFtZSAkZW50cnkgLUVycm9yQWN0aW9uIFNpbGVudGx5Q29udGludWV9fQ0KJHBlclVzZXJPbmVEcml2ZT1Kb2luLVBhdGggJGVudjpMT0NBTEFQUERBVEEgJ01pY3Jvc29mdFxPbmVEcml2ZScNCmlmKFRlc3QtUGF0aCAtTGl0ZXJhbFBhdGggJHBlclVzZXJPbmVEcml2ZSl7DQogICAgJHNldHVwPUdldC1DaGlsZEl0ZW0gLUxpdGVyYWxQYXRoICRwZXJVc2VyT25lRHJpdmUgLUZpbHRlciBPbmVEcml2ZVNldHVwLmV4ZSAtRmlsZSAtUmVjdXJzZSAtRXJyb3JBY3Rpb24gU2lsZW50bHlDb250aW51ZXxTZWxlY3QtT2JqZWN0IC1GaXJzdCAxDQogICAgaWYoJHNldHVwKXtTdGFydC1Qcm9jZXNzIC1GaWxlUGF0aCAkc2V0dXAuRnVsbE5hbWUgLUFyZ3VtZW50TGlzdCAnL3VuaW5zdGFsbCcgLVdhaXQgLVdpbmRvd1N0eWxlIEhpZGRlbn0NCn0NClNldC1Vc2VyVmFsdWUgJ0hLQ1U6XFNvZnR3YXJlXE1pY3Jvc29mdFxXaW5kb3dzXEN1cnJlbnRWZXJzaW9uXFRoZW1lc1xQZXJzb25hbGl6ZScgJ1N5c3RlbVVzZXNMaWdodFRoZW1lJyAwDQpTZXQtVXNlclZhbHVlICdIS0NVOlxDb250cm9sIFBhbmVsXERlc2t0b3AnICdXYWxscGFwZXInICRXYWxscGFwZXIgU3RyaW5nDQpTZXQtVXNlclZhbHVlICdIS0NVOlxDb250cm9sIFBhbmVsXERlc2t0b3AnICdXYWxscGFwZXJTdHlsZScgJzEwJyBTdHJpbmcNClNldC1Vc2VyVmFsdWUgJ0hLQ1U6XENvbnRyb2wgUGFuZWxcRGVza3RvcCcgJ1RpbGVXYWxscGFwZXInICcwJyBTdHJpbmcNCmZvcmVhY2ggKCRwYW5lbCBpbiBAKCdOZXdTdGFydFBhbmVsJywnQ2xhc3NpY1N0YXJ0TWVudScpKSB7DQogICAgJGtleSA9ICdIS0NVOlxTb2Z0d2FyZVxNaWNyb3NvZnRcV2luZG93c1xDdXJyZW50VmVyc2lvblxFeHBsb3JlclxIaWRlRGVza3RvcEljb25zXCcgKyAkcGFuZWwNCiAgICBmb3JlYWNoICgkaWQgaW4gQCgnezIwRDA0RkUwLTNBRUEtMTA2OS1BMkQ4LTA4MDAyQjMwMzA5RH0nLCd7NTkwMzFhNDctM2Y3Mi00NGE3LTg5YzUtNTU5NWZlNmIzMGVlfScsJ3tGMDJDMUEwRC1CRTIxLTQzNTAtODhCMC03MzY3RkM5NkVGM0N9JywnezUzOTlFNjk0LTZDRTUtNEQ2Qy04RkNFLTFEODg3MEZEQ0JBMH0nKSkgeyBTZXQtVXNlclZhbHVlICRrZXkgJGlkIDEgfQ0KICAgIFNldC1Vc2VyVmFsdWUgJGtleSAnezY0NUZGMDQwLTUwODEtMTAxQi05RjA4LTAwQUEwMDJGOTU0RX0nIDANCn0NCiMgUmVzdHJpY3RlZCBwb2xpY3kga2V5cyBhcmUgY29uZmlndXJlZCBieSB0aGUgZWxldmF0ZWQgaW5zdGFsbGVyIGJlZm9yZSBmaXJzdCBzaWduLWluLg0KIyBTdGFuZGFyZCB1c2VycyBtdXN0IG5ldmVyIHdyaXRlIHRoZXNlIGtleXM6IGFuIGFjY2VzcyBlcnJvciB3b3VsZCBzdG9wIHRoZSB3YWxscGFwZXIgcmVmcmVzaC4NCiMgTmF0aXZlIHJlZnJlc2ggY2hhbmdlcyBvbmx5IHRoaXMgdXNlcidzIHdhbGxwYXBlciwgbmV2ZXIgYW5vdGhlciBzZXNzaW9uLg0KaWYgKC1ub3QgKCdVRVBMVi5XYWxscGFwZXInIC1hcyBbdHlwZV0pKSB7DQogICAgQWRkLVR5cGUgLVR5cGVEZWZpbml0aW9uICduYW1lc3BhY2UgVUVQTFYgeyBwdWJsaWMgY2xhc3MgV2FsbHBhcGVyIHsgW1N5c3RlbS5SdW50aW1lLkludGVyb3BTZXJ2aWNlcy5EbGxJbXBvcnQoInVzZXIzMi5kbGwiLCBDaGFyU2V0PVN5c3RlbS5SdW50aW1lLkludGVyb3BTZXJ2aWNlcy5DaGFyU2V0LlVuaWNvZGUpXSBwdWJsaWMgc3RhdGljIGV4dGVybiBib29sIFN5c3RlbVBhcmFtZXRlcnNJbmZvKGludCBhY3Rpb24sIGludCBwYXJhbSwgc3RyaW5nIHZhbHVlLCBpbnQgZmxhZ3MpOyB9IH0nDQp9DQppZiAoVGVzdC1QYXRoIC1MaXRlcmFsUGF0aCAkV2FsbHBhcGVyKSB7IFtVRVBMVi5XYWxscGFwZXJdOjpTeXN0ZW1QYXJhbWV0ZXJzSW5mbygyMCwwLCRXYWxscGFwZXIsMykgfCBPdXQtTnVsbCB9DQoNCiMgV2luZG93cyByZXNvbHZlcyB0aGUgb3JpZ2luYWwgdGFza2JhciBwaW4gYmFjayB0byBFZGdlJ3MgZGVmYXVsdCBzaG9ydGN1dC4NCiMgVXBkYXRlIHRoZSBhY3R1YWwgcGVyLXVzZXIgcGluIGFmdGVyIEV4cGxvcmVyIGNyZWF0ZXMgaXQsIHdpdGhvdXQgcmVxdWlyaW5nIGVsZXZhdGlvbi4NCiRwaW5Sb290PUpvaW4tUGF0aCAkZW52OkFQUERBVEEgJ01pY3Jvc29mdFxJbnRlcm5ldCBFeHBsb3JlclxRdWljayBMYXVuY2hcVXNlciBQaW5uZWRcVGFza0JhcicNCiRlZGdlUGlucz1AKCk7JHNoZWxsPU5ldy1PYmplY3QgLUNvbU9iamVjdCBXU2NyaXB0LlNoZWxsDQp0cnkgew0KICAgIGZvcigkYXR0ZW1wdD0wOyRhdHRlbXB0IC1sdCAzMDskYXR0ZW1wdCsrKXsNCiAgICAgICAgJGVkZ2VQaW5zPUAoR2V0LUNoaWxkSXRlbSAtTGl0ZXJhbFBhdGggJHBpblJvb3QgLUZpbHRlciAnKi5sbmsnIC1FcnJvckFjdGlvbiBTaWxlbnRseUNvbnRpbnVlfFdoZXJlLU9iamVjdCB7JHNoZWxsLkNyZWF0ZVNob3J0Y3V0KCRfLkZ1bGxOYW1lKS5UYXJnZXRQYXRoIC1tYXRjaCAnXFxtc2VkZ2VcLmV4ZSQnfSkNCiAgICAgICAgaWYoJGVkZ2VQaW5zLkNvdW50KXticmVha307U3RhcnQtU2xlZXAgLVNlY29uZHMgMQ0KICAgIH0NCiAgICBmb3JlYWNoKCRwaW4gaW4gJGVkZ2VQaW5zKXsNCiAgICAgICAgJGxpbms9JHNoZWxsLkNyZWF0ZVNob3J0Y3V0KCRwaW4uRnVsbE5hbWUpDQogICAgICAgICRsaW5rLkFyZ3VtZW50cz0nLS1uby1maXJzdC1ydW4gLS1uZXctd2luZG93IGh0dHBzOi8vd3d3Lmdvb2dsZS5jb20vJw0KICAgICAgICAkbGluay5JY29uTG9jYXRpb249JGxpbmsuVGFyZ2V0UGF0aCsnLDAnOyRsaW5rLlNhdmUoKQ0KICAgICAgICBpZigkc2hlbGwuQ3JlYXRlU2hvcnRjdXQoJHBpbi5GdWxsTmFtZSkuQXJndW1lbnRzIC1ub3RtYXRjaCAnaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8nKXt0aHJvdyAnUGlubmVkIEVkZ2Ugc3RhcnR1cCBjb3VsZCBub3QgYmUgdmVyaWZpZWQuJ30NCiAgICB9DQp9IGZpbmFsbHkge1tSdW50aW1lLkludGVyb3BTZXJ2aWNlcy5NYXJzaGFsXTo6RmluYWxSZWxlYXNlQ29tT2JqZWN0KCRzaGVsbCl8T3V0LU51bGx9DQoNCltJTy5GaWxlXTo6V3JpdGVBbGxUZXh0KChKb2luLVBhdGggJGxvZ1Jvb3QgJ3VzZXItc2V0dGluZ3MuanNvbicpLChAe1N1Y2Nlc3M9JHRydWU7UGlubmVkRWRnZUdvb2dsZT0oJGVkZ2VQaW5zLkNvdW50IC1ndCAwKTtVc2VyPSRuYW1lO1dhbGxwYXBlcj0kV2FsbHBhcGVyO1V0Yz1bZGF0ZXRpbWVdOjpVdGNOb3cuVG9TdHJpbmcoJ28nKX18Q29udmVydFRvLUpzb24pLFtUZXh0LlVURjhFbmNvZGluZ106Om5ldygkZmFsc2UpKQ0KfSBjYXRjaCB7DQogICAgW0lPLkZpbGVdOjpXcml0ZUFsbFRleHQoKEpvaW4tUGF0aCAkbG9nUm9vdCAndXNlci1zZXR0aW5ncy5qc29uJyksKEB7U3VjY2Vzcz0kZmFsc2U7VXNlcj0kbmFtZTtFcnJvcj0kXy5FeGNlcHRpb24uTWVzc2FnZTtVdGM9W2RhdGV0aW1lXTo6VXRjTm93LlRvU3RyaW5nKCdvJyl9fENvbnZlcnRUby1Kc29uKSxbVGV4dC5VVEY4RW5jb2RpbmddOjpuZXcoJGZhbHNlKSkNCiAgICB0aHJvdw0KfSBmaW5hbGx5IHtTdG9wLVRyYW5zY3JpcHR8T3V0LU51bGx9DQo='))
 if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $expected){throw 'Installed user settings failed integrity verification.'}
}
function Update-OwnedHosts([string[]]$Domains){
 $path=Join-Path $env:windir 'System32\drivers\etc\hosts';$lines=[IO.File]::ReadAllLines($path);$kept=[Collections.Generic.List[string]]::new();$block=$null
 $starts=@('# BEGIN UEPLV_MANAGEMENT','# BEGIN LEV_VIGOTSKY_GUARD','# BEGIN LEV_VIGOTSKY_CLASS_AI_EXTRA','# BEGIN LEV_VIGOTSKY_EXAM_EXTRA')
 foreach($line in $lines){if($starts -contains $line.Trim()){if($block){throw 'Nested managed hosts blocks require staff review.'};$block=$line.Trim().Replace('# BEGIN ','# END ');continue};if($block){if($line.Trim() -eq $block){$block=$null};continue};$kept.Add($line)}
 if($block){throw 'An incomplete managed hosts block requires staff review.'}
 if($Domains.Count){$kept.Add('# BEGIN UEPLV_MANAGEMENT');foreach($domain in $Domains){$kept.Add('0.0.0.0 '+$domain);$kept.Add('0.0.0.0 www.'+$domain)};$kept.Add('# END UEPLV_MANAGEMENT')}
 $attributes=[IO.File]::GetAttributes($path);try{[IO.File]::SetAttributes($path,($attributes -band (-bnot [IO.FileAttributes]::ReadOnly)));[IO.File]::WriteAllLines($path,$kept.ToArray(),[Text.UTF8Encoding]::new($false))}finally{[IO.File]::SetAttributes($path,$attributes)}
}
try {
 if($Action -in @('class','class-ai','exam','free')){
  Sync-InstalledUserSettings
  $student=Get-Student;$hive='Registry::HKEY_USERS\'+$student.Sid;$loaded=$false
  if(-not(Test-Path -LiteralPath $hive)){Run-Native reg.exe @('load',('HKU\'+$student.Sid),(Join-Path $student.Root 'NTUSER.DAT'))|Out-Null;$loaded=$true}
  try {
   $task=$hive+'\Software\Microsoft\Windows\CurrentVersion\Policies\System';$explorer=$hive+'\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer';$deny=$explorer+'\DisallowRun';$msi='HKLM:\Software\Policies\Microsoft\Windows\Installer'
   # Repair the known school appearance values removed by older registry writers.
   # These remain part of the classroom baseline in every browsing mode.
   if(-not(Test-Path -LiteralPath $task)){New-Item -Path $task -Force|Out-Null}
   New-ItemProperty -LiteralPath $task -Name Wallpaper -Value (Join-Path $env:ProgramFiles 'UEPLV\Provisioning\Wallpaper.png') -PropertyType String -Force|Out-Null
   New-ItemProperty -LiteralPath $task -Name WallpaperStyle -Value '10' -PropertyType String -Force|Out-Null
   if($Action -eq 'free'){Restore-OwnedRegistryValue $task DisableTaskMgr;Restore-OwnedRegistryValue $msi DisableMSI;Restore-OwnedRegistryValue $explorer DisallowRun;Restore-OwnedRegistryValue $deny '9001';Restore-OwnedRegistryValue $deny '9002'}else{Set-OwnedRegistryValue $task DisableTaskMgr 1;Set-OwnedRegistryValue $msi DisableMSI 2;Set-OwnedRegistryValue $explorer DisallowRun 1;Set-OwnedRegistryValue $deny '9001' 'RobloxPlayerBeta.exe' String;Set-OwnedRegistryValue $deny '9002' 'RobloxPlayerLauncher.exe' String}
  }finally{if($loaded){[GC]::Collect();[GC]::WaitForPendingFinalizers();Run-Native reg.exe @('unload',('HKU\'+$student.Sid))|Out-Null}}
  $domains=@();if($Action -ne 'free'){$domains=@($classGames+$classSocial+$classAdult);if($Action -in @('class-ai','exam')){$domains+= $ai};if($Action -eq 'exam'){$domains+=$examWeb};$domains=@($domains|Select-Object -Unique)}
  $agentRecord=Get-Content (Join-Path $env:ProgramData 'UEPLV\Management\agent-state.json') -Raw|ConvertFrom-Json
  if($agentRecord.PSObject.Properties['websitePolicy'] -and $agentRecord.websitePolicy -and $Action -ne 'free'){
   $field=if($Action -eq 'exam'){'examDomains'}elseif($Action -eq 'class-ai'){'aiDomains'}else{'classDomains'}
   $domains=@($agentRecord.websitePolicy.$field)
   if($domains.Count -gt 90 -or @($domains|Where-Object {$_ -cnotmatch '^([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$'}).Count){throw 'Invalid managed website policy'}
   $patterns=@()
  }
  Update-OwnedHosts $domains
  foreach($browser in @('HKLM:\SOFTWARE\Policies\Microsoft\Edge\URLBlocklist','HKLM:\SOFTWARE\Policies\Google\Chrome\URLBlocklist')){
   foreach($n in 9001..9099){Restore-OwnedRegistryValue $browser ([string]$n)}
   if($Action -ne 'free'){
    $urls=@($domains+$patterns|Select-Object -Unique);$n=9001
    foreach($url in $urls){if($n -gt 9099){throw 'Managed browser policy range exhausted.'};Set-OwnedRegistryValue $browser ([string]$n) $url String;$n++}
    if($urls.Count){$key=Get-Item -LiteralPath $browser;try{for($i=0;$i -lt $urls.Count;$i++){if($key.GetValue([string](9001+$i)) -cne $urls[$i]){throw 'Browser blocklist verification failed.'}}}finally{$key.Close()}}
   }
  }
  Run-Native ipconfig.exe @('/flushdns')|Out-Null
  $result.detail='Mode '+$Action+' applied to the student policy hive, managed hosts blocks, Edge and Chrome. Free mode restores only managed entries. Existing browser sessions may need reopening.'
 } elseif($Action -eq 'cleanup') {
  $student=Get-Student
  foreach($folder in @('Downloads','Documents','Music','Videos','Pictures','AppData\Local\Microsoft\Windows\INetCache','AppData\Local\Microsoft\Windows\History','AppData\Roaming\Microsoft\Windows\Cookies','AppData\Local\Microsoft\Windows\WebCache')){Clear-CheckedDirectory (Join-Path $student.Root $folder) $student.Root}
  foreach($relative in @('AppData\Local\Google\Chrome\User Data','AppData\Local\Microsoft\Edge\User Data','AppData\Local\BraveSoftware\Brave-Browser\User Data','AppData\Roaming\Opera Software\Opera Stable')){
   $browserRoot=Join-Path $student.Root $relative;if(-not(Test-Path -LiteralPath $browserRoot)){continue};$browserLease=Get-CleanupLease $browserRoot $student.Root
   try{$dirs=@((Get-Item -LiteralPath $browserRoot -Force))+@(Get-ChildItem -LiteralPath $browserRoot -Directory -Force)
    foreach($dir in $dirs){$profileLease=Get-CleanupLease $dir.FullName $student.Root;try{foreach($file in @('History','History-journal','Cookies','Cookies-journal','Login Data','Login Data-journal','Visited Links','Top Sites','Top Sites-journal','Web Data','Web Data-journal','Network\Cookies','Network\Cookies-journal')){Delete-CheckedFile (Join-Path $dir.FullName $file) $student.Root};foreach($cache in @('Cache','Code Cache','GPUCache','Service Worker\CacheStorage','Session Storage','Local Storage')){Clear-CheckedDirectory (Join-Path $dir.FullName $cache) $student.Root}}finally{Close-CleanupLease $profileLease}}
   }finally{Close-CleanupLease $browserLease}
  }
  foreach($relative in @('AppData\Roaming\Mozilla\Firefox\Profiles','AppData\Local\Mozilla\Firefox\Profiles')){$base=Join-Path $student.Root $relative;if(Test-Path -LiteralPath $base){$browserLease=Get-CleanupLease $base $student.Root;try{foreach($dir in Get-ChildItem -LiteralPath $base -Directory -Force){$profileLease=Get-CleanupLease $dir.FullName $student.Root;try{foreach($file in @('cookies.sqlite','cookies.sqlite-wal','cookies.sqlite-shm','places.sqlite','places.sqlite-wal','places.sqlite-shm','formhistory.sqlite')){Delete-CheckedFile (Join-Path $dir.FullName $file) $student.Root};foreach($cache in @('cache2','startupCache')){Clear-CheckedDirectory (Join-Path $dir.FullName $cache) $student.Root}}finally{Close-CleanupLease $profileLease}}}finally{Close-CleanupLease $browserLease}}}
  foreach($drive in Get-PSDrive -PSProvider FileSystem|Where-Object {$_.Root -match '^[A-Z]:\\$'}){$bin=Join-Path $drive.Root ('$Recycle.Bin\'+$student.Sid);if(Test-Path -LiteralPath $bin){Clear-CheckedDirectory $bin (Join-Path $drive.Root '$Recycle.Bin')}}
  $result.detail='Student Downloads/Documents/Music/Videos/Pictures, browser history/cache and that student SID recycle-bin contents cleaned. MAINTENANCE and other user profiles preserved. UWF may restore protected baseline files after reboot.'
 } elseif($Action -in @('status','uwf-status')) {
  $result.detail=(Uwf-State|ConvertTo-Json -Compress)
 } elseif($Action -eq 'uwf-enable') {
  $script=Join-Path $env:ProgramData 'UEPLV\Deployment\Provisioning\Finish-Protection.ps1';if(-not(Test-Path -LiteralPath $script)){throw 'The verified deployment finalizer is missing.'}
  $code=Run-Native powershell.exe @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$script,'-Stage','Enable') @(0,3010)
  $result.restartRequired=($code -eq 3010);$result.detail='Readiness checks passed; UWF '+$(if($code -eq 3010){'scheduled for the next restart, not yet active.'}else{'already active or ready.'})
 } elseif($Action -eq 'uwf-disable') {
  if((Uwf-State).servicing){throw 'UWF servicing is active or scheduled; disabling protection is deferred until servicing completes.'}
  Run-Native uwfmgr.exe @('filter','disable')|Out-Null;Run-Native uwfmgr.exe @('volume','unprotect','C:')|Out-Null
  $s=Uwf-State;if($s.next -or $s.nextC){throw 'Next-session UWF disable could not be verified.'};$result.restartRequired=$s.current;$result.detail='UWF disabled and C: unprotected for the next boot; current protection changes only after restart.'
 } elseif($Action -eq 'uwf-purge-swap') {
  Require-Unprotected;$path=$env:SystemDrive+'\uwfswap.sys';if(Test-Path -LiteralPath $path){$item=Get-Item -LiteralPath $path -Force;if($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Swap path is not an ordinary file.'};[IO.File]::SetAttributes($path,[IO.FileAttributes]::Normal);[IO.File]::Delete($path)};$result.detail='Verified current/next UWF disabled; exact inactive C:\uwfswap.sys removed if present.'
 } elseif($Action -eq 'uwf-repair') {
  Require-Unprotected;$code=Run-Native dism.exe @('/Online','/Cleanup-Image','/RestoreHealth') @(0,3010)
  if($code -eq 3010){$result.restartRequired=$true;$result.detail='DISM repaired the image and requested a restart. Run Repair again after restart to finish SFC. No driver startup values or LowerFilters were edited.'}else{Run-Native sfc.exe @('/scannow')|Out-Null;$result.detail='DISM RestoreHealth and SFC completed while UWF was disabled. No driver startup values or LowerFilters were edited.'}
 } elseif($Action -eq 'uwf-reset-stage1') {
  Require-Unprotected; $code=Run-Native dism.exe @('/Online','/Disable-Feature','/FeatureName:Client-UnifiedWriteFilter','/NoRestart') @(0,3010);$result.resetPhase='feature-disabled';$result.restartRequired=$true;$result.detail='UWF feature removal requested. Restart is required before stage 2.'
 } elseif($Action -eq 'uwf-reset-stage2') {
  Require-Unprotected;$code=Run-Native dism.exe @('/Online','/Enable-Feature','/FeatureName:Client-UnifiedWriteFilter','/All','/NoRestart') @(0,3010);$result.resetPhase='feature-reinstalled';$result.restartRequired=$true;$result.detail='UWF feature reinstalled. Restart and verify before separately enabling protection.'
 } elseif($Action -eq 'windows-update') {
  Require-Unprotected;$script=Join-Path $env:ProgramData 'UEPLV\Deployment\Provisioning\Update-BeforeProtection.ps1';if(-not(Test-Path -LiteralPath $script)){throw 'Verified Windows Update helper is missing.'}
  $code=Run-Native powershell.exe @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$script) @(0,2,3010);$result.restartRequired=($code -eq 3010);$result.needsUpdateCheck=($code -eq 2);$result.detail=if($code -eq 2){'Additional software updates remain; run the update action again.'}elseif($code -eq 3010){'Updates or pending operations require a restart, then another update check.'}else{'Required software update installation and follow-up scan passed.'}
 }
 if($Action -eq 'cleanup' -and $script:CleanupSkippedLinks.Count){$result.detail+=' Skipped '+$script:CleanupSkippedLinks.Count+' links/junctions without traversing them.'}
 if($Action -eq 'cleanup' -and $script:CleanupSkippedBusy.Count){$result.detail+=' '+$script:CleanupSkippedBusy.Count+' cache items remain locked by Windows; other files were cleaned. Restart clears protected-session changes.'}
 $result.success=$true
} catch {$result.detail=$_.Exception.Message}
$result|ConvertTo-Json -Compress -Depth 6
if(-not $result.success){exit 1}
