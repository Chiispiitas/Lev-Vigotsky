﻿# Runs in the signed-in user's context; no administrator rights are required or requested.
# Copied to Program Files by Apply-LabSettings.ps1 and inherited via Default user Run value.
param([string]$Wallpaper = (Join-Path $env:ProgramFiles 'UEPLV\Provisioning\Wallpaper.png'))
$ErrorActionPreference = 'Stop'
$name = [Security.Principal.WindowsIdentity]::GetCurrent().Name.Split('\')[-1]
if ($name -notin @('MAINTENANCE','LEV VIGOTSKY')) { exit 0 }
$logRoot=Join-Path $env:LOCALAPPDATA 'UEPLV'
[IO.Directory]::CreateDirectory($logRoot)|Out-Null
Start-Transcript -Path (Join-Path $logRoot 'user-settings.log') -Append -Force|Out-Null
try {
function Set-UserValue([string]$Path,[string]$Name,$Value,[string]$Type='DWord') {
    if (-not (Test-Path -LiteralPath $Path)) { New-Item -Path $Path -Force | Out-Null }
    New-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -PropertyType $Type -Force | Out-Null
}
Set-UserValue 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' 'AppsUseLightTheme' 0
Set-UserValue 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' 'SearchboxTaskbarMode' 2
Set-UserValue 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'ShowTaskViewButton' 0
foreach($runKey in @('Run','RunOnce')){foreach($entry in @('OneDriveSetup','OneDrive')){Remove-ItemProperty -LiteralPath ('HKCU:\Software\Microsoft\Windows\CurrentVersion\'+$runKey) -Name $entry -ErrorAction SilentlyContinue}}
$perUserOneDrive=Join-Path $env:LOCALAPPDATA 'Microsoft\OneDrive'
if(Test-Path -LiteralPath $perUserOneDrive){
    $setup=Get-ChildItem -LiteralPath $perUserOneDrive -Filter OneDriveSetup.exe -File -Recurse -ErrorAction SilentlyContinue|Select-Object -First 1
    if($setup){Start-Process -FilePath $setup.FullName -ArgumentList '/uninstall' -Wait -WindowStyle Hidden}
}
Set-UserValue 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' 'SystemUsesLightTheme' 0
Set-UserValue 'HKCU:\Control Panel\Desktop' 'Wallpaper' $Wallpaper String
Set-UserValue 'HKCU:\Control Panel\Desktop' 'WallpaperStyle' '10' String
Set-UserValue 'HKCU:\Control Panel\Desktop' 'TileWallpaper' '0' String
foreach ($panel in @('NewStartPanel','ClassicStartMenu')) {
    $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\' + $panel
    foreach ($id in @('{20D04FE0-3AEA-1069-A2D8-08002B30309D}','{59031a47-3f72-44a7-89c5-5595fe6b30ee}','{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}','{5399E694-6CE5-4D6C-8FCE-1D8870FDCBA0}')) { Set-UserValue $key $id 1 }
    Set-UserValue $key '{645FF040-5081-101B-9F08-00AA002F954E}' 0
}
# Restricted policy keys are configured by the elevated installer before first sign-in.
# Standard users must never write these keys: an access error would stop the wallpaper refresh.
# Native refresh changes only this user's wallpaper, never another session.
if (-not ('UEPLV.Wallpaper' -as [type])) {
    Add-Type -TypeDefinition 'namespace UEPLV { public class Wallpaper { [System.Runtime.InteropServices.DllImport("user32.dll", CharSet=System.Runtime.InteropServices.CharSet.Unicode)] public static extern bool SystemParametersInfo(int action, int param, string value, int flags); } }'
}
if (Test-Path -LiteralPath $Wallpaper) { [UEPLV.Wallpaper]::SystemParametersInfo(20,0,$Wallpaper,3) | Out-Null }

# Windows resolves the original taskbar pin back to Edge's default shortcut.
# Update the actual per-user pin after Explorer creates it, without requiring elevation.
$pinRoot=Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar'
$edgePins=@();$shell=New-Object -ComObject WScript.Shell
try {
    for($attempt=0;$attempt -lt 30;$attempt++){
        $edgePins=@(Get-ChildItem -LiteralPath $pinRoot -Filter '*.lnk' -ErrorAction SilentlyContinue|Where-Object {$shell.CreateShortcut($_.FullName).TargetPath -match '\\msedge\.exe$'})
        if($edgePins.Count){break};Start-Sleep -Seconds 1
    }
    foreach($pin in $edgePins){
        $link=$shell.CreateShortcut($pin.FullName)
        $link.Arguments='--no-first-run --new-window https://www.google.com/'
        $link.IconLocation=$link.TargetPath+',0';$link.Save()
        if($shell.CreateShortcut($pin.FullName).Arguments -notmatch 'https://www.google.com/'){throw 'Pinned Edge startup could not be verified.'}
    }
} finally {[Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell)|Out-Null}

[IO.File]::WriteAllText((Join-Path $logRoot 'user-settings.json'),(@{Success=$true;PinnedEdgeGoogle=($edgePins.Count -gt 0);User=$name;Wallpaper=$Wallpaper;Utc=[datetime]::UtcNow.ToString('o')}|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
} catch {
    [IO.File]::WriteAllText((Join-Path $logRoot 'user-settings.json'),(@{Success=$false;User=$name;Error=$_.Exception.Message;Utc=[datetime]::UtcNow.ToString('o')}|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
    throw
} finally {Stop-Transcript|Out-Null}
