﻿[CmdletBinding()]
param([ValidateRange(0,33)][int]$ComputerNumber = 0)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
function Write-SetupJson([string]$Path,$Value){
    $json=ConvertTo-Json -InputObject $Value -Depth 12
    if([string]::IsNullOrWhiteSpace($json)){throw ('Refusing to write empty setup data: '+$Path)}
    $bytes=[Text.UTF8Encoding]::new($false).GetBytes($json)
    $file=[IO.File]::Open($Path,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::Read)
    try{$preamble=[Text.Encoding]::UTF8.GetPreamble();$file.Write($preamble,0,$preamble.Length);$file.Write($bytes,0,$bytes.Length);$file.Flush($true)}finally{$file.Dispose()}
}
$principal = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Run this setup as MAINTENANCE.' }
if ($env:USERNAME -ne 'MAINTENANCE') { throw 'This installer is for a newly installed lab PC signed in as MAINTENANCE.' }
# Consume setup's one-time staff sign-in before any dialog or operation can fail.
$winlogon='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
Set-ItemProperty -Path $winlogon -Name AutoAdminLogon -Value '0'
New-ItemProperty -Path $winlogon -Name AutoLogonCount -Value 0 -PropertyType DWord -Force | Out-Null
Remove-ItemProperty -Path $winlogon -Name DefaultPassword -ErrorAction SilentlyContinue
$stateRoot = Join-Path $env:ProgramData 'UEPLV'
[IO.Directory]::CreateDirectory($stateRoot)|Out-Null
$stateAcl=[Security.AccessControl.DirectorySecurity]::new()
$stateAcl.SetAccessRuleProtection($true,$false)
foreach($sid in @('S-1-5-18','S-1-5-32-544')){
    $stateAcl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new([Security.Principal.SecurityIdentifier]::new($sid),'FullControl','ContainerInherit,ObjectInherit','None','Allow'))
}
Set-Acl -LiteralPath $stateRoot -AclObject $stateAcl
$reports = Join-Path $stateRoot 'Reports'
New-Item -ItemType Directory -Path $reports -Force | Out-Null
function Invoke-DeploymentStep {
    param([string]$Script,[string[]]$Parameters=@(),[int[]]$AllowedExitCodes=@(0))
    & "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $Script @Parameters
    $code=$LASTEXITCODE
    if($code -notin $AllowedExitCodes){throw ('Setup component failed: '+[IO.Path]::GetFileName($Script)+' (exit '+$code+'). Review its report.')}
}
$identityPath = Join-Path $stateRoot 'deployment-identity.json'
if (Test-Path -LiteralPath $identityPath) {
    try{$saved=Get-Content -LiteralPath $identityPath -Raw|ConvertFrom-Json;if(-not $saved -or [int]$saved.Number -lt 1 -or [int]$saved.Number -gt 33){throw 'Invalid saved PC number.'}}
    catch{throw ('Saved setup identity is invalid: '+$identityPath+'. Collect the diagnostics ZIP before changing this file. '+$_.Exception.Message)}
    $ComputerNumber = [int]$saved.Number
}
if ($ComputerNumber -eq 0) {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $form = New-Object Windows.Forms.Form
    $form.Text = 'Configuracion del laboratorio UEPLV'
    $form.Size = New-Object Drawing.Size(440,190)
    $form.StartPosition = 'CenterScreen'
    $form.TopMost = $true
    $form.FormBorderStyle = 'FixedDialog'
    $form.MaximizeBox = $false
    $label = New-Object Windows.Forms.Label
    $label.Text = 'Numero del equipo (01 a 33):'
    $label.Location = New-Object Drawing.Point(25,25)
    $label.AutoSize = $true
    $number = New-Object Windows.Forms.NumericUpDown
    $number.Minimum = 1; $number.Maximum = 33; $number.Value = 1
    $number.Location = New-Object Drawing.Point(270,22)
    $number.Width = 100
    $button = New-Object Windows.Forms.Button
    $button.Text = 'Configurar equipo'
    $button.Location = New-Object Drawing.Point(125,80)
    $button.Size = New-Object Drawing.Size(160,35)
    $button.DialogResult = [Windows.Forms.DialogResult]::OK
    $form.Controls.AddRange(@($label,$number,$button))
    $form.AcceptButton = $button
    if ($form.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { throw 'Setup cancelled. No protection was enabled.' }
    $ComputerNumber = [int]$number.Value
    $form.Dispose()
}
$name = 'LEV-VIGOTSKY-{0:00}' -f $ComputerNumber
$managementName = 'UEPLV-{0:00}' -f $ComputerNumber
Write-SetupJson $identityPath @{Number=$ComputerNumber;ComputerName=$name;ManagementName=$managementName;CreatedUtc=[DateTime]::UtcNow.ToString('o')}
. (Join-Path $root 'Provisioning\Resolve-SetupEnrollment.ps1')
$enrollment=Resolve-LabSetupEnrollment $stateRoot $managementName
$report = [ordered]@{ComputerName=$name;StartedUtc=[DateTime]::UtcNow.ToString('o');Success=$false;Steps=@();Warnings=@();Protection='Not enabled';Error=$null}
try {
    $student = Get-LocalUser -Name 'LEV VIGOTSKY'
    $admin = Get-LocalUser -Name 'MAINTENANCE'
    # Explicitly initialize the blank local student password; an empty Setup password can leave it unusable.
    $studentAccount=[ADSI]('WinNT://'+$env:COMPUTERNAME+'/'+$student.Name+',user')
    $studentAccount.SetPassword('');$studentAccount.SetInfo()
    Set-LocalUser -Name $student.Name -PasswordNeverExpires $true
    Set-LocalUser -Name $admin.Name -PasswordNeverExpires $true
    $adminGroup = Get-LocalGroup -SID 'S-1-5-32-544'
    if ((Get-LocalGroupMember -Group $adminGroup.Name | Where-Object SID -eq $student.SID)) {
        Remove-LocalGroupMember -Group $adminGroup.Name -Member $student.Name
    }
    $usersGroup = Get-LocalGroup -SID 'S-1-5-32-545'
    if (-not (Get-LocalGroupMember -Group $usersGroup.Name | Where-Object SID -eq $student.SID)) {
        Add-LocalGroupMember -Group $usersGroup.Name -Member $student.Name
    }
    if (-not (Get-LocalGroupMember -Group $adminGroup.Name | Where-Object SID -eq $admin.SID)) { throw 'MAINTENANCE is not an administrator.' }
    $report.Steps += 'Account membership verified'
    if ($env:COMPUTERNAME -ne $name) { Rename-Computer -NewName $name -Force | Out-Null }
    $report.Steps += 'Computer name assigned'
    Invoke-DeploymentStep (Join-Path $root 'Provisioning\Configure-LabShell.ps1') @() @(0,2)
    $report.Steps += 'Taskbar configured; bundled app cleanup report saved'
    $shellReport=Get-Content -LiteralPath (Join-Path $stateRoot 'Provisioning\declutter-report.json') -Raw|ConvertFrom-Json
    if(-not $shellReport.Success){$report.Warnings+=('App cleanup needs review: '+($shellReport.Errors -join '; '))}
    Invoke-DeploymentStep (Join-Path $root 'Provisioning\Apply-LabSettings.ps1') @('-PayloadRoot',$root)
    $report.Steps += 'Appearance and browser policies applied'
    Invoke-DeploymentStep (Join-Path $root 'Veyon\Install-Veyon.ps1')
    $report.Steps += 'Veyon installed and public key imported'
    Invoke-DeploymentStep (Join-Path $root 'Management\Install-Agent.ps1') @('-ComputerName',$managementName,'-EnrollmentFile',$enrollment)
    $report.Steps += 'Management service installed'
    $action=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+(Join-Path $root 'Finalize-Deployment.ps1')+'"')
    $startup=New-ScheduledTaskTrigger -AtStartup
    $retry=New-ScheduledTaskTrigger -Once -At ((Get-Date).AddMinutes(5)) -RepetitionInterval (New-TimeSpan -Minutes 15)
    $principalTask=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $settings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 3)
    Register-ScheduledTask -TaskName 'UEPLV-FinalizeDeployment' -Action $action -Trigger @($startup,$retry) -Principal $principalTask -Settings $settings -Force | Out-Null
    $report.Steps += 'Automatic update and UWF verification task registered'
    # Switch automatic sign-in to the unprivileged student only after provisioning succeeds.
    $winlogon='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
    New-ItemProperty -Path $winlogon -Name AutoAdminLogon -Value '1' -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $winlogon -Name DefaultUserName -Value 'LEV VIGOTSKY' -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $winlogon -Name DefaultDomainName -Value $name -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $winlogon -Name DefaultPassword -Value '' -PropertyType String -Force | Out-Null
    Remove-ItemProperty -Path $winlogon -Name AutoLogonCount -ErrorAction SilentlyContinue
    # Remove cached setup answers carrying temporary administrator autologon material.
    foreach($answer in @("$env:windir\Panther\unattend.xml","$env:windir\Panther\Unattend\unattend.xml","$env:windir\System32\Sysprep\unattend.xml")) {
        if(Test-Path -LiteralPath $answer) { Remove-Item -LiteralPath $answer -Force }
    }
    $report.Steps += 'Student automatic sign-in configured'
    $report.Success=$true
    $report.Protection='Awaiting Windows updates, gateway enrollment and verification'
} catch {
    $report.Error=$_.Exception.Message
    # Never leave unattended administrator sign-in enabled after a failed deployment.
    $winlogon='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
    Set-ItemProperty -Path $winlogon -Name AutoAdminLogon -Value '0' -ErrorAction SilentlyContinue
    Remove-ItemProperty -Path $winlogon -Name DefaultPassword -ErrorAction SilentlyContinue
    throw
} finally {
    $report.CompletedUtc=[DateTime]::UtcNow.ToString('o')
    Write-SetupJson (Join-Path $reports 'deployment.json') $report
}
if($report.Warnings.Count){Write-Warning ($report.Warnings -join '; ');Write-Host 'No se reinicia automaticamente: revise declutter-report.json. La proteccion UWF queda pendiente.';return}
Write-Host 'Configuracion inicial terminada. Reiniciando para aplicar el nombre e iniciar como estudiante.'
& shutdown.exe /r /t 30 /c 'UEPLV: configuracion inicial terminada. Las actualizaciones y la verificacion deben completarse antes de activar UWF.'
