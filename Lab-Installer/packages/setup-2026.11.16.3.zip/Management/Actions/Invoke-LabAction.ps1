﻿#Requires -RunAsAdministrator
[CmdletBinding()]
param(
 [Parameter(Mandatory)][ValidateSet('class','class-ai','exam','free','cleanup','browser-cleanup','status','uwf-status','uwf-enable','uwf-disable','uwf-purge-swap','uwf-repair','uwf-reset-stage1','uwf-reset-stage2','windows-update')][string]$Action,
 [switch]$PolicyOnly
)
$ErrorActionPreference='Stop'
if($env:COMPUTERNAME -notmatch '^(?:UEPLV-|LEV-VIGOTSKY-)(0[1-9]|[12][0-9]|3[0-4])$'){throw 'This action helper is only for enrolled UEPLV lab computers.'}
$result=[ordered]@{success=$false;detail=$null;restartRequired=$false;resetPhase=$null;needsUpdateCheck=$false}
$script:CleanupSkippedLinks=[Collections.Generic.List[string]]::new()
$script:CleanupSkippedBusy=[Collections.Generic.List[string]]::new()
$stateRoot=Join-Path $env:ProgramData 'UEPLV\Management'
$reportRoot=Join-Path $env:ProgramData 'UEPLV\Reports'
[IO.Directory]::CreateDirectory($reportRoot)|Out-Null
function Run-Native([string]$File,[string[]]$Arguments,[int[]]$Allowed=@(0)){
 $log=Join-Path $reportRoot ('action-'+$Action+'.log')
 $old=$ErrorActionPreference;try{$ErrorActionPreference='Continue';& $File @Arguments 2>&1|Out-File -LiteralPath $log -Append -Encoding UTF8;$code=$LASTEXITCODE}finally{$ErrorActionPreference=$old}
 if($code -notin $Allowed){throw ([IO.Path]::GetFileName($File)+' returned '+$code+'; see action report.')};return [int]$code
}
function Uwf-State {
 $f=Get-CimInstance -Namespace 'root\standardcimv2\embedded' -ClassName UWF_Filter -ErrorAction Stop
 $v=@(Get-CimInstance -Namespace 'root\standardcimv2\embedded' -ClassName UWF_Volume|Where-Object DriveLetter -eq 'C:')
 $s=@(Get-CimInstance -Namespace 'root\standardcimv2\embedded' -ClassName UWF_Servicing)
 [pscustomobject]@{current=[bool]$f.CurrentEnabled;next=[bool]$f.NextEnabled;currentC=[bool]($v|Where-Object CurrentSession|Select-Object -ExpandProperty Protected);nextC=[bool]($v|Where-Object {-not $_.CurrentSession}|Select-Object -ExpandProperty Protected);servicing=[bool]@($s|Where-Object ServicingEnabled).Count}
}
function Require-Unprotected {
 $f=Get-WindowsOptionalFeature -Online -FeatureName Client-UnifiedWriteFilter
 if($f.State -eq 'DisablePending' -or $f.State -eq 'EnablePending'){throw 'A UWF feature restart is pending. Restart before this action.'}
 if($f.State -eq 'Enabled'){$s=Uwf-State;if($s.current -or $s.next -or $s.servicing){throw 'This action requires UWF disabled now and for the next boot, with servicing off.'}}
}
function Get-Student {
 $account=Get-LocalUser -Name 'LEV VIGOTSKY' -ErrorAction Stop
 $p=Get-CimInstance Win32_UserProfile|Where-Object SID -eq $account.SID.Value|Select-Object -First 1
 if(-not $p){throw 'Student profile has not been created yet. Sign in to LEV VIGOTSKY first.'}
 $root=[IO.Path]::GetFullPath($p.LocalPath).TrimEnd('\')
 if(-not $root.StartsWith(($env:SystemDrive+'\Users\'),[StringComparison]::OrdinalIgnoreCase) -or ($p.Special) -or ((Get-Item -LiteralPath $root -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Student profile is not an ordinary local user directory.'}
 [pscustomobject]@{Root=$root;Sid=$account.SID.Value}
}
function Ensure-CleanupNative {
 if('UEPLV.CheckedDelete' -as [type]){return}
 Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Text;
using System.ComponentModel;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
namespace UEPLV {
 public static class CheckedDelete {
  [StructLayout(LayoutKind.Sequential)]struct TagInfo{public uint Attributes;public uint Tag;}
  [StructLayout(LayoutKind.Sequential)]struct Disposition{[MarshalAs(UnmanagedType.U1)]public bool Delete;}
  [StructLayout(LayoutKind.Sequential)]struct BasicInfo{public long Created,Accessed,Written,Changed;public uint Attributes;}
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern SafeFileHandle CreateFile(string p,uint access,uint share,IntPtr security,uint creation,uint flags,IntPtr template);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern uint GetFinalPathNameByHandle(SafeFileHandle h,StringBuilder p,uint length,uint flags);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetFileInformationByHandleEx(SafeFileHandle h,int kind,out TagInfo info,uint size);
  [DllImport("kernel32.dll",EntryPoint="SetFileInformationByHandle",SetLastError=true)]static extern bool SetDisposition(SafeFileHandle h,int kind,ref Disposition info,uint size);
  [DllImport("kernel32.dll",EntryPoint="SetFileInformationByHandle",SetLastError=true)]static extern bool SetBasic(SafeFileHandle h,int kind,ref BasicInfo info,uint size);
  static void Check(SafeFileHandle h,string root,bool allowRoot){if(h.IsInvalid)throw new Win32Exception(Marshal.GetLastWin32Error(),"Cannot acquire safe cleanup handle");var path=new StringBuilder(32768);uint n=GetFinalPathNameByHandle(h,path,(uint)path.Capacity,0);if(n==0||n>=path.Capacity)throw new Win32Exception(Marshal.GetLastWin32Error(),"Cannot resolve cleanup handle");string resolved=path.ToString();if(resolved.StartsWith(@"\\?\"))resolved=resolved.Substring(4);string expected=Path.GetFullPath(root).TrimEnd('\\');if(!(resolved.StartsWith(expected+"\\",StringComparison.OrdinalIgnoreCase)||(allowRoot&&resolved.Equals(expected,StringComparison.OrdinalIgnoreCase))))throw new IOException("Resolved cleanup handle escaped the approved student root");TagInfo info;if(!GetFileInformationByHandleEx(h,9,out info,8))throw new Win32Exception(Marshal.GetLastWin32Error());if((info.Attributes&0x400)!=0)throw new IOException("Cleanup refused a reparse point");}
  [StructLayout(LayoutKind.Sequential)]struct FileInfo {public uint Attributes;public System.Runtime.InteropServices.ComTypes.FILETIME Created,Accessed,Written;public uint Volume,SizeHigh,SizeLow,Links,IndexHigh,IndexLow;}
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetFileInformationByHandle(SafeFileHandle h,out FileInfo info);
  [DefaultDllImportSearchPaths(DllImportSearchPath.System32)][DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl,CharSet=CharSet.Unicode)]static extern int sqlite3_open16(string name,out IntPtr db);
  [DefaultDllImportSearchPaths(DllImportSearchPath.System32)][DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl)]static extern int sqlite3_exec(IntPtr db,byte[] sql,IntPtr callback,IntPtr arg,out IntPtr error);
  [DefaultDllImportSearchPaths(DllImportSearchPath.System32)][DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl)]static extern int sqlite3_close(IntPtr db);
  [DefaultDllImportSearchPaths(DllImportSearchPath.System32)][DllImport("winsqlite3.dll",CallingConvention=CallingConvention.Cdecl)]static extern void sqlite3_free(IntPtr p);
  static SafeFileHandle LockDatabaseFile(string path,string root){var h=CreateFile(path,0xc0000000,3,IntPtr.Zero,4,0x00200000,IntPtr.Zero);try{Check(h,root,false);FileInfo info;if(!GetFileInformationByHandle(h,out info)||info.Links!=1)throw new IOException("Browser database has links or cannot be verified");return h;}catch{h.Dispose();throw;}}
  static void Sql(IntPtr db,string sql){IntPtr error;int code=sqlite3_exec(db,Encoding.UTF8.GetBytes(sql+"\0"),IntPtr.Zero,IntPtr.Zero,out error);if(error!=IntPtr.Zero)sqlite3_free(error);if(code!=0)throw new IOException("Browser history cleanup failed (SQLite "+code+")");}
  public static void FirefoxHistory(string path,string root){
   if(!File.Exists(path))return;
   using(var dbLock=LockDatabaseFile(path,root))using(var walLock=LockDatabaseFile(path+"-wal",root))using(var shmLock=LockDatabaseFile(path+"-shm",root))using(var journalLock=LockDatabaseFile(path+"-journal",root)){
    bool wal=false;using(var header=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite)){header.Position=18;wal=header.ReadByte()==2;}
    IntPtr db=IntPtr.Zero;try{if(sqlite3_open16(path,out db)!=0)throw new IOException("Could not open student browser history");if(!wal)Sql(db,"PRAGMA journal_mode=PERSIST;");Sql(db,"PRAGMA busy_timeout=5000; PRAGMA trusted_schema=OFF; PRAGMA secure_delete=ON; BEGIN IMMEDIATE; DELETE FROM moz_historyvisits; DELETE FROM moz_inputhistory; UPDATE moz_places SET visit_count=0,last_visit_date=NULL,typed=0; COMMIT; PRAGMA wal_checkpoint(TRUNCATE);");}finally{if(db!=IntPtr.Zero)sqlite3_close(db);}
   }
  }
  public static SafeFileHandle LockDirectory(string path,string root){var h=CreateFile(path,0x81,1,IntPtr.Zero,3,0x02200000,IntPtr.Zero);try{Check(h,root,true);return h;}catch{h.Dispose();throw;}}
  public static void Delete(string path,string root,bool directory){using(var h=CreateFile(path,0x10180,7,IntPtr.Zero,3,0x02200000,IntPtr.Zero)){if(h.IsInvalid)throw new Win32Exception(Marshal.GetLastWin32Error(),"Cannot open cleanup item: "+path);Check(h,root,false);if(!directory){var basic=new BasicInfo{Attributes=0x80};if(!SetBasic(h,0,ref basic,(uint)Marshal.SizeOf(typeof(BasicInfo))))throw new Win32Exception(Marshal.GetLastWin32Error());}var d=new Disposition{Delete=true};if(!SetDisposition(h,4,ref d,(uint)Marshal.SizeOf(typeof(Disposition))))throw new Win32Exception(Marshal.GetLastWin32Error(),"Cleanup could not delete the checked item");}}
 }
}
'@
}
function Get-CleanupLease([string]$Path,[string]$AllowedRoot){
 Ensure-CleanupNative
 $full=[IO.Path]::GetFullPath($Path).TrimEnd('\');$root=[IO.Path]::GetFullPath($AllowedRoot).TrimEnd('\')
 if($full -ne $root -and -not $full.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Cleanup path escaped the approved student root.'}
 $handles=[Collections.Generic.List[object]]::new()
 try{
  $current=$root;$handles.Add([UEPLV.CheckedDelete]::LockDirectory($current,$root))
  if($full.Length -gt $root.Length){foreach($segment in $full.Substring($root.Length+1).Split('\')){$current=Join-Path $current $segment;$handles.Add([UEPLV.CheckedDelete]::LockDirectory($current,$root))}}
  return ,$handles
 }catch{foreach($h in $handles){$h.Dispose()};throw}
}
function Close-CleanupLease($Lease){if($Lease){foreach($h in $Lease){$h.Dispose()}}}
function Invoke-CheckedCleanupDelete([string]$Path,[string]$Root,[bool]$Directory){
 try{[UEPLV.CheckedDelete]::Delete($Path,$Root,$Directory)}catch{
  $cause=$_.Exception.GetBaseException()
  if($Path -match '\\AppData\\(Local|Roaming)\\' -and $cause -is [ComponentModel.Win32Exception] -and $cause.NativeErrorCode -in @(5,32,33)){
   $script:CleanupSkippedBusy.Add($Path)
  }else{throw}
 }
}
function Clear-CheckedDirectory([string]$Path,[string]$AllowedRoot){
 $full=[IO.Path]::GetFullPath($Path).TrimEnd('\');$allowed=[IO.Path]::GetFullPath($AllowedRoot).TrimEnd('\')
 if(-not $full.StartsWith($allowed+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Cleanup path escaped the approved student area.'}
 if(-not(Test-Path -LiteralPath $full)){return}
 if((Get-Item -LiteralPath $full -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){$script:CleanupSkippedLinks.Add($full);return}
 $lease=Get-CleanupLease $full $AllowedRoot;$directoryHandles=@{}
 try{
  $stack=[Collections.Generic.Stack[string]]::new();$stack.Push($full);$items=[Collections.Generic.List[object]]::new()
  while($stack.Count){$dir=$stack.Pop();foreach($item in Get-ChildItem -LiteralPath $dir -Force){if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){$script:CleanupSkippedLinks.Add($item.FullName);continue};$items.Add($item);if($item.PSIsContainer){$directoryHandles[$item.FullName]=[UEPLV.CheckedDelete]::LockDirectory($item.FullName,$AllowedRoot);$stack.Push($item.FullName)}}}
  foreach($item in @($items|Sort-Object @{Expression={$_.FullName.Length};Descending=$true})){
   if($item.PSIsContainer){$directoryHandles[$item.FullName].Dispose();$directoryHandles.Remove($item.FullName)}
   if($item.PSIsContainer -and @($script:CleanupSkippedLinks|Where-Object {$_.StartsWith($item.FullName+'\',[StringComparison]::OrdinalIgnoreCase)}).Count){continue}
   if($item.PSIsContainer -and @($script:CleanupSkippedBusy|Where-Object {$_.StartsWith($item.FullName+'\',[StringComparison]::OrdinalIgnoreCase)}).Count){continue}
   Invoke-CheckedCleanupDelete $item.FullName $AllowedRoot ([bool]$item.PSIsContainer)
  }
 }finally{foreach($h in $directoryHandles.Values){$h.Dispose()};Close-CleanupLease $lease}
}
function Delete-CheckedFile([string]$Path,[string]$Root){
 $full=[IO.Path]::GetFullPath($Path);$base=[IO.Path]::GetFullPath($Root).TrimEnd('\')
 if(-not $full.StartsWith($base+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Browser cleanup path escaped student profile.'}
 if(Test-Path -LiteralPath $full){$lease=Get-CleanupLease ([IO.Path]::GetDirectoryName($full)) $Root;try{Invoke-CheckedCleanupDelete $full $Root $false}finally{Close-CleanupLease $lease}}
}
$classGames='friv.com voxiom.io shellshock.io poki.com roblox.com veck.io msn.com games.msn.com zone.msn.com disneyplus.com twitch.tv steamcommunity.com steampowered.com epicgames.com blizzboygames.net krunker.io paper-io.com slither.io agar.io hole-io.com crazygames.com minijuegos.com poki.es badtimesimulator.io jcw87.github.io doodles.google'.Split(' ')
$classSocial='facebook.com instagram.com tiktok.com youtube.com twitter.com x.com snapchat.com kwai.com'.Split(' ')
$classAdult='pornhub.com xnxx.com xvideos.com stripchat.com chaturbate.com xhamster.com youporn.com redtube.com spankbang.com tnaflix.com beeg.com cam4.com bongacams.com rule34.xxx e621.net'.Split(' ')
$ai='chat.openai.com chatgpt.com openai.com gemini.google.com bard.google.com copilot.microsoft.com claude.ai poe.com perplexity.ai you.com meta.ai'.Split(' ')
$examWeb='google.com bing.com yahoo.com duckduckgo.com ask.com baidu.com yandex.com brave.com search.brave.com youtube.com facebook.com instagram.com tiktok.com x.com twitter.com whatsapp.com web.whatsapp.com discord.com netflix.com disneyplus.com twitch.tv reddit.com'.Split(' ')
$patterns=@('*://jcw87.github.io/c2-sans-fight/*','*://badtimesimulator.io/*','*://*.badtimesimulator.io/*','*://www.google.com/logos/*','*://google.com/logos/*','*://www.google.com/doodles/*','*://google.com/doodles/*','*://doodles.google/*','*://*.doodles.google/*')
function Set-OwnedRegistryValue([string]$Path,[string]$Name,$Value,[string]$Kind='DWord'){
 $backupPath=Join-Path $stateRoot 'mode-registry-before.json'
 $backup=@();if(Test-Path -LiteralPath $backupPath){$parsed=Get-Content -LiteralPath $backupPath -Raw|ConvertFrom-Json;$backup=@($parsed)}
 if(-not @($backup|Where-Object {$_.path -eq $Path -and $_.name -eq $Name}).Count){$exists=$false;$old=$null;$oldKind=$null;if(Test-Path -LiteralPath $Path){$key=Get-Item -LiteralPath $Path;try{if($key.GetValueNames() -contains $Name){$exists=$true;$old=$key.GetValue($Name);$oldKind=$key.GetValueKind($Name).ToString()}}finally{$key.Close()}};$backup+=@{path=$Path;name=$Name;exists=$exists;value=$old;kind=$oldKind};[IO.File]::WriteAllText($backupPath,(ConvertTo-Json -InputObject @($backup) -Depth 6),[Text.UTF8Encoding]::new($false))}
 if(-not(Test-Path -LiteralPath $Path)){New-Item -Path $Path -Force|Out-Null};New-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -PropertyType $Kind -Force|Out-Null
}
function Restore-OwnedRegistryValue([string]$Path,[string]$Name){
 $backupPath=Join-Path $stateRoot 'mode-registry-before.json';if(-not(Test-Path -LiteralPath $backupPath)){return}
 $records=Get-Content -LiteralPath $backupPath -Raw|ConvertFrom-Json
 $record=$records|Where-Object {$_.path -eq $Path -and $_.name -eq $Name}|Select-Object -First 1
 if(-not $record){return};if($record.exists){if(-not(Test-Path -LiteralPath $Path)){New-Item -Path $Path -Force|Out-Null};New-ItemProperty -LiteralPath $Path -Name $Name -Value $record.value -PropertyType $record.kind -Force|Out-Null}else{Remove-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction SilentlyContinue}
}
function Sync-InstalledUserSettings {
 # Delivered inside the signed action-module update; never read executable code from cloud settings.
 $target=Join-Path $env:ProgramFiles 'UEPLV\Provisioning\Apply-UserSettings.ps1'
 if(-not(Test-Path -LiteralPath (Split-Path $target))){throw 'Installed classroom provisioning folder is missing.'}
 $expected='DF6682485410ED7FEC127794BBF498BE8989A6BA4C29070C6F8C0963894520AC'
 if((Test-Path -LiteralPath $target) -and (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -eq $expected){return}
 if([IO.File]::Exists($target)){[IO.File]::SetAttributes($target,([IO.File]::GetAttributes($target) -band (-bnot [IO.FileAttributes]::ReadOnly)))}
 [IO.File]::WriteAllBytes($target,[Convert]::FromBase64String('77u/IyBSdW5zIGluIHRoZSBzaWduZWQtaW4gdXNlcidzIGNvbnRleHQ7IG5vIGFkbWluaXN0cmF0b3IgcmlnaHRzIGFyZSByZXF1aXJlZCBvciByZXF1ZXN0ZWQuDQojIENvcGllZCB0byBQcm9ncmFtIEZpbGVzIGJ5IEFwcGx5LUxhYlNldHRpbmdzLnBzMSBhbmQgaW5oZXJpdGVkIHZpYSBEZWZhdWx0IHVzZXIgUnVuIHZhbHVlLg0KcGFyYW0oW3N0cmluZ10kV2FsbHBhcGVyID0gKEpvaW4tUGF0aCAkZW52OlByb2dyYW1GaWxlcyAnVUVQTFZcUHJvdmlzaW9uaW5nXFdhbGxwYXBlci5wbmcnKSkNCiRFcnJvckFjdGlvblByZWZlcmVuY2UgPSAnU3RvcCcNCiRuYW1lID0gW1NlY3VyaXR5LlByaW5jaXBhbC5XaW5kb3dzSWRlbnRpdHldOjpHZXRDdXJyZW50KCkuTmFtZS5TcGxpdCgnXCcpWy0xXQ0KaWYgKCRuYW1lIC1ub3RpbiBAKCdNQUlOVEVOQU5DRScsJ0xFViBWSUdPVFNLWScpKSB7IGV4aXQgMCB9DQokbG9nUm9vdD1Kb2luLVBhdGggJGVudjpMT0NBTEFQUERBVEEgJ1VFUExWJw0KW0lPLkRpcmVjdG9yeV06OkNyZWF0ZURpcmVjdG9yeSgkbG9nUm9vdCl8T3V0LU51bGwNClN0YXJ0LVRyYW5zY3JpcHQgLVBhdGggKEpvaW4tUGF0aCAkbG9nUm9vdCAndXNlci1zZXR0aW5ncy5sb2cnKSAtQXBwZW5kIC1Gb3JjZXxPdXQtTnVsbA0KdHJ5IHsNCmZ1bmN0aW9uIFNldC1Vc2VyVmFsdWUoW3N0cmluZ10kUGF0aCxbc3RyaW5nXSROYW1lLCRWYWx1ZSxbc3RyaW5nXSRUeXBlPSdEV29yZCcpIHsNCiAgICBpZiAoLW5vdCAoVGVzdC1QYXRoIC1MaXRlcmFsUGF0aCAkUGF0aCkpIHsgTmV3LUl0ZW0gLVBhdGggJFBhdGggLUZvcmNlIHwgT3V0LU51bGwgfQ0KICAgIE5ldy1JdGVtUHJvcGVydHkgLUxpdGVyYWxQYXRoICRQYXRoIC1OYW1lICROYW1lIC1WYWx1ZSAkVmFsdWUgLVByb3BlcnR5VHlwZSAkVHlwZSAtRm9yY2UgfCBPdXQtTnVsbA0KfQ0KU2V0LVVzZXJWYWx1ZSAnSEtDVTpcU29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cVGhlbWVzXFBlcnNvbmFsaXplJyAnQXBwc1VzZUxpZ2h0VGhlbWUnIDANClNldC1Vc2VyVmFsdWUgJ0hLQ1U6XENvbnRyb2wgUGFuZWxcRGVza3RvcCcgJ1NjcmVlblNhdmVBY3RpdmUnICcwJyBTdHJpbmcNClNldC1Vc2VyVmFsdWUgJ0hLQ1U6XFNvZnR3YXJlXE1pY3Jvc29mdFxXaW5kb3dzXEN1cnJlbnRWZXJzaW9uXFNlYXJjaCcgJ1NlYXJjaGJveFRhc2tiYXJNb2RlJyAyDQpTZXQtVXNlclZhbHVlICdIS0NVOlxTb2Z0d2FyZVxNaWNyb3NvZnRcV2luZG93c1xDdXJyZW50VmVyc2lvblxFeHBsb3JlclxBZHZhbmNlZCcgJ1Nob3dUYXNrVmlld0J1dHRvbicgMA0KZm9yZWFjaCgkcnVuS2V5IGluIEAoJ1J1bicsJ1J1bk9uY2UnKSl7Zm9yZWFjaCgkZW50cnkgaW4gQCgnT25lRHJpdmVTZXR1cCcsJ09uZURyaXZlJykpe1JlbW92ZS1JdGVtUHJvcGVydHkgLUxpdGVyYWxQYXRoICgnSEtDVTpcU29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cJyskcnVuS2V5KSAtTmFtZSAkZW50cnkgLUVycm9yQWN0aW9uIFNpbGVudGx5Q29udGludWV9fQ0KJHBlclVzZXJPbmVEcml2ZT1Kb2luLVBhdGggJGVudjpMT0NBTEFQUERBVEEgJ01pY3Jvc29mdFxPbmVEcml2ZScNCmlmKFRlc3QtUGF0aCAtTGl0ZXJhbFBhdGggJHBlclVzZXJPbmVEcml2ZSl7DQogICAgJHNldHVwPUdldC1DaGlsZEl0ZW0gLUxpdGVyYWxQYXRoICRwZXJVc2VyT25lRHJpdmUgLUZpbHRlciBPbmVEcml2ZVNldHVwLmV4ZSAtRmlsZSAtUmVjdXJzZSAtRXJyb3JBY3Rpb24gU2lsZW50bHlDb250aW51ZXxTZWxlY3QtT2JqZWN0IC1GaXJzdCAxDQogICAgaWYoJHNldHVwKXtTdGFydC1Qcm9jZXNzIC1GaWxlUGF0aCAkc2V0dXAuRnVsbE5hbWUgLUFyZ3VtZW50TGlzdCAnL3VuaW5zdGFsbCcgLVdhaXQgLVdpbmRvd1N0eWxlIEhpZGRlbn0NCn0NClNldC1Vc2VyVmFsdWUgJ0hLQ1U6XFNvZnR3YXJlXE1pY3Jvc29mdFxXaW5kb3dzXEN1cnJlbnRWZXJzaW9uXFRoZW1lc1xQZXJzb25hbGl6ZScgJ1N5c3RlbVVzZXNMaWdodFRoZW1lJyAwDQpTZXQtVXNlclZhbHVlICdIS0NVOlxDb250cm9sIFBhbmVsXERlc2t0b3AnICdXYWxscGFwZXInICRXYWxscGFwZXIgU3RyaW5nDQpTZXQtVXNlclZhbHVlICdIS0NVOlxDb250cm9sIFBhbmVsXERlc2t0b3AnICdXYWxscGFwZXJTdHlsZScgJzEwJyBTdHJpbmcNClNldC1Vc2VyVmFsdWUgJ0hLQ1U6XENvbnRyb2wgUGFuZWxcRGVza3RvcCcgJ1RpbGVXYWxscGFwZXInICcwJyBTdHJpbmcNCmZvcmVhY2ggKCRwYW5lbCBpbiBAKCdOZXdTdGFydFBhbmVsJywnQ2xhc3NpY1N0YXJ0TWVudScpKSB7DQogICAgJGtleSA9ICdIS0NVOlxTb2Z0d2FyZVxNaWNyb3NvZnRcV2luZG93c1xDdXJyZW50VmVyc2lvblxFeHBsb3JlclxIaWRlRGVza3RvcEljb25zXCcgKyAkcGFuZWwNCiAgICBmb3JlYWNoICgkaWQgaW4gQCgnezIwRDA0RkUwLTNBRUEtMTA2OS1BMkQ4LTA4MDAyQjMwMzA5RH0nLCd7NTkwMzFhNDctM2Y3Mi00NGE3LTg5YzUtNTU5NWZlNmIzMGVlfScsJ3tGMDJDMUEwRC1CRTIxLTQzNTAtODhCMC03MzY3RkM5NkVGM0N9JywnezUzOTlFNjk0LTZDRTUtNEQ2Qy04RkNFLTFEODg3MEZEQ0JBMH0nKSkgeyBTZXQtVXNlclZhbHVlICRrZXkgJGlkIDEgfQ0KICAgIFNldC1Vc2VyVmFsdWUgJGtleSAnezY0NUZGMDQwLTUwODEtMTAxQi05RjA4LTAwQUEwMDJGOTU0RX0nIDANCn0NCiMgUmVzdHJpY3RlZCBwb2xpY3kga2V5cyBhcmUgY29uZmlndXJlZCBieSB0aGUgZWxldmF0ZWQgaW5zdGFsbGVyIGJlZm9yZSBmaXJzdCBzaWduLWluLg0KIyBTdGFuZGFyZCB1c2VycyBtdXN0IG5ldmVyIHdyaXRlIHRoZXNlIGtleXM6IGFuIGFjY2VzcyBlcnJvciB3b3VsZCBzdG9wIHRoZSB3YWxscGFwZXIgcmVmcmVzaC4NCiMgTmF0aXZlIHJlZnJlc2ggY2hhbmdlcyBvbmx5IHRoaXMgdXNlcidzIHdhbGxwYXBlciwgbmV2ZXIgYW5vdGhlciBzZXNzaW9uLg0KaWYgKC1ub3QgKCdVRVBMVi5XYWxscGFwZXInIC1hcyBbdHlwZV0pKSB7DQogICAgQWRkLVR5cGUgLVR5cGVEZWZpbml0aW9uICduYW1lc3BhY2UgVUVQTFYgeyBwdWJsaWMgY2xhc3MgV2FsbHBhcGVyIHsgW1N5c3RlbS5SdW50aW1lLkludGVyb3BTZXJ2aWNlcy5EbGxJbXBvcnQoInVzZXIzMi5kbGwiLCBDaGFyU2V0PVN5c3RlbS5SdW50aW1lLkludGVyb3BTZXJ2aWNlcy5DaGFyU2V0LlVuaWNvZGUpXSBwdWJsaWMgc3RhdGljIGV4dGVybiBib29sIFN5c3RlbVBhcmFtZXRlcnNJbmZvKGludCBhY3Rpb24sIGludCBwYXJhbSwgc3RyaW5nIHZhbHVlLCBpbnQgZmxhZ3MpOyB9IH0nDQp9DQppZiAoVGVzdC1QYXRoIC1MaXRlcmFsUGF0aCAkV2FsbHBhcGVyKSB7IFtVRVBMVi5XYWxscGFwZXJdOjpTeXN0ZW1QYXJhbWV0ZXJzSW5mbygyMCwwLCRXYWxscGFwZXIsMykgfCBPdXQtTnVsbCB9DQoNCiMgV2luZG93cyByZXNvbHZlcyB0aGUgb3JpZ2luYWwgdGFza2JhciBwaW4gYmFjayB0byBFZGdlJ3MgZGVmYXVsdCBzaG9ydGN1dC4NCiMgVXBkYXRlIHRoZSBhY3R1YWwgcGVyLXVzZXIgcGluIGFmdGVyIEV4cGxvcmVyIGNyZWF0ZXMgaXQsIHdpdGhvdXQgcmVxdWlyaW5nIGVsZXZhdGlvbi4NCiRwaW5Sb290PUpvaW4tUGF0aCAkZW52OkFQUERBVEEgJ01pY3Jvc29mdFxJbnRlcm5ldCBFeHBsb3JlclxRdWljayBMYXVuY2hcVXNlciBQaW5uZWRcVGFza0JhcicNCiRlZGdlUGlucz1AKCk7JHNoZWxsPU5ldy1PYmplY3QgLUNvbU9iamVjdCBXU2NyaXB0LlNoZWxsDQp0cnkgew0KICAgIGZvcigkYXR0ZW1wdD0wOyRhdHRlbXB0IC1sdCAzMDskYXR0ZW1wdCsrKXsNCiAgICAgICAgJGVkZ2VQaW5zPUAoR2V0LUNoaWxkSXRlbSAtTGl0ZXJhbFBhdGggJHBpblJvb3QgLUZpbHRlciAnKi5sbmsnIC1FcnJvckFjdGlvbiBTaWxlbnRseUNvbnRpbnVlfFdoZXJlLU9iamVjdCB7JHNoZWxsLkNyZWF0ZVNob3J0Y3V0KCRfLkZ1bGxOYW1lKS5UYXJnZXRQYXRoIC1tYXRjaCAnXFxtc2VkZ2VcLmV4ZSQnfSkNCiAgICAgICAgaWYoJGVkZ2VQaW5zLkNvdW50KXticmVha307U3RhcnQtU2xlZXAgLVNlY29uZHMgMQ0KICAgIH0NCiAgICBmb3JlYWNoKCRwaW4gaW4gJGVkZ2VQaW5zKXsNCiAgICAgICAgJGxpbms9JHNoZWxsLkNyZWF0ZVNob3J0Y3V0KCRwaW4uRnVsbE5hbWUpDQogICAgICAgICRsaW5rLkFyZ3VtZW50cz0nLS1uby1maXJzdC1ydW4gLS1uZXctd2luZG93IGh0dHBzOi8vd3d3Lmdvb2dsZS5jb20vJw0KICAgICAgICAkbGluay5JY29uTG9jYXRpb249JGxpbmsuVGFyZ2V0UGF0aCsnLDAnOyRsaW5rLlNhdmUoKQ0KICAgICAgICBpZigkc2hlbGwuQ3JlYXRlU2hvcnRjdXQoJHBpbi5GdWxsTmFtZSkuQXJndW1lbnRzIC1ub3RtYXRjaCAnaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8nKXt0aHJvdyAnUGlubmVkIEVkZ2Ugc3RhcnR1cCBjb3VsZCBub3QgYmUgdmVyaWZpZWQuJ30NCiAgICB9DQp9IGZpbmFsbHkge1tSdW50aW1lLkludGVyb3BTZXJ2aWNlcy5NYXJzaGFsXTo6RmluYWxSZWxlYXNlQ29tT2JqZWN0KCRzaGVsbCl8T3V0LU51bGx9DQoNCltJTy5GaWxlXTo6V3JpdGVBbGxUZXh0KChKb2luLVBhdGggJGxvZ1Jvb3QgJ3VzZXItc2V0dGluZ3MuanNvbicpLChAe1N1Y2Nlc3M9JHRydWU7UGlubmVkRWRnZUdvb2dsZT0oJGVkZ2VQaW5zLkNvdW50IC1ndCAwKTtVc2VyPSRuYW1lO1dhbGxwYXBlcj0kV2FsbHBhcGVyO1V0Yz1bZGF0ZXRpbWVdOjpVdGNOb3cuVG9TdHJpbmcoJ28nKX18Q29udmVydFRvLUpzb24pLFtUZXh0LlVURjhFbmNvZGluZ106Om5ldygkZmFsc2UpKQ0KfSBjYXRjaCB7DQogICAgW0lPLkZpbGVdOjpXcml0ZUFsbFRleHQoKEpvaW4tUGF0aCAkbG9nUm9vdCAndXNlci1zZXR0aW5ncy5qc29uJyksKEB7U3VjY2Vzcz0kZmFsc2U7VXNlcj0kbmFtZTtFcnJvcj0kXy5FeGNlcHRpb24uTWVzc2FnZTtVdGM9W2RhdGV0aW1lXTo6VXRjTm93LlRvU3RyaW5nKCdvJyl9fENvbnZlcnRUby1Kc29uKSxbVGV4dC5VVEY4RW5jb2RpbmddOjpuZXcoJGZhbHNlKSkNCiAgICB0aHJvdw0KfSBmaW5hbGx5IHtTdG9wLVRyYW5zY3JpcHR8T3V0LU51bGx9DQo='))
 if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $expected){throw 'Installed user settings failed integrity verification.'}
}
function Sync-StudentDeviceBaseline {
 $target=Join-Path $env:ProgramFiles 'UEPLV\Management\StudentDeviceBaseline.ps1'
 $expected='13DECAFBCF310E4643C327666D1DC5D5BDF3EAEF86B5318D4CA4C2B3A7E8AAE1'
 if(-not(Test-Path $target) -or (Get-FileHash $target).Hash -ne $expected){[IO.File]::WriteAllBytes($target,[Convert]::FromBase64String('77u/I3JlcXVpcmVzIC1WZXJzaW9uIDUuMQpbQ21kbGV0QmluZGluZygpXQpwYXJhbShbVmFsaWRhdGVTZXQoJ2NsYXNzJywnY2xhc3MtYWknLCdleGFtJywnZnJlZScpXVtzdHJpbmddJE1vZGU9J2NsYXNzJyxbc3dpdGNoXSRMaWJyYXJ5T25seSkKJEVycm9yQWN0aW9uUHJlZmVyZW5jZT0nU3RvcCcKJHNjcmlwdDpCYXNlbGluZVZlcnNpb249JzEuNS40Jwokc2NyaXB0OkJhc2VsaW5lRGVmaW5pdGlvbkhhc2g9KEdldC1GaWxlSGFzaCAtTGl0ZXJhbFBhdGggJFBTQ29tbWFuZFBhdGggLUFsZ29yaXRobSBTSEEyNTYpLkhhc2gKZnVuY3Rpb24gU2V0LUJhc2VsaW5lVmFsdWUoW3N0cmluZ10kUGF0aCxbc3RyaW5nXSROYW1lLCRWYWx1ZSxbc3RyaW5nXSRUeXBlPSdEV29yZCcpewogaWYoLW5vdCAkUGF0aC5TdGFydHNXaXRoKCdIS0xNOlwnLFtTdHJpbmdDb21wYXJpc29uXTo6T3JkaW5hbElnbm9yZUNhc2UpKXt0aHJvdyAnVW5leHBlY3RlZCBtYWNoaW5lLXBvbGljeSBwYXRoLid9CiAka2V5PVtNaWNyb3NvZnQuV2luMzIuUmVnaXN0cnldOjpMb2NhbE1hY2hpbmUuQ3JlYXRlU3ViS2V5KCRQYXRoLlN1YnN0cmluZyg2KSkKIHRyeXska2V5LlNldFZhbHVlKCROYW1lLCRWYWx1ZSxbTWljcm9zb2Z0LldpbjMyLlJlZ2lzdHJ5VmFsdWVLaW5kXTo6JFR5cGUpfWZpbmFsbHl7JGtleS5DbG9zZSgpfQp9CmZ1bmN0aW9uIEdldC1CYXNlbGluZVBvd2VyU2V0dGluZ3MgewogQCgKICBAe0dyb3VwPSc3NTE2Yjk1Zi1mNzc2LTQ0NjQtOGM1My0wNjE2N2Y0MGNjOTknO1NldHRpbmc9JzNjMGJjMDIxLWM4YTgtNGUwNy1hOTczLTZiMTRjYmNiMmI3ZSc7TmFtZT0nRGlzcGxheSd9LAogIEB7R3JvdXA9Jzc1MTZiOTVmLWY3NzYtNDQ2NC04YzUzLTA2MTY3ZjQwY2M5OSc7U2V0dGluZz0nOGVjNGIzYTUtNjg2OC00OGMyLWJlNzUtNGYzMDQ0YmU4OGE3JztOYW1lPSdMb2NrZWQgZGlzcGxheSd9LAogIEB7R3JvdXA9JzIzOGM5ZmE4LTBhYWQtNDFlZC04M2Y0LTk3YmUyNDJjOGYyMCc7U2V0dGluZz0nMjlmNmMxZGItODZkYS00OGM1LTlmZGItZjJiNjdiMWY0NGRhJztOYW1lPSdTbGVlcCd9LAogIEB7R3JvdXA9JzIzOGM5ZmE4LTBhYWQtNDFlZC04M2Y0LTk3YmUyNDJjOGYyMCc7U2V0dGluZz0nOWQ3ODE1YTYtN2VlNC00OTdlLTg4ODgtNTE1YTA1ZjAyMzY0JztOYW1lPSdIaWJlcm5hdGUnfSwKICBAe0dyb3VwPScyMzhjOWZhOC0wYWFkLTQxZWQtODNmNC05N2JlMjQyYzhmMjAnO1NldHRpbmc9JzdiYzRhMmY5LWQ4ZmMtNDQ2OS1iMDdiLTMzZWI3ODVhYWNhMCc7TmFtZT0nVW5hdHRlbmRlZCBzbGVlcCd9LAogIEB7R3JvdXA9JzIzOGM5ZmE4LTBhYWQtNDFlZC04M2Y0LTk3YmUyNDJjOGYyMCc7U2V0dGluZz0nOTRhYzZkMjktNzNjZS00MWE2LTgwOWYtNjM2M2JhMjFiNDdlJztOYW1lPSdIeWJyaWQgc2xlZXAnfSwKICBAe0dyb3VwPSc0Zjk3MWU4OS1lZWJkLTQ0NTUtYThkZS05ZTU5MDQwZTczNDcnO1NldHRpbmc9JzVjYTgzMzY3LTZlNDUtNDU5Zi1hMjdiLTQ3NmIxZDAxYzkzNic7TmFtZT0nTGlkIGNsb3NlJ30sCiAgQHtHcm91cD0nNGY5NzFlODktZWViZC00NDU1LWE4ZGUtOWU1OTA0MGU3MzQ3JztTZXR0aW5nPSc5Njk5NmJjMC1hZDUwLTQ3ZWMtOTIzYi02ZjQxODc0ZGQ5ZWInO05hbWU9J1NsZWVwIGJ1dHRvbid9LAogIEB7R3JvdXA9JzRmOTcxZTg5LWVlYmQtNDQ1NS1hOGRlLTllNTkwNDBlNzM0Nyc7U2V0dGluZz0nNzY0OGVmYTMtZGQ5Yy00ZTNlLWI1NjYtNTBmOTI5Mzg2MjgwJztOYW1lPSdQb3dlciBidXR0b24nfQogKQp9CmZ1bmN0aW9uIFNldC1MYWJBbHdheXNPbiB7CiAkcG93ZXI9Sm9pbi1QYXRoICRlbnY6U3lzdGVtUm9vdCAnU3lzdGVtMzJccG93ZXJjZmcuZXhlJwogJGFjdGl2ZT0oR2V0LUl0ZW1Qcm9wZXJ0eSAnSEtMTTpcU1lTVEVNXEN1cnJlbnRDb250cm9sU2V0XENvbnRyb2xcUG93ZXJcVXNlclxQb3dlclNjaGVtZXMnKS5BY3RpdmVQb3dlclNjaGVtZQogaWYoJGFjdGl2ZSAtbm90bWF0Y2ggJ15bYS1mQS1GMC05LV17MzZ9JCcpe3Rocm93ICdObyBzZSBwdWRvIGxlZXIgZWwgcGxhbiBkZSBlbmVyZ2lhIGFjdGl2by4nfQogJGNoYW5nZWQ9JGZhbHNlCiBmb3JlYWNoKCRpdGVtIGluIEdldC1CYXNlbGluZVBvd2VyU2V0dGluZ3MpewogICRwb2xpY3k9J0hLTE06XFNPRlRXQVJFXFBvbGljaWVzXE1pY3Jvc29mdFxQb3dlclxQb3dlclNldHRpbmdzXCcrJGl0ZW0uU2V0dGluZwogICRzY2hlbWU9J0hLTE06XFNZU1RFTVxDdXJyZW50Q29udHJvbFNldFxDb250cm9sXFBvd2VyXFVzZXJcUG93ZXJTY2hlbWVzXCcrJGFjdGl2ZSsnXCcrJGl0ZW0uR3JvdXArJ1wnKyRpdGVtLlNldHRpbmcKICAkdmFsdWVzPUdldC1JdGVtUHJvcGVydHkgJHNjaGVtZSAtRXJyb3JBY3Rpb24gU2lsZW50bHlDb250aW51ZQogIGZvcmVhY2goJGtpbmQgaW4gQCgnQUMnLCdEQycpKXsKICAgaWYoLW5vdCAkdmFsdWVzIC1vciAkdmFsdWVzLigka2luZCsnU2V0dGluZ0luZGV4JykgLW5lIDApewogICAgJiAkcG93ZXIgKCcvc2V0Jyska2luZC5Ub0xvd2VySW52YXJpYW50KCkrJ3ZhbHVlaW5kZXgnKSAkYWN0aXZlICRpdGVtLkdyb3VwICRpdGVtLlNldHRpbmcgMHxPdXQtTnVsbAogICAgaWYoJExBU1RFWElUQ09ERSAtbmUgMCl7dGhyb3cgKCdObyBzZSBwdWRvIGNvbmZpZ3VyYXIgZW5lcmdpYTogJyskaXRlbS5OYW1lKycgJyska2luZCl9OyRjaGFuZ2VkPSR0cnVlCiAgIH0KICAgU2V0LUJhc2VsaW5lVmFsdWUgJHBvbGljeSAoJGtpbmQrJ1NldHRpbmdJbmRleCcpIDAKICB9CiB9CiBTZXQtQmFzZWxpbmVWYWx1ZSAnSEtMTTpcU09GVFdBUkVcUG9saWNpZXNcTWljcm9zb2Z0XFBvd2VyXFBvd2VyU2V0dGluZ3MnIEFjdGl2ZVBvd2VyU2NoZW1lICRhY3RpdmUgU3RyaW5nCiBTZXQtQmFzZWxpbmVWYWx1ZSAnSEtMTTpcU09GVFdBUkVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cRXhwbG9yZXJcRmx5b3V0TWVudVNldHRpbmdzJyBTaG93U2xlZXBPcHRpb24gMAogU2V0LUJhc2VsaW5lVmFsdWUgJ0hLTE06XFNPRlRXQVJFXE1pY3Jvc29mdFxXaW5kb3dzXEN1cnJlbnRWZXJzaW9uXEV4cGxvcmVyXEZseW91dE1lbnVTZXR0aW5ncycgU2hvd0hpYmVybmF0ZU9wdGlvbiAwCiBpZigoR2V0LUl0ZW1Qcm9wZXJ0eSAnSEtMTTpcU1lTVEVNXEN1cnJlbnRDb250cm9sU2V0XENvbnRyb2xcUG93ZXInIC1FcnJvckFjdGlvbiBTaWxlbnRseUNvbnRpbnVlKS5IaWJlcm5hdGVFbmFibGVkIC1uZSAwKXsmICRwb3dlciAvaGliZXJuYXRlIG9mZnxPdXQtTnVsbDtpZigkTEFTVEVYSVRDT0RFKXt0aHJvdyAnTm8gc2UgcHVkbyBkZXNhY3RpdmFyIGhpYmVybmFjaW9uLid9OyRjaGFuZ2VkPSR0cnVlfQogaWYoJGNoYW5nZWQpeyYgJHBvd2VyIC9zZXRhY3RpdmUgJGFjdGl2ZXxPdXQtTnVsbDtpZigkTEFTVEVYSVRDT0RFKXt0aHJvdyAnTm8gc2UgcHVkbyBhY3RpdmFyIGVsIHBsYW4gZGUgZW5lcmdpYS4nfX0KIHJldHVybiAkYWN0aXZlCn0KZnVuY3Rpb24gR2V0LUJhc2VsaW5lUnVsZUlkKFtzdHJpbmddJFRleHQpeyRzaGE9W1NlY3VyaXR5LkNyeXB0b2dyYXBoeS5TSEEyNTZdOjpDcmVhdGUoKTt0cnl7JGJ5dGVzPSRzaGEuQ29tcHV0ZUhhc2goW1RleHQuRW5jb2RpbmddOjpVVEY4LkdldEJ5dGVzKCdVRVBMVi1iYXNlbGluZS12MTonKyAkVGV4dCkpOyRmaXJzdD1OZXctT2JqZWN0IGJ5dGVbXSAxNjtbQXJyYXldOjpDb3B5KCRieXRlcywkZmlyc3QsMTYpOyhbZ3VpZF06Om5ldygkZmlyc3QpKS5Ub1N0cmluZygpfWZpbmFsbHl7JHNoYS5EaXNwb3NlKCl9fQpmdW5jdGlvbiBBZGQtQmFzZWxpbmVQYXRoUnVsZSgkRG9jdW1lbnQsJENvbGxlY3Rpb24sW3N0cmluZ10kU2lkLFtzdHJpbmddJE5hbWUsW3N0cmluZ10kQWN0aW9uLFtzdHJpbmddJFBhdGgsW3N0cmluZ1tdXSRFeGNlcHRpb25zPUAoKSl7CiAkcnVsZT0kRG9jdW1lbnQuQ3JlYXRlRWxlbWVudCgnRmlsZVBhdGhSdWxlJyk7Zm9yZWFjaCgkcGFpciBpbiBAe0lkPShHZXQtQmFzZWxpbmVSdWxlSWQgKCRDb2xsZWN0aW9uLlR5cGUrJzonKyRTaWQrJzonKyROYW1lKSk7TmFtZT0oJ1VFUExWICcrJE5hbWUpO0Rlc2NyaXB0aW9uPSdVRVBMViBzdHVkZW50IGJhc2VsaW5lIHYxJztVc2VyT3JHcm91cFNpZD0kU2lkO0FjdGlvbj0kQWN0aW9ufS5HZXRFbnVtZXJhdG9yKCkpeyRydWxlLlNldEF0dHJpYnV0ZSgkcGFpci5LZXksJHBhaXIuVmFsdWUpfQogJGNvbmRpdGlvbnM9JERvY3VtZW50LkNyZWF0ZUVsZW1lbnQoJ0NvbmRpdGlvbnMnKTskY29uZGl0aW9uPSREb2N1bWVudC5DcmVhdGVFbGVtZW50KCdGaWxlUGF0aENvbmRpdGlvbicpOyRjb25kaXRpb24uU2V0QXR0cmlidXRlKCdQYXRoJywkUGF0aCk7W3ZvaWRdJGNvbmRpdGlvbnMuQXBwZW5kQ2hpbGQoJGNvbmRpdGlvbik7W3ZvaWRdJHJ1bGUuQXBwZW5kQ2hpbGQoJGNvbmRpdGlvbnMpCiBpZigkRXhjZXB0aW9ucy5Db3VudCl7JGV4Y2VwdD0kRG9jdW1lbnQuQ3JlYXRlRWxlbWVudCgnRXhjZXB0aW9ucycpO2ZvcmVhY2goJHBhdGggaW4gJEV4Y2VwdGlvbnMpeyRub2RlPSREb2N1bWVudC5DcmVhdGVFbGVtZW50KCdGaWxlUGF0aENvbmRpdGlvbicpOyRub2RlLlNldEF0dHJpYnV0ZSgnUGF0aCcsJHBhdGgpO1t2b2lkXSRleGNlcHQuQXBwZW5kQ2hpbGQoJG5vZGUpfTtbdm9pZF0kcnVsZS5BcHBlbmRDaGlsZCgkZXhjZXB0KX0KIFt2b2lkXSRDb2xsZWN0aW9uLkFwcGVuZENoaWxkKCRydWxlKQp9CmZ1bmN0aW9uIEFkZC1CYXNlbGluZVB1Ymxpc2hlclJ1bGUoJERvY3VtZW50LCRDb2xsZWN0aW9uLFtzdHJpbmddJFNpZCxbc3RyaW5nXSROYW1lLFtzdHJpbmddJFB1Ymxpc2hlcixbc3RyaW5nXSRQcm9kdWN0KXsKICRydWxlPSREb2N1bWVudC5DcmVhdGVFbGVtZW50KCdGaWxlUHVibGlzaGVyUnVsZScpO2ZvcmVhY2goJHBhaXIgaW4gQHtJZD0oR2V0LUJhc2VsaW5lUnVsZUlkICgkQ29sbGVjdGlvbi5UeXBlKyc6JyskU2lkKyc6JyskTmFtZSkpO05hbWU9KCdVRVBMViAnKyROYW1lKTtEZXNjcmlwdGlvbj0nVUVQTFYgc3R1ZGVudCBiYXNlbGluZSB2MSc7VXNlck9yR3JvdXBTaWQ9JFNpZDtBY3Rpb249J0FsbG93J30uR2V0RW51bWVyYXRvcigpKXskcnVsZS5TZXRBdHRyaWJ1dGUoJHBhaXIuS2V5LCRwYWlyLlZhbHVlKX0KICRjb25kaXRpb25zPSREb2N1bWVudC5DcmVhdGVFbGVtZW50KCdDb25kaXRpb25zJyk7JGNvbmRpdGlvbj0kRG9jdW1lbnQuQ3JlYXRlRWxlbWVudCgnRmlsZVB1Ymxpc2hlckNvbmRpdGlvbicpOyRjb25kaXRpb24uU2V0QXR0cmlidXRlKCdQdWJsaXNoZXJOYW1lJywkUHVibGlzaGVyKTskY29uZGl0aW9uLlNldEF0dHJpYnV0ZSgnUHJvZHVjdE5hbWUnLCRQcm9kdWN0KTskY29uZGl0aW9uLlNldEF0dHJpYnV0ZSgnQmluYXJ5TmFtZScsJyonKTskdmVyc2lvbnM9JERvY3VtZW50LkNyZWF0ZUVsZW1lbnQoJ0JpbmFyeVZlcnNpb25SYW5nZScpOyR2ZXJzaW9ucy5TZXRBdHRyaWJ1dGUoJ0xvd1NlY3Rpb24nLCcwLjAuMC4wJyk7JHZlcnNpb25zLlNldEF0dHJpYnV0ZSgnSGlnaFNlY3Rpb24nLCcqJyk7W3ZvaWRdJGNvbmRpdGlvbi5BcHBlbmRDaGlsZCgkdmVyc2lvbnMpO1t2b2lkXSRjb25kaXRpb25zLkFwcGVuZENoaWxkKCRjb25kaXRpb24pO1t2b2lkXSRydWxlLkFwcGVuZENoaWxkKCRjb25kaXRpb25zKTtbdm9pZF0kQ29sbGVjdGlvbi5BcHBlbmRDaGlsZCgkcnVsZSkKfQpmdW5jdGlvbiBOZXctTGFiQXBwbGljYXRpb25Qb2xpY3koW3N0cmluZ10kU3R1ZGVudFNpZCxbYm9vbF0kRnJlZSwkUGFja2FnZXMpewogaWYoJFN0dWRlbnRTaWQgLW5vdG1hdGNoICdeUy0xLTUtMjEtXGQrLVxkKy1cZCstXGQrJCcpe3Rocm93ICdTSUQgZGUgZXN0dWRpYW50ZSBpbnZhbGlkby4nfQogW3htbF0kZG9jPSc8QXBwTG9ja2VyUG9saWN5IFZlcnNpb249IjEiIC8+JwogJHByaXZpbGVnZWQ9QCgnUy0xLTUtMzItNTQ0JywnUy0xLTUtMTgnLCdTLTEtNS0xOScsJ1MtMS01LTIwJykKIGZvcmVhY2goJHR5cGUgaW4gQCgnRXhlJywnTXNpJywnU2NyaXB0JywnQXBweCcpKXsKICAkY29sbGVjdGlvbj0kZG9jLkNyZWF0ZUVsZW1lbnQoJ1J1bGVDb2xsZWN0aW9uJyk7JGNvbGxlY3Rpb24uU2V0QXR0cmlidXRlKCdUeXBlJywkdHlwZSk7JGNvbGxlY3Rpb24uU2V0QXR0cmlidXRlKCdFbmZvcmNlbWVudE1vZGUnLCdFbmFibGVkJyk7W3ZvaWRdJGRvYy5Eb2N1bWVudEVsZW1lbnQuQXBwZW5kQ2hpbGQoJGNvbGxlY3Rpb24pCiAgZm9yZWFjaCgkc2lkIGluICRwcml2aWxlZ2VkKXtpZigkdHlwZSAtZXEgJ0FwcHgnKXtBZGQtQmFzZWxpbmVQdWJsaXNoZXJSdWxlICRkb2MgJGNvbGxlY3Rpb24gJHNpZCAoJ3N0YWZmLScrJHNpZCkgJyonICcqJ31lbHNle0FkZC1CYXNlbGluZVBhdGhSdWxlICRkb2MgJGNvbGxlY3Rpb24gJHNpZCAoJ3N0YWZmLScrJHNpZCkgQWxsb3cgJyonfX0KICBpZigkdHlwZSAtZXEgJ0V4ZScpewogICAkdHJ1c3RlZD1AKCclV0lORElSJVwqJywnJVBST0dSQU1GSUxFUyVcKicpCiAgIEFkZC1CYXNlbGluZVBhdGhSdWxlICRkb2MgJGNvbGxlY3Rpb24gJ1MtMS0xLTAnICd0cnVzdGVkIFdpbmRvd3MgYW5kIHN0YWZmLWluc3RhbGxlZCBwcm9ncmFtcycgQWxsb3cgJyVXSU5ESVIlXConCiAgIEFkZC1CYXNlbGluZVBhdGhSdWxlICRkb2MgJGNvbGxlY3Rpb24gJ1MtMS0xLTAnICdzdGFmZi1pbnN0YWxsZWQgcHJvZ3JhbXMnIEFsbG93ICclUFJPR1JBTUZJTEVTJVwqJwogICBBZGQtQmFzZWxpbmVQYXRoUnVsZSAkZG9jICRjb2xsZWN0aW9uICRTdHVkZW50U2lkICdubyBkb3dubG9hZGVkIHBvcnRhYmxlIG9yIFVTQiBwcm9ncmFtcycgRGVueSAnKicgJHRydXN0ZWQKICAgZm9yZWFjaCgkcGF0aCBpbiBAKCclV0lORElSJVxUZW1wXConLCclV0lORElSJVxUYXNrc1wqJywnJVdJTkRJUiVcVHJhY2luZ1wqJywnJVdJTkRJUiVcUmVnaXN0cmF0aW9uXENSTUxvZ1wqJywnJVdJTkRJUiVcU3lzdGVtMzJcc3Bvb2xcKicsJyVXSU5ESVIlXFN5c3RlbTMyXENvbVxkbXBcKicsJyVXSU5ESVIlXFN5c1dPVzY0XENvbVxkbXBcKicsJyVXSU5ESVIlXFN5c3RlbTMyXEZ4c1RtcFwqJywnJVdJTkRJUiVcU3lzdGVtMzJcVGFza3NcKicpKXtBZGQtQmFzZWxpbmVQYXRoUnVsZSAkZG9jICRjb2xsZWN0aW9uICRTdHVkZW50U2lkICgnd3JpdGFibGUgJyskcGF0aCkgRGVueSAkcGF0aH0KICAgZm9yZWFjaCgkYmluYXJ5IGluIEAoJ21zaWV4ZWMuZXhlJywnY21kLmV4ZScsJ3JlZ2VkaXQuZXhlJywncmVnLmV4ZScsJ3dzY3JpcHQuZXhlJywnY3NjcmlwdC5leGUnLCdtc2h0YS5leGUnLCdydW5kbGwzMi5leGUnLCdyZWdzdnIzMi5leGUnLCdpbnN0YWxsdXRpbC5leGUnLCdtc2J1aWxkLmV4ZScsJ2lleHByZXNzLmV4ZScsJ3Bvd2VyY2ZnLmV4ZScpKXsKICAgIEFkZC1CYXNlbGluZVBhdGhSdWxlICRkb2MgJGNvbGxlY3Rpb24gJFN0dWRlbnRTaWQgKCdyZXN0cmljdGVkIGhvc3QgJyskYmluYXJ5KSBEZW55ICgnJVdJTkRJUiVcKlwnKyRiaW5hcnkpCiAgIH0KICAgQWRkLUJhc2VsaW5lUGF0aFJ1bGUgJGRvYyAkY29sbGVjdGlvbiAkU3R1ZGVudFNpZCAncmVnaXN0cnkgZWRpdG9yJyBEZW55ICclV0lORElSJVxyZWdlZGl0LmV4ZScKICAgZm9yZWFjaCgkcGFja2FnZSBpbiBAKCdNaWNyb3NvZnQuRGVza3RvcEFwcEluc3RhbGxlcicsJ01pY3Jvc29mdC5XaW5kb3dzU3RvcmUnKSl7QWRkLUJhc2VsaW5lUGF0aFJ1bGUgJGRvYyAkY29sbGVjdGlvbiAkU3R1ZGVudFNpZCAoJ25vICcrJHBhY2thZ2UrJyBleGVjdXRhYmxlcycpIERlbnkgKCclUFJPR1JBTUZJTEVTJVxXaW5kb3dzQXBwc1wnKyRwYWNrYWdlKycqXConKX0KICAgaWYoLW5vdCAkRnJlZSl7Zm9yZWFjaCgkcGF0aCBpbiBAKCclV0lORElSJVxTeXN0ZW0zMlxUYXNrbWdyLmV4ZScsJyVXSU5ESVIlXFN5c1dPVzY0XFRhc2ttZ3IuZXhlJykpe0FkZC1CYXNlbGluZVBhdGhSdWxlICRkb2MgJGNvbGxlY3Rpb24gJFN0dWRlbnRTaWQgKCdUYXNrIE1hbmFnZXIgJyskcGF0aCkgRGVueSAkcGF0aH19CiAgfWVsc2VpZigkdHlwZSAtZXEgJ01zaScpe0FkZC1CYXNlbGluZVBhdGhSdWxlICRkb2MgJGNvbGxlY3Rpb24gJFN0dWRlbnRTaWQgJ25vIHN0dWRlbnQgTVNJIE1TUCBvciBNU1QgaW5zdGFsbGF0aW9uJyBEZW55ICcqJ30KICBlbHNlaWYoJHR5cGUgLWVxICdTY3JpcHQnKXsKICAgJGhlbHBlcj0nJVBST0dSQU1GSUxFUyVcVUVQTFZcUHJvdmlzaW9uaW5nXEFwcGx5LVVzZXJTZXR0aW5ncy5wczEnCiAgIEFkZC1CYXNlbGluZVBhdGhSdWxlICRkb2MgJGNvbGxlY3Rpb24gJFN0dWRlbnRTaWQgJ3RydXN0ZWQgc2Nob29sIGFwcGVhcmFuY2UgaGVscGVyJyBBbGxvdyAkaGVscGVyCiAgIEFkZC1CYXNlbGluZVBhdGhSdWxlICRkb2MgJGNvbGxlY3Rpb24gJFN0dWRlbnRTaWQgJ25vIHN0dWRlbnQgc2NyaXB0cycgRGVueSAnKicgQCgkaGVscGVyKQogIH1lbHNlewogICBmb3JlYWNoKCRwYWNrYWdlIGluIEAoJFBhY2thZ2VzfFNvcnQtT2JqZWN0IE5hbWUgLVVuaXF1ZSkpewogICAgaWYoJHBhY2thZ2UuTmFtZSAtbm90bWF0Y2ggJ14oTWljcm9zb2Z0XC58TWljcm9zb2Z0V2luZG93c1wufFdpbmRvd3NcLiknIC1vciAkcGFja2FnZS5OYW1lIC1tYXRjaCAnKD9pKVdpbmRvd3NTdG9yZXxTdG9yZVB1cmNoYXNlQXBwfERlc2t0b3BBcHBJbnN0YWxsZXJ8WGJveHxHYW1pbmd8TWluZWNyYWZ0fFNvbGl0YWlyZXxDb3BpbG90fE1pY3Jvc29mdE9mZmljZUh1Yicpe2NvbnRpbnVlfQogICAgQWRkLUJhc2VsaW5lUHVibGlzaGVyUnVsZSAkZG9jICRjb2xsZWN0aW9uICdTLTEtMS0wJyAoJ1dpbmRvd3MgcGFja2FnZSAnKyRwYWNrYWdlLk5hbWUpICRwYWNrYWdlLlB1Ymxpc2hlciAkcGFja2FnZS5OYW1lCiAgIH0KICB9CiB9CiByZXR1cm4gJGRvYwp9CmZ1bmN0aW9uIEludm9rZS1MYWJTdHVkZW50QmFzZWxpbmUoW3N0cmluZ10kU2VsZWN0ZWRNb2RlKXsKICRzdHVkZW50PUdldC1Mb2NhbFVzZXIgLU5hbWUgJ0xFViBWSUdPVFNLWScgLUVycm9yQWN0aW9uIFN0b3AKIGlmKEAoR2V0LUxvY2FsR3JvdXBNZW1iZXIgLVNJRCAnUy0xLTUtMzItNTQ0J3xXaGVyZS1PYmplY3QgeyRfLlNJRC5WYWx1ZSAtZXEgJHN0dWRlbnQuU0lELlZhbHVlfSkuQ291bnQpe3Rocm93ICdMYSBjdWVudGEgZGUgZXN0dWRpYW50ZSBubyBwdWVkZSBzZXIgYWRtaW5pc3RyYWRvcmEuJ30KICRyb290PUpvaW4tUGF0aCAkZW52OlByb2dyYW1EYXRhICdVRVBMVlxNYW5hZ2VtZW50XFNlY3VyaXR5JztbSU8uRGlyZWN0b3J5XTo6Q3JlYXRlRGlyZWN0b3J5KCRyb290KXxPdXQtTnVsbAogSW1wb3J0LU1vZHVsZSBBcHBMb2NrZXIgLUVycm9yQWN0aW9uIFN0b3AKICRwb2xpY3lQYXRoPUpvaW4tUGF0aCAkcm9vdCAnc3R1ZGVudC1wb2xpY3kueG1sJzskc3RhbXBQYXRoPUpvaW4tUGF0aCAkcm9vdCAnYmFzZWxpbmUuanNvbic7JHN0YW1wPSRudWxsCiBpZihUZXN0LVBhdGggJHN0YW1wUGF0aCl7dHJ5eyRzdGFtcD1HZXQtQ29udGVudCAkc3RhbXBQYXRoIC1SYXd8Q29udmVydEZyb20tSnNvbn1jYXRjaHt9fQogJGZyZWU9JFNlbGVjdGVkTW9kZSAtZXEgJ2ZyZWUnCiAkcGxhbj1TZXQtTGFiQWx3YXlzT24KIFNldC1CYXNlbGluZVZhbHVlICdIS0xNOlxTT0ZUV0FSRVxQb2xpY2llc1xNaWNyb3NvZnRcV2luZG93c1xJbnN0YWxsZXInIEFsd2F5c0luc3RhbGxFbGV2YXRlZCAwCiAkcG9saWN5PShHZXQtQXBwTG9ja2VyUG9saWN5IC1Mb2NhbCAtWG1sKQogaWYoLW5vdCAkc3RhbXAgLW9yICRzdGFtcC5WZXJzaW9uIC1uZSAkc2NyaXB0OkJhc2VsaW5lVmVyc2lvbiAtb3IgJHN0YW1wLkRlZmluaXRpb25IYXNoIC1uZSAkc2NyaXB0OkJhc2VsaW5lRGVmaW5pdGlvbkhhc2ggLW9yICRzdGFtcC5TdHVkZW50U2lkIC1uZSAkc3R1ZGVudC5TSUQuVmFsdWUgLW9yIFtib29sXSRzdGFtcC5GcmVlIC1uZSAkZnJlZSAtb3IgJHN0YW1wLlBvbGljeVNIQTI1NiAtbmUgKEdldC1CYXNlbGluZVRleHRIYXNoICRwb2xpY3kpKXsKICBpZigtbm90KFRlc3QtUGF0aCAoSm9pbi1QYXRoICRyb290ICdiZWZvcmUtcG9saWN5LnhtbCcpKSl7W0lPLkZpbGVdOjpXcml0ZUFsbFRleHQoKEpvaW4tUGF0aCAkcm9vdCAnYmVmb3JlLXBvbGljeS54bWwnKSwkcG9saWN5LFtUZXh0LlVURjhFbmNvZGluZ106Om5ldygkZmFsc2UpKX0KICBbeG1sXSRvbGQ9JHBvbGljeQogICRmb3JlaWduPUAoJG9sZC5BcHBMb2NrZXJQb2xpY3kuUnVsZUNvbGxlY3Rpb24uQ2hpbGROb2Rlc3xXaGVyZS1PYmplY3QgeyRfLk5vZGVUeXBlIC1lcSAnRWxlbWVudCcgLWFuZCAkXy5EZXNjcmlwdGlvbiAtbmUgJ1VFUExWIHN0dWRlbnQgYmFzZWxpbmUgdjEnfSkKICBpZigkZm9yZWlnbi5Db3VudCl7dGhyb3cgJ0V4aXN0ZSBvdHJhIGRpcmVjdGl2YSBBcHBMb2NrZXIuIFJldmlzZSBsYSBkaXJlY3RpdmEgbG9jYWwgYW50ZXMgZGUgcmVlbXBsYXphcmxhLid9CiAgJGRvYz1OZXctTGFiQXBwbGljYXRpb25Qb2xpY3kgJHN0dWRlbnQuU0lELlZhbHVlICRmcmVlIEAoR2V0LUFwcHhQYWNrYWdlIC1BbGxVc2VycykKICAkZG9jLlNhdmUoJHBvbGljeVBhdGgpCiAgJGNoZWNrcz1AKChKb2luLVBhdGggJGVudjpTeXN0ZW1Sb290ICdleHBsb3Jlci5leGUnKSwoSm9pbi1QYXRoICR7ZW52OlByb2dyYW1GaWxlcyh4ODYpfSAnTWljcm9zb2Z0XEVkZ2VcQXBwbGljYXRpb25cbXNlZGdlLmV4ZScpKXxXaGVyZS1PYmplY3Qge1Rlc3QtUGF0aCAkX30KICAkZXZhbHVhdGVkPUAoVGVzdC1BcHBMb2NrZXJQb2xpY3kgLVhtbFBvbGljeSAkcG9saWN5UGF0aCAtUGF0aCAkY2hlY2tzIC1Vc2VyICRzdHVkZW50LlNJRC5WYWx1ZSkKICBpZihAKCRldmFsdWF0ZWR8V2hlcmUtT2JqZWN0IFBvbGljeURlY2lzaW9uIC1uZSAnQWxsb3dlZCcpLkNvdW50KXt0aHJvdyAnTGEgZGlyZWN0aXZhIGJsb3F1ZWFyaWEgZWwgZXNjcml0b3JpbyBvIEVkZ2UuJ30KICBTZXQtQXBwTG9ja2VyUG9saWN5IC1YbWxQb2xpY3kgJHBvbGljeVBhdGggLUVycm9yQWN0aW9uIFN0b3AKICAmIHNjLmV4ZSBjb25maWcgYXBwaWRzdmMgc3RhcnQ9IGF1dG98T3V0LU51bGw7aWYoJExBU1RFWElUQ09ERSl7dGhyb3cgJ05vIHNlIHB1ZG8gYWN0aXZhciBBcHBsaWNhdGlvbiBJZGVudGl0eS4nfQogIFN0YXJ0LVNlcnZpY2UgQXBwSURTdmMgLUVycm9yQWN0aW9uIFN0b3AKICBpZigoR2V0LVNlcnZpY2UgQXBwSURTdmMpLlN0YXR1cyAtbmUgJ1J1bm5pbmcnKXt0aHJvdyAnQXBwTG9ja2VyIG5vIGVzdGEgZWplY3V0YW5kb3NlLid9CiAgJHN0YW1wPVtvcmRlcmVkXUB7VmVyc2lvbj0kc2NyaXB0OkJhc2VsaW5lVmVyc2lvbjtEZWZpbml0aW9uSGFzaD0kc2NyaXB0OkJhc2VsaW5lRGVmaW5pdGlvbkhhc2g7U3R1ZGVudFNpZD0kc3R1ZGVudC5TSUQuVmFsdWU7RnJlZT0kZnJlZTtQb2xpY3lTSEEyNTY9KEdldC1CYXNlbGluZVRleHRIYXNoIChHZXQtQXBwTG9ja2VyUG9saWN5IC1Mb2NhbCAtWG1sKSk7UG93ZXJQbGFuPSRwbGFuO1V0Yz1bZGF0ZXRpbWVdOjpVdGNOb3cuVG9TdHJpbmcoJ28nKTtTdHVkZW50SW5zdGFsbGF0aW9uc0Jsb2NrZWQ9JHRydWU7TWFpbnRlbmFuY2VVbnJlc3RyaWN0ZWQ9JHRydWV9CiAgJHN0YW1wfENvbnZlcnRUby1Kc29ufFNldC1Db250ZW50ICRzdGFtcFBhdGggLUVuY29kaW5nIFVURjgKIH0KICMgUmVnaXN0cnkgcG9saWN5IGFsb25lIGlzIGluc3VmZmljaWVudCBhZnRlciBhIHByb3RlY3RlZCByZWJvb3Q6IHJlZnJlc2ggdGhlCiAjIGNvbXB1dGVyIHBvbGljeSBzbyBBcHBsaWNhdGlvbiBJZGVudGl0eSBsb2FkcyB0aGUgY3VycmVudCBlbmZvcmNlZCBydWxlcy4KICYgZ3B1cGRhdGUuZXhlIC90YXJnZXQ6Y29tcHV0ZXIgL2ZvcmNlIC93YWl0OjYwfE91dC1OdWxsCiBpZigkTEFTVEVYSVRDT0RFIC1uZSAwKXt0aHJvdyAnTm8gc2UgcHVkbyBhY3RpdmFyIGxhIGRpcmVjdGl2YSBkZSBhcGxpY2FjaW9uZXMuJ30KIFJlc3RhcnQtU2VydmljZSBBcHBJRFN2YyAtRm9yY2UgLUVycm9yQWN0aW9uIFN0b3AKIChHZXQtU2VydmljZSBBcHBJRFN2YykuV2FpdEZvclN0YXR1cygnUnVubmluZycsW3RpbWVzcGFuXTo6RnJvbVNlY29uZHMoMzApKQogcmV0dXJuICRzdGFtcAp9CmZ1bmN0aW9uIEdldC1CYXNlbGluZVRleHRIYXNoKFtzdHJpbmddJFRleHQpeyRzaGE9W1NlY3VyaXR5LkNyeXB0b2dyYXBoeS5TSEEyNTZdOjpDcmVhdGUoKTt0cnl7KFtCaXRDb252ZXJ0ZXJdOjpUb1N0cmluZygkc2hhLkNvbXB1dGVIYXNoKFtUZXh0LkVuY29kaW5nXTo6VVRGOC5HZXRCeXRlcygkVGV4dCkpKSkuUmVwbGFjZSgnLScsJycpfWZpbmFsbHl7JHNoYS5EaXNwb3NlKCl9fQpmdW5jdGlvbiBQcm90ZWN0LVN0dWRlbnRUYXNrUG9saWN5KFtzdHJpbmddJFBhdGgsW3N0cmluZ10kU3R1ZGVudFNpZCl7CiAkYWNsPVtTZWN1cml0eS5BY2Nlc3NDb250cm9sLlJlZ2lzdHJ5U2VjdXJpdHldOjpuZXcoKTskYWNsLlNldEFjY2Vzc1J1bGVQcm90ZWN0aW9uKCR0cnVlLCRmYWxzZSk7JGFjbC5TZXRPd25lcihbU2VjdXJpdHkuUHJpbmNpcGFsLlNlY3VyaXR5SWRlbnRpZmllcl06Om5ldygnUy0xLTUtMzItNTQ0JykpCiBmb3JlYWNoKCRzaWQgaW4gQCgnUy0xLTUtMTgnLCdTLTEtNS0zMi01NDQnKSl7JGFjbC5BZGRBY2Nlc3NSdWxlKFtTZWN1cml0eS5BY2Nlc3NDb250cm9sLlJlZ2lzdHJ5QWNjZXNzUnVsZV06Om5ldyhbU2VjdXJpdHkuUHJpbmNpcGFsLlNlY3VyaXR5SWRlbnRpZmllcl06Om5ldygkc2lkKSwnRnVsbENvbnRyb2wnLCdDb250YWluZXJJbmhlcml0JywnTm9uZScsJ0FsbG93JykpfQogJGFjbC5BZGRBY2Nlc3NSdWxlKFtTZWN1cml0eS5BY2Nlc3NDb250cm9sLlJlZ2lzdHJ5QWNjZXNzUnVsZV06Om5ldyhbU2VjdXJpdHkuUHJpbmNpcGFsLlNlY3VyaXR5SWRlbnRpZmllcl06Om5ldygkU3R1ZGVudFNpZCksJ1JlYWRLZXknLCdDb250YWluZXJJbmhlcml0JywnTm9uZScsJ0FsbG93JykpCiBTZXQtQWNsIC1MaXRlcmFsUGF0aCAkUGF0aCAtQWNsT2JqZWN0ICRhY2wKfQppZigkTGlicmFyeU9ubHkpe3JldHVybn0KJHByaW5jaXBhbD1bU2VjdXJpdHkuUHJpbmNpcGFsLldpbmRvd3NQcmluY2lwYWxdW1NlY3VyaXR5LlByaW5jaXBhbC5XaW5kb3dzSWRlbnRpdHldOjpHZXRDdXJyZW50KCkKaWYoLW5vdCAkcHJpbmNpcGFsLklzSW5Sb2xlKFtTZWN1cml0eS5QcmluY2lwYWwuV2luZG93c0J1aWx0SW5Sb2xlXTo6QWRtaW5pc3RyYXRvcikpe3Rocm93ICdTZSByZXF1aWVyZW4gcGVybWlzb3MgZGUgTUFJTlRFTkFOQ0UgbyBTWVNURU0uJ30KSW52b2tlLUxhYlN0dWRlbnRCYXNlbGluZSAkTW9kZXxDb252ZXJ0VG8tSnNvbiAtRGVwdGggNAo='))}
 if((Get-FileHash $target).Hash -ne $expected){throw 'Student baseline module failed integrity verification.'}
 return $target
}
function Reset-StudentBrowserSessions {
 if(-not ('UEPLV.ModeEnforcement.StudentBrowsers' -as [type])){
 Add-Type -ReferencedAssemblies @('System.Management','System.Core') -TypeDefinition @'
using System;using System.IO;using System.Linq;using System.Collections.Generic;using System.Diagnostics;using System.Management;using System.Runtime.InteropServices;namespace UEPLV.ModeEnforcement {
  public static class StudentBrowsers {
    const string Student="LEV VIGOTSKY";
    static readonly string[] Essential={"system","idle","registry","smss","csrss","wininit","winlogon","logonui","services","lsass","svchost","fontdrvhost","dwm","explorer","sihost","taskhostw","ctfmon","conhost","dllhost","runtimebroker","shellexperiencehost","startmenuexperiencehost","searchhost","searchapp","textinputhost","applicationframehost","securityhealthsystray","securityhealthservice","widgets","widgetservice","userinit","rdpclip","audiodg","wudfhost","msedgewebview2"};
    [StructLayout(LayoutKind.Sequential)]struct WtsSession {public int SessionID;public IntPtr Station;public int State;}
    [DllImport("wtsapi32.dll",SetLastError=true)]static extern bool WTSEnumerateSessions(IntPtr server,int reserved,int version,out IntPtr sessions,out int count);
    [DllImport("wtsapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool WTSQuerySessionInformation(IntPtr server,int session,int infoClass,out IntPtr buffer,out int bytes);
    [DllImport("wtsapi32.dll")]static extern void WTSFreeMemory(IntPtr buffer);
    static Dictionary<int,string> Sessions(){var result=new Dictionary<int,string>();IntPtr data;int count;if(!WTSEnumerateSessions(IntPtr.Zero,0,1,out data,out count))throw new Exception("Could not enumerate logged-in sessions; no apps were closed");try{int size=Marshal.SizeOf(typeof(WtsSession));for(int i=0;i<count;i++){var s=(WtsSession)Marshal.PtrToStructure(IntPtr.Add(data,i*size),typeof(WtsSession));IntPtr p;int bytes;if(WTSQuerySessionInformation(IntPtr.Zero,s.SessionID,5,out p,out bytes)){try{string user=Marshal.PtrToStringUni(p);if(s.SessionID>0&&string.Equals(user,Student,StringComparison.OrdinalIgnoreCase))result[s.SessionID]=user;}finally{WTSFreeMemory(p);}}}}finally{WTSFreeMemory(data);}return result;}
    static string Owner(int pid){try{using(var p=new ManagementObject("Win32_Process.Handle='"+pid+"'")){using(var owner=p.InvokeMethod("GetOwner",null,null)){return owner!=null&&Convert.ToUInt32(owner["ReturnValue"])==0?Convert.ToString(owner["User"]):null;}}}catch{return null;}}
    static string OwnerSid(int pid){try{using(var p=new ManagementObject("Win32_Process.Handle='"+pid+"'")){using(var owner=p.InvokeMethod("GetOwnerSid",null,null)){return owner!=null&&Convert.ToUInt32(owner["ReturnValue"])==0?Convert.ToString(owner["Sid"]):null;}}}catch{return null;}}
    public static bool SafeToClose(string processName,string fullPath,string owner,string sessionUser,int sessionId){
      if(sessionId<=0||!string.Equals(owner,Student,StringComparison.OrdinalIgnoreCase)||!string.Equals(sessionUser,Student,StringComparison.OrdinalIgnoreCase)||string.IsNullOrEmpty(fullPath))return false;
      string name=(processName??"").ToLowerInvariant();foreach(string files in new[]{Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86)}){if(string.IsNullOrEmpty(files))continue;if(fullPath.StartsWith(Path.Combine(files,"Veyon")+"\\",StringComparison.OrdinalIgnoreCase)||fullPath.StartsWith(Path.Combine(files,"UEPLV")+"\\",StringComparison.OrdinalIgnoreCase))return false;if(Essential.Contains(name)&&(fullPath.StartsWith(Path.Combine(files,"WindowsApps")+"\\",StringComparison.OrdinalIgnoreCase)||fullPath.StartsWith(Path.Combine(files,@"Microsoft\EdgeWebView")+"\\",StringComparison.OrdinalIgnoreCase)))return false;}
      string windows=Environment.GetFolderPath(Environment.SpecialFolder.Windows);if(string.IsNullOrEmpty(windows)||fullPath.StartsWith(windows.TrimEnd('\\')+"\\",StringComparison.OrdinalIgnoreCase))return false;
      return true;
    }
    public static bool SafeToCloseTaskManager(string name,string path,string owner,string sessionUser,int session){return session>0&&string.Equals(name,"taskmgr",StringComparison.OrdinalIgnoreCase)&&string.Equals(owner,Student,StringComparison.OrdinalIgnoreCase)&&string.Equals(sessionUser,Student,StringComparison.OrdinalIgnoreCase)&&(string.Equals(path,Path.Combine(Environment.SystemDirectory,"Taskmgr.exe"),StringComparison.OrdinalIgnoreCase)||string.Equals(path,Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),@"SysWOW64\Taskmgr.exe"),StringComparison.OrdinalIgnoreCase));}
    public static string Close(string[] onlyNames=null,bool closeTaskManager=false){var sessions=Sessions();if(sessions.Count==0)return "No LEV VIGOTSKY student session is signed in; no apps closed";string localSid=((System.Security.Principal.SecurityIdentifier)new System.Security.Principal.NTAccount(Environment.MachineName,Student).Translate(typeof(System.Security.Principal.SecurityIdentifier))).Value;int closed=0,failed=0,protectedCount=0;var candidates=new List<Process>();
      foreach(var p in Process.GetProcesses()){try{string sessionUser;if(!sessions.TryGetValue(p.SessionId,out sessionUser)||(onlyNames!=null&&!onlyNames.Contains(p.ProcessName,StringComparer.OrdinalIgnoreCase))){p.Dispose();continue;}string path=p.MainModule.FileName;if(OwnerSid(p.Id)!=localSid||!SafeToClose(p.ProcessName,path,Owner(p.Id),sessionUser,p.SessionId)){protectedCount++;p.Dispose();continue;}candidates.Add(p);}catch{p.Dispose();protectedCount++;}}
      foreach(var p in candidates){try{string sessionUser;if(p.HasExited)continue;if(!sessions.TryGetValue(p.SessionId,out sessionUser)||OwnerSid(p.Id)!=localSid||!(SafeToClose(p.ProcessName,p.MainModule.FileName,Owner(p.Id),sessionUser,p.SessionId)||(closeTaskManager&&SafeToCloseTaskManager(p.ProcessName,p.MainModule.FileName,Owner(p.Id),sessionUser,p.SessionId)))){protectedCount++;continue;}bool requested=p.CloseMainWindow();if(requested&&p.WaitForExit(2000)){closed++;continue;}if(!p.HasExited){p.Kill();if(!p.WaitForExit(3000)){failed++;continue;}}closed++;}catch{failed++;}finally{p.Dispose();}}
      string detail="Closed "+closed+" student application processes; "+failed+" could not close. Windows, Veyon, management and staff processes were preserved ("+protectedCount+" protected/skipped). Unsaved student work may be lost.";if(failed>0)throw new Exception(detail);return detail;
    }
    public static string CloseBrowsers(){
      var names=new[]{"msedge","chrome","firefox","brave","opera","opera_gx","chromium","vivaldi","waterfox","librewolf","iexplore"};
      string detail=Close(names);
      var sessions=Sessions();string sid=((System.Security.Principal.SecurityIdentifier)new System.Security.Principal.NTAccount(Environment.MachineName,Student).Translate(typeof(System.Security.Principal.SecurityIdentifier))).Value;
      foreach(var p in Process.GetProcesses())using(p){try{if(!names.Contains(p.ProcessName,StringComparer.OrdinalIgnoreCase)||!sessions.ContainsKey(p.SessionId)||p.HasExited)continue;if(OwnerSid(p.Id)==sid&&!p.HasExited)throw new InvalidOperationException("A student browser is still running; mode switch was not confirmed");}catch(InvalidOperationException){throw;}catch{} }
      return detail;
    }  }

}
'@
 }
 [UEPLV.ModeEnforcement.StudentBrowsers]::CloseBrowsers()
}
function Update-OwnedHosts([string[]]$Domains,[string]$Path=(Join-Path $env:windir 'System32\drivers\etc\hosts')){
 $lines=[Collections.Generic.List[string]]::new()
 for($readAttempt=0;$readAttempt -lt 12;$readAttempt++){
  $input=$null;$reader=$null
  try{
   $input=[IO.File]::Open($path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
   $reader=[IO.StreamReader]::new($input,[Text.Encoding]::UTF8,$true)
   while(($line=$reader.ReadLine()) -ne $null){$lines.Add($line)}
   break
  }catch{if(($_.Exception.GetBaseException().HResult -band 65535) -notin @(32,33) -or $readAttempt -eq 11){throw};$lines.Clear();Start-Sleep -Milliseconds 250}
  finally{if($reader){$reader.Dispose()}elseif($input){$input.Dispose()}}
 }
 $kept=[Collections.Generic.List[string]]::new();$block=$null
 $starts=@('# BEGIN UEPLV_MANAGEMENT','# BEGIN LEV_VIGOTSKY_GUARD','# BEGIN LEV_VIGOTSKY_CLASS_AI_EXTRA','# BEGIN LEV_VIGOTSKY_EXAM_EXTRA')
 foreach($line in $lines){if($starts -contains $line.Trim()){if($block){throw 'Nested managed hosts blocks require staff review.'};$block=$line.Trim().Replace('# BEGIN ','# END ');continue};if($block){if($line.Trim() -eq $block){$block=$null};continue};$kept.Add($line)}
 if($block){throw 'An incomplete managed hosts block requires staff review.'}
 if($Domains.Count){$kept.Add('# BEGIN UEPLV_MANAGEMENT');foreach($domain in $Domains){$kept.Add('0.0.0.0 '+$domain);$kept.Add('0.0.0.0 www.'+$domain)};$kept.Add('# END UEPLV_MANAGEMENT')}
 $attributes=[IO.File]::GetAttributes($path)
 $bytes=[Text.UTF8Encoding]::new($false).GetBytes(($kept.ToArray() -join "`r`n")+"`r`n")
 for($attempt=0;$attempt -lt 12;$attempt++){
  $stream=$null;$attributesModified=$false
  try{
   if($attributes -band [IO.FileAttributes]::ReadOnly){[IO.File]::SetAttributes($path,($attributes -band (-bnot [IO.FileAttributes]::ReadOnly)));$attributesModified=$true}
   $stream=[IO.File]::Open($path,[IO.FileMode]::Open,[IO.FileAccess]::Write,[IO.FileShare]::ReadWrite)
   $stream.Position=0;$stream.Write($bytes,0,$bytes.Length);$stream.SetLength($bytes.Length);$stream.Flush($true);break
  }catch{
   $native=$_.Exception.GetBaseException().HResult -band 65535
   if($native -notin @(32,33) -or $attempt -eq 11){throw}
   Start-Sleep -Milliseconds 250
  }finally{if($stream){$stream.Dispose()};if($attributesModified){[IO.File]::SetAttributes($path,$attributes)}}
 }
}
try {
 if($Action -in @('class','class-ai','exam','free')){
  $browserResetRequired=$true
  Sync-InstalledUserSettings
  $baselineModule=Sync-StudentDeviceBaseline
  . $baselineModule -LibraryOnly
  Invoke-LabStudentBaseline $Action|Out-Null
  $student=Get-Student;$hive='Registry::HKEY_USERS\'+$student.Sid;$loaded=$false
  if(-not(Test-Path -LiteralPath $hive)){Run-Native reg.exe @('load',('HKU\'+$student.Sid),(Join-Path $student.Root 'NTUSER.DAT'))|Out-Null;$loaded=$true}
  try {
   $task=$hive+'\Software\Microsoft\Windows\CurrentVersion\Policies\System';$explorer=$hive+'\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer';$deny=$explorer+'\DisallowRun';$msi='HKLM:\Software\Policies\Microsoft\Windows\Installer'
   # Repair the known school appearance values removed by older registry writers.
   # These remain part of the classroom baseline in every browsing mode.
   if(-not(Test-Path -LiteralPath $task)){New-Item -Path $task -Force|Out-Null}
   New-ItemProperty -LiteralPath $task -Name Wallpaper -Value (Join-Path $env:ProgramFiles 'UEPLV\Provisioning\Wallpaper.png') -PropertyType String -Force|Out-Null
   New-ItemProperty -LiteralPath $task -Name WallpaperStyle -Value '10' -PropertyType String -Force|Out-Null
   Restore-OwnedRegistryValue $msi DisableMSI
   if($Action -eq 'free'){Set-OwnedRegistryValue $task DisableTaskMgr 0;Restore-OwnedRegistryValue $explorer DisallowRun;Restore-OwnedRegistryValue $deny '9001';Restore-OwnedRegistryValue $deny '9002'}else{Set-OwnedRegistryValue $task DisableTaskMgr 1;Set-OwnedRegistryValue $explorer DisallowRun 1;Set-OwnedRegistryValue $deny '9001' 'RobloxPlayerBeta.exe' String;Set-OwnedRegistryValue $deny '9002' 'RobloxPlayerLauncher.exe' String}
   Set-OwnedRegistryValue $explorer NoClose 0
   Set-OwnedRegistryValue $explorer NoLogoff 0
   Set-OwnedRegistryValue $explorer StartMenuLogOff 0
   foreach($browser in @('Microsoft\Edge','Google\Chrome')){$extensions=$hive+'\Software\Policies\'+$browser+'\ExtensionInstallBlocklist';Set-OwnedRegistryValue $extensions '1' '*' String;Protect-StudentTaskPolicy $extensions $student.Sid}
   $edgePolicy=$hive+'\Software\Policies\Microsoft\Edge'
   Set-OwnedRegistryValue $edgePolicy WebAppInstallByUserEnabled 0
   Protect-StudentTaskPolicy $edgePolicy $student.Sid
   $installerPolicy=$hive+'\Software\Policies\Microsoft\Windows\Installer'
   Set-OwnedRegistryValue $installerPolicy AlwaysInstallElevated 0
   Protect-StudentTaskPolicy $installerPolicy $student.Sid
   $screen=$hive+'\Software\Policies\Microsoft\Windows\Control Panel\Desktop'
   Set-OwnedRegistryValue $screen ScreenSaveActive '0' String
   Protect-StudentTaskPolicy $screen $student.Sid
   Protect-StudentTaskPolicy $task $student.Sid
   Protect-StudentTaskPolicy $explorer $student.Sid
  }finally{if($loaded){[GC]::Collect();[GC]::WaitForPendingFinalizers();Run-Native reg.exe @('unload',('HKU\'+$student.Sid))|Out-Null}}
  $domains=@();if($Action -ne 'free'){$domains=@($classGames+$classSocial+$classAdult);if($Action -in @('class-ai','exam')){$domains+= $ai};if($Action -eq 'exam'){$domains+=$examWeb};$domains=@($domains|Select-Object -Unique)}
  $agentRecord=$null
  for($attempt=0;$attempt -lt 20;$attempt++){
   $reader=$null
   try{
    $stream=[IO.FileStream]::new((Join-Path $env:ProgramData 'UEPLV\Management\agent-state.json'),[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
    $reader=[IO.StreamReader]::new($stream,[Text.Encoding]::UTF8,$true)
    $agentRecord=$reader.ReadToEnd()|ConvertFrom-Json
    if(-not $agentRecord.deviceId -or -not $agentRecord.computerName){throw 'Incomplete agent state'}
    break
   }catch{if($attempt -eq 19){throw};Start-Sleep -Milliseconds 100}finally{if($reader){$reader.Dispose()}}
  }
  if($agentRecord.PSObject.Properties['websitePolicy'] -and $agentRecord.websitePolicy -and $Action -ne 'free'){
   $field=if($Action -eq 'exam'){'examDomains'}elseif($Action -eq 'class-ai'){'aiDomains'}else{'classDomains'}
   $domains=@($agentRecord.websitePolicy.$field)
   if($domains.Count -gt 90 -or @($domains|Where-Object {$_ -cnotmatch '^([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$'}).Count){throw 'Invalid managed website policy'}
   $patterns=@()
  }
  $nextUrls=@(if($Action -ne 'free'){$domains+$patterns|Select-Object -Unique})
  $browserResetRequired=$false
  foreach($browserKey in @('HKLM:\SOFTWARE\Policies\Microsoft\Edge\URLBlocklist','HKLM:\SOFTWARE\Policies\Google\Chrome\URLBlocklist')){
   $previous=@();if(Test-Path $browserKey){$key=Get-Item $browserKey;try{foreach($n in 9001..9099){$value=$key.GetValue([string]$n);if($value){$previous+=[string]$value}}}finally{$key.Close()}}
   if($previous -notcontains '*' -and @($nextUrls|Where-Object {$_ -notin $previous}).Count){$browserResetRequired=$true}
  }
  if($nextUrls.Count -gt 0 -and (-not $agentRecord.PSObject.Properties['policiesApplied'] -or -not $agentRecord.policiesApplied) -and (-not $agentRecord.PSObject.Properties['previousPolicyVerified'] -or -not $agentRecord.previousPolicyVerified)){$browserResetRequired=$true}
  if($browserResetRequired){$initialBrowsers=Reset-StudentBrowserSessions}
  Update-OwnedHosts $domains
  foreach($browser in @('HKLM:\SOFTWARE\Policies\Microsoft\Edge\URLBlocklist','HKLM:\SOFTWARE\Policies\Google\Chrome\URLBlocklist')){
   foreach($n in 9001..9099){Restore-OwnedRegistryValue $browser ([string]$n)}
   if($Action -ne 'free'){
    $urls=@($domains+$patterns|Select-Object -Unique);$n=9001
    foreach($url in $urls){if($n -gt 9099){throw 'Managed browser policy range exhausted.'};Set-OwnedRegistryValue $browser ([string]$n) $url String;$n++}
    if($urls.Count){$key=Get-Item -LiteralPath $browser;try{for($i=0;$i -lt $urls.Count;$i++){if($key.GetValue([string](9001+$i)) -cne $urls[$i]){throw 'Browser blocklist verification failed.'}}}finally{$key.Close()}}
   }
  }
  Run-Native ipconfig.exe @('/flushdns')|Out-Null
  if($browserResetRequired){$browserResult=Reset-StudentBrowserSessions;$result.detail='Mode '+$Action+' applied; tighter restrictions verified after closing student browsers. '+$browserResult}else{$result.detail='Mode '+$Action+' applied; browser windows and tabs preserved (no added restrictions).'}
 } elseif($Action -eq 'browser-cleanup') {
  $feature=Get-WindowsOptionalFeature -Online -FeatureName Client-UnifiedWriteFilter
  if($feature.State -eq 'EnablePending' -or $feature.State -eq 'DisablePending'){throw 'UWF feature restart is pending.'}
  if($feature.State -eq 'Enabled'){$privacyUwf=Uwf-State;if($privacyUwf.current -or $privacyUwf.servicing){throw 'Browser baseline cleanup requires current-session UWF disabled and no servicing.'}}
  Reset-StudentBrowserSessions|Out-Null
  $student=Get-Student
  foreach($relative in @('AppData\Local\Microsoft\Edge\User Data','AppData\Local\Google\Chrome\User Data','AppData\Local\BraveSoftware\Brave-Browser\User Data','AppData\Local\Vivaldi\User Data','AppData\Roaming\Opera Software\Opera Stable','AppData\Roaming\Opera Software\Opera GX Stable')){
   $browserRoot=Join-Path $student.Root $relative;if(-not(Test-Path -LiteralPath $browserRoot)){continue}
   $browserLease=Get-CleanupLease $browserRoot $student.Root
   try{
    $profiles=@((Get-Item -LiteralPath $browserRoot -Force))+@(Get-ChildItem -LiteralPath $browserRoot -Directory -Force)
    foreach($profile in $profiles){
     $profileLease=Get-CleanupLease $profile.FullName $student.Root
     try{foreach($file in @('History','History-journal','History-wal','History-shm','Cookies','Cookies-journal','Cookies-wal','Cookies-shm','Network\Cookies','Network\Cookies-journal','Network\Cookies-wal','Network\Cookies-shm','Visited Links','Top Sites','Top Sites-journal','Shortcuts','Shortcuts-journal')){Delete-CheckedFile (Join-Path $profile.FullName $file) $student.Root}
      foreach($cache in @('Session Storage','Sessions','Local Storage','IndexedDB')){Clear-CheckedDirectory (Join-Path $profile.FullName $cache) $student.Root}
     }finally{Close-CleanupLease $profileLease}
    }
   }finally{Close-CleanupLease $browserLease}
  }
  foreach($relative in @('AppData\Roaming\Mozilla\Firefox\Profiles','AppData\Roaming\Waterfox\Profiles','AppData\Roaming\librewolf\Profiles')){
   $base=Join-Path $student.Root $relative;if(-not(Test-Path -LiteralPath $base)){continue}
   $browserLease=Get-CleanupLease $base $student.Root
   try{foreach($profile in Get-ChildItem -LiteralPath $base -Directory -Force){$profileLease=Get-CleanupLease $profile.FullName $student.Root
    try{[UEPLV.CheckedDelete]::FirefoxHistory((Join-Path $profile.FullName 'places.sqlite'),$student.Root)
     foreach($file in @('cookies.sqlite','cookies.sqlite-wal','cookies.sqlite-shm','sessionstore.jsonlz4','sessionstore.js')){Delete-CheckedFile (Join-Path $profile.FullName $file) $student.Root}
     foreach($cache in @('sessionstore-backups','storage\default')){Clear-CheckedDirectory (Join-Path $profile.FullName $cache) $student.Root}
    }finally{Close-CleanupLease $profileLease}
   }}finally{Close-CleanupLease $browserLease}
  }
  foreach($relative in @('AppData\Roaming\Microsoft\Windows\Cookies','AppData\Local\Microsoft\Windows\INetCookies','AppData\Local\Microsoft\Windows\History','AppData\Local\Microsoft\Windows\WebCache')){Clear-CheckedDirectory (Join-Path $student.Root $relative) $student.Root}
  Reset-StudentBrowserSessions|Out-Null
  if($script:CleanupSkippedBusy.Count -or $script:CleanupSkippedLinks.Count){throw 'Browser data could not be completely cleared; protection must wait for review.'}
  $result.detail='Student browser cookies, browsing history and web sessions cleared on the unprotected volume. Student files, bookmarks, saved passwords and MAINTENANCE were preserved.'
 } elseif($Action -eq 'cleanup') {
  $student=Get-Student
  foreach($folder in @('Downloads','Documents','Music','Videos','Pictures','AppData\Local\Microsoft\Windows\INetCache','AppData\Local\Microsoft\Windows\History','AppData\Roaming\Microsoft\Windows\Cookies','AppData\Local\Microsoft\Windows\WebCache')){Clear-CheckedDirectory (Join-Path $student.Root $folder) $student.Root}
  foreach($relative in @('AppData\Local\Google\Chrome\User Data','AppData\Local\Microsoft\Edge\User Data','AppData\Local\BraveSoftware\Brave-Browser\User Data','AppData\Roaming\Opera Software\Opera Stable')){
   $browserRoot=Join-Path $student.Root $relative;if(-not(Test-Path -LiteralPath $browserRoot)){continue};$browserLease=Get-CleanupLease $browserRoot $student.Root
   try{$dirs=@((Get-Item -LiteralPath $browserRoot -Force))+@(Get-ChildItem -LiteralPath $browserRoot -Directory -Force)
    foreach($dir in $dirs){$profileLease=Get-CleanupLease $dir.FullName $student.Root;try{foreach($file in @('History','History-journal','Cookies','Cookies-journal','Login Data','Login Data-journal','Visited Links','Top Sites','Top Sites-journal','Web Data','Web Data-journal','Network\Cookies','Network\Cookies-journal')){Delete-CheckedFile (Join-Path $dir.FullName $file) $student.Root};foreach($cache in @('Cache','Code Cache','GPUCache','Session Storage','Local Storage')){Clear-CheckedDirectory (Join-Path $dir.FullName $cache) $student.Root}}finally{Close-CleanupLease $profileLease}}
   }finally{Close-CleanupLease $browserLease}
  }
  foreach($relative in @('AppData\Roaming\Mozilla\Firefox\Profiles','AppData\Local\Mozilla\Firefox\Profiles')){$base=Join-Path $student.Root $relative;if(Test-Path -LiteralPath $base){$browserLease=Get-CleanupLease $base $student.Root;try{foreach($dir in Get-ChildItem -LiteralPath $base -Directory -Force){$profileLease=Get-CleanupLease $dir.FullName $student.Root;try{foreach($file in @('cookies.sqlite','cookies.sqlite-wal','cookies.sqlite-shm','places.sqlite','places.sqlite-wal','places.sqlite-shm','formhistory.sqlite')){Delete-CheckedFile (Join-Path $dir.FullName $file) $student.Root};foreach($cache in @('cache2','startupCache')){Clear-CheckedDirectory (Join-Path $dir.FullName $cache) $student.Root}}finally{Close-CleanupLease $profileLease}}}finally{Close-CleanupLease $browserLease}}}
  foreach($drive in Get-PSDrive -PSProvider FileSystem|Where-Object {$_.Root -match '^[A-Z]:\\$'}){$bin=Join-Path $drive.Root ('$Recycle.Bin\'+$student.Sid);if(Test-Path -LiteralPath $bin){Clear-CheckedDirectory $bin (Join-Path $drive.Root '$Recycle.Bin')}}
  $result.detail='Student Downloads/Documents/Music/Videos/Pictures, browser history/cache and that student SID recycle-bin contents cleaned. MAINTENANCE and other user profiles preserved. UWF may restore protected baseline files after reboot.'
 } elseif($Action -in @('status','uwf-status')) {
  $result.detail=(Uwf-State|ConvertTo-Json -Compress)
 } elseif($Action -eq 'uwf-enable') {
  $script=Join-Path $env:ProgramData 'UEPLV\Deployment\Provisioning\Finish-Protection.ps1';if(-not(Test-Path -LiteralPath $script)){throw 'The verified deployment finalizer is missing.'}
  $code=Run-Native powershell.exe @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$script,'-Stage','Enable') @(0,3010)
  $result.restartRequired=($code -eq 3010);$result.detail='Readiness checks passed; UWF '+$(if($code -eq 3010){'scheduled for the next restart, not yet active.'}else{'already active or ready.'})
 } elseif($Action -eq 'uwf-disable') {
  if((Uwf-State).servicing){throw 'UWF servicing is active or scheduled; disabling protection is deferred until servicing completes.'}
  Run-Native uwfmgr.exe @('filter','disable')|Out-Null;Run-Native uwfmgr.exe @('volume','unprotect','C:')|Out-Null
  $s=Uwf-State;if($s.next -or $s.nextC){throw 'Next-session UWF disable could not be verified.'};$result.restartRequired=$s.current;$result.detail='UWF disabled and C: unprotected for the next boot; current protection changes only after restart.'
 } elseif($Action -eq 'uwf-purge-swap') {
  Require-Unprotected;$path=$env:SystemDrive+'\uwfswap.sys';if(Test-Path -LiteralPath $path){$item=Get-Item -LiteralPath $path -Force;if($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Swap path is not an ordinary file.'};[IO.File]::SetAttributes($path,[IO.FileAttributes]::Normal);[IO.File]::Delete($path)};$result.detail='Verified current/next UWF disabled; exact inactive C:\uwfswap.sys removed if present.'
 } elseif($Action -eq 'uwf-repair') {
  Require-Unprotected;$code=Run-Native dism.exe @('/Online','/Cleanup-Image','/RestoreHealth') @(0,3010)
  if($code -eq 3010){$result.restartRequired=$true;$result.detail='DISM repaired the image and requested a restart. Run Repair again after restart to finish SFC. No driver startup values or LowerFilters were edited.'}else{Run-Native sfc.exe @('/scannow')|Out-Null;$result.detail='DISM RestoreHealth and SFC completed while UWF was disabled. No driver startup values or LowerFilters were edited.'}
 } elseif($Action -eq 'uwf-reset-stage1') {
  Require-Unprotected; $code=Run-Native dism.exe @('/Online','/Disable-Feature','/FeatureName:Client-UnifiedWriteFilter','/NoRestart') @(0,3010);$result.resetPhase='feature-disabled';$result.restartRequired=$true;$result.detail='UWF feature removal requested. Restart is required before stage 2.'
 } elseif($Action -eq 'uwf-reset-stage2') {
  Require-Unprotected;$code=Run-Native dism.exe @('/Online','/Enable-Feature','/FeatureName:Client-UnifiedWriteFilter','/All','/NoRestart') @(0,3010);$result.resetPhase='feature-reinstalled';$result.restartRequired=$true;$result.detail='UWF feature reinstalled. Restart and verify before separately enabling protection.'
 } elseif($Action -eq 'windows-update') {
  Require-Unprotected;$script=Join-Path $env:ProgramData 'UEPLV\Deployment\Provisioning\Update-BeforeProtection.ps1';if(-not(Test-Path -LiteralPath $script)){throw 'Verified Windows Update helper is missing.'}
  $code=Run-Native powershell.exe @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$script) @(0,2,3010);$result.restartRequired=($code -eq 3010);$result.needsUpdateCheck=($code -eq 2);$result.detail=if($code -eq 2){'Additional software updates remain; run the update action again.'}elseif($code -eq 3010){'Updates or pending operations require a restart, then another update check.'}else{'Required software update installation and follow-up scan passed.'}
 }
 if($Action -eq 'cleanup' -and $script:CleanupSkippedLinks.Count){$result.detail+=' Skipped '+$script:CleanupSkippedLinks.Count+' links/junctions without traversing them.'}
 if($Action -eq 'cleanup' -and $script:CleanupSkippedBusy.Count){$result.detail+=' '+$script:CleanupSkippedBusy.Count+' cache items remain locked by Windows; other files were cleaned. Restart clears protected-session changes.'}
 $result.success=$true
} catch {$result.detail=$_.Exception.Message}
$result|ConvertTo-Json -Compress -Depth 6
if(-not $result.success){exit 1}
