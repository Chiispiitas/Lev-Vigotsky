﻿#Requires -RunAsAdministrator
[CmdletBinding()]
param(
  [Parameter(Mandatory)][ValidatePattern('^UEPLV-(0[1-9]|[12][0-9]|3[0-3])$')][string]$ComputerName,
  [string]$PayloadRoot,
  [string]$EnrollmentFile,
  [switch]$ValidateOnly
)
$ErrorActionPreference='Stop'
if(-not $PayloadRoot){$PayloadRoot=$PSScriptRoot}
if(!$EnrollmentFile){$EnrollmentFile=Join-Path $PayloadRoot ('Enrollment\'+$ComputerName+'.json')}
$sourceExe=Join-Path $PayloadRoot 'bin\UEPLV.Management.exe'
$sourceAction=Join-Path $PayloadRoot 'Actions\Invoke-LabAction.ps1'
$updateInstaller=Join-Path $PayloadRoot 'Update\Install-AutoUpdate.ps1'
foreach($f in @($EnrollmentFile,$sourceExe,$sourceAction,$updateInstaller,(Join-Path $PayloadRoot 'Update\release-public.xml'))){if(!(Test-Path -LiteralPath $f -PathType Leaf)){throw "Required management file is missing: $f"}}
$profile=Get-Content -LiteralPath $EnrollmentFile -Raw | ConvertFrom-Json
if($profile.name -cne $ComputerName -or ([Convert]::FromBase64String($profile.key)).Length -ne 64){throw 'Enrollment profile does not match the selected computer.'}
if($profile.cloudUrl){
 $uri=$null
 if(-not [Uri]::TryCreate([string]$profile.cloudUrl,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -ne 'https' -or $uri.AbsolutePath -ne '/api/agent/poll' -or $uri.UserInfo -or $uri.Query -or $uri.Fragment){throw 'Cloud endpoint must be an HTTPS /api/agent/poll URL.'}
 if(-not $profile.cloudKey -or $profile.cloudKey -ceq $profile.key -or ([Convert]::FromBase64String($profile.cloudKey)).Length -ne 64){throw 'Cloud enrollment requires its own distinct 64-byte credential.'}
}
$public=New-Object Security.Cryptography.RSACryptoServiceProvider
$public.PersistKeyInCsp=$false
try{$public.FromXmlString($profile.discoveryPublicKey);if(!$public.PublicOnly){throw 'Agent must receive a public discovery key only.'}}finally{$public.Dispose()}
if($ValidateOnly){Write-Output 'Agent payload and assigned profile validated; no system changes.';return}
# Configuration/executable changes must reach the real disk, not a temporary UWF overlay.
$feature=Get-WindowsOptionalFeature -Online -FeatureName Client-UnifiedWriteFilter
if($feature.State -in @('EnablePending','DisablePending')){throw 'Complete the pending UWF feature restart before installing/upgrading management.'}
if($feature.State -eq 'Enabled'){
 $filter=Get-CimInstance -Namespace 'root\standardcimv2\embedded' -ClassName UWF_Filter
 $servicing=@(Get-CimInstance -Namespace 'root\standardcimv2\embedded' -ClassName UWF_Servicing|Where-Object ServicingEnabled)
 if($filter.CurrentEnabled -or $filter.NextEnabled -or $servicing.Count){throw 'Disable UWF and restart before upgrading management; current/next protection or servicing is active.'}
}
$stateRoot=Join-Path $env:ProgramData 'UEPLV\Management'
$programRoot=Join-Path $env:ProgramFiles 'UEPLV\Management'
New-Item -ItemType Directory -Path $stateRoot,$programRoot -Force | Out-Null
& icacls.exe $stateRoot /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null
if($LASTEXITCODE -ne 0){throw 'Could not protect management credentials.'}
$existing=Get-Service -Name UEPLVAgent -ErrorAction SilentlyContinue
if($existing){Stop-Service UEPLVAgent -Force -ErrorAction Stop}
$statePath=Join-Path $stateRoot 'agent-state.json'
$configPath=Join-Path $stateRoot 'agent-config.json'
if(Test-Path -LiteralPath $configPath){
  $old=Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
  if($old.name -cne $profile.name -or $old.key -cne $profile.key){throw 'Installed identity differs; refusing to overwrite it silently.'}
}
Copy-Item -LiteralPath $sourceExe -Destination (Join-Path $programRoot 'UEPLV.Management.exe') -Force
New-Item -ItemType Directory -Path (Join-Path $programRoot 'Actions') -Force | Out-Null
Copy-Item -LiteralPath $sourceAction -Destination (Join-Path $programRoot 'Actions\Invoke-LabAction.ps1') -Force
New-Item -ItemType Directory -Path (Join-Path $programRoot 'Tests') -Force|Out-Null
Copy-Item -LiteralPath (Join-Path $PayloadRoot 'Tests\crypto-fixture.json') -Destination (Join-Path $programRoot 'Tests\crypto-fixture.json') -Force
Copy-Item -LiteralPath $EnrollmentFile -Destination $configPath -Force
Get-ChildItem -LiteralPath $programRoot -Recurse -File | ForEach-Object { $_.IsReadOnly=$false }
(Get-Item -LiteralPath $configPath).IsReadOnly=$false
if(!(Test-Path -LiteralPath $statePath)){
  $state=[ordered]@{computerName=$ComputerName;deviceId=[Guid]::NewGuid().ToString();mode='class';policiesApplied=$false;policyError=$null;version='1.5.4';enrolled=$false;enrollmentUtc=$null;lastSuccessUtc=$null;lastError=$null;sequence=0;results=@()}
  [IO.File]::WriteAllText($statePath,($state|ConvertTo-Json -Depth 5),(New-Object Text.UTF8Encoding $false))
}
# Install the pinned updater and private exact-file cache before the agent's first cloud poll.
& "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $updateInstaller -PayloadRoot (Join-Path $PayloadRoot 'Update') -InitialVersion '1.5.6'
if($LASTEXITCODE -ne 0){throw 'Automatic updater installation did not succeed; management was not started.'}
# Windows PowerShell 5.1 requires escaped native quotes inside the binPath argument.
$bin='\"'+(Join-Path $programRoot 'UEPLV.Management.exe')+'\" agent-service'
if(!$existing){& sc.exe create UEPLVAgent binPath= $bin start= auto obj= LocalSystem DisplayName= 'UEPLV Lab Management Agent' | Out-Null}else{& sc.exe config UEPLVAgent binPath= $bin start= auto | Out-Null}
if($LASTEXITCODE -ne 0){throw 'Could not register the UEPLV agent service.'}
& sc.exe description UEPLVAgent 'School-owned classroom management; complements Veyon. Fixed authenticated actions only.' | Out-Null
& sc.exe sdset UEPLVAgent 'D:(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;AU)' | Out-Null
if($LASTEXITCODE -ne 0){throw 'Could not set agent service access permissions.'}
& sc.exe failure UEPLVAgent reset= 86400 actions= restart/15000/restart/60000/restart/300000 | Out-Null
Start-Service UEPLVAgent
$service=Get-Service UEPLVAgent
$service.WaitForStatus([ServiceProcess.ServiceControllerStatus]::Running,[TimeSpan]::FromSeconds(30))
$service.Refresh()
$state=Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
$result=[ordered]@{component='UEPLVAgent';installed=($service.Status -eq 'Running');service=$service.Name;computerName=$ComputerName;deviceId=$state.deviceId;enrolled=[bool]$state.enrolled;cloudConfigured=[bool]$profile.cloudUrl;statePath=$statePath;utc=[DateTime]::UtcNow.ToString('o');version='1.5.4'}
[IO.File]::WriteAllText((Join-Path $stateRoot 'install-result.json'),($result|ConvertTo-Json -Depth 4),(New-Object Text.UTF8Encoding $false))
$result
