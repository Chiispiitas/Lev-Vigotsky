﻿$ErrorActionPreference='Stop'
$statePath=Join-Path $env:ProgramData 'UEPLV\finalization-state.json'
$reportPath=Join-Path $env:ProgramData 'UEPLV\Reports\finalization.json'
$state=[ordered]@{SchemaVersion=1;Stage='Prepare';UpdateReboots=0;UpdatePasses=0;UpdateFailures=0;Failure=$null;LastRunUtc=$null;Complete=$false}
if(Test-Path -LiteralPath $statePath){$old=Get-Content -LiteralPath $statePath -Raw|ConvertFrom-Json;foreach($p in $old.PSObject.Properties){$state[$p.Name]=$p.Value}}
function Save-Finalization {
    $state.LastRunUtc=[DateTime]::UtcNow.ToString('o')
    $text=$state|ConvertTo-Json -Depth 6
    # Write the existing excluded file in place; replacing it would break exact-file UWF semantics.
    [IO.File]::WriteAllText($statePath,$text,[Text.UTF8Encoding]::new($false))
    & icacls.exe $statePath /inheritance:r /grant:r '*S-1-5-18:F' '*S-1-5-32-544:F' | Out-Null
    if($LASTEXITCODE -ne 0){throw 'Could not protect finalization state.'}
    [IO.File]::WriteAllText($reportPath,$text,[Text.UTF8Encoding]::new($false))
}
function Run-Component([string]$Script,[string[]]$Parameters=@()) {
    $log=Join-Path $env:ProgramData 'UEPLV\Reports\finalization-components.log'
    $previous=$ErrorActionPreference
    try {
        $ErrorActionPreference='Continue'
        & "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot $Script) @Parameters 2>&1 | Out-File -LiteralPath $log -Append -Encoding UTF8
        $code=[int]$LASTEXITCODE
    } finally { $ErrorActionPreference=$previous }
    return $code
}
function Request-DeploymentRestart {
    $state.RestartRequestedBootTicks=(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime().Ticks
    Save-Finalization
    & shutdown.exe /r /t 60 /c 'UEPLV: completando actualizaciones y proteccion inicial del laboratorio.'
}
if($env:COMPUTERNAME -notmatch '^(?:UEPLV-|LEV-VIGOTSKY-)(0[1-9]|[12][0-9]|3[0-3])$'){exit 0}
# A queued restart can overlap the retry trigger. Verify only after the boot changes.
if($state.Contains('RestartRequestedBootTicks') -and [long]$state.RestartRequestedBootTicks -eq (Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime().Ticks){exit 0}
if($state.Complete -or $state.Failure){Disable-ScheduledTask -TaskName 'UEPLV-FinalizeDeployment' | Out-Null;exit 0}
try {
    if($state.Stage -eq 'Prepare') {
        $veyonCode=Run-Component 'Veyon\Verify-InstalledVeyon.ps1'
        if($veyonCode -ne 0){throw 'Veyon verification failed after computer rename. Review Reports\veyon-installation.json.'}
        $code=Run-Component 'Provisioning\Finish-Protection.ps1' @('-Stage','Prepare')
        if($code -notin @(0,3010)){throw 'UWF component preparation failed.'}
        $state.Stage='Updates';Save-Finalization
        if($code -eq 3010){Request-DeploymentRestart;exit 0}
    }
    if($state.Stage -eq 'Updates') {
        $state.UpdatePasses=[int]$state.UpdatePasses+1
        if($state.UpdatePasses -gt 12){throw 'Automatic update attempts reached the limit; staff review required.'}
        Save-Finalization
        $code=Run-Component 'Provisioning\Update-BeforeProtection.ps1'
        if($code -eq 3010){
            $state.UpdateReboots=[int]$state.UpdateReboots+1
            if($state.UpdateReboots -gt 4){throw 'Update reboot limit reached. No further automatic restart will occur.'}
            Request-DeploymentRestart;exit 0
        }
        if($code -eq 2){Save-Finalization;exit 0}
        if($code -ne 0){
            $state.UpdateFailures=[int]$state.UpdateFailures+1
            if($state.UpdateFailures -lt 3){Save-Finalization;exit 0}
            throw 'Windows Update failed three checks. Protection remains disabled; review Provisioning\update-report.json.'
        }
        $state.Stage='Readiness';Save-Finalization
    }
    if($state.Stage -eq 'Readiness') {
        $agentPath=Join-Path $env:ProgramData 'UEPLV\Management\agent-state.json'
        if(-not(Test-Path -LiteralPath $agentPath)){Save-Finalization;exit 0}
        $agent=Get-Content -LiteralPath $agentPath -Raw|ConvertFrom-Json
        # Enrollment is verified by Finish-Protection too. An unavailable gateway is a wait condition.
        if(-not $agent.Enrolled){Save-Finalization;exit 0}
        $state.Stage='ProtectionPending';Save-Finalization
        $code=Run-Component 'Provisioning\Finish-Protection.ps1' @('-Stage','Enable')
        if($code -eq 3010){Request-DeploymentRestart;exit 0}
        if($code -ne 0){
            # An offline gateway or a newly available update defers protection without any reboot loop.
            $state.Stage='Readiness'
            $protectionPath=Join-Path $env:ProgramData 'UEPLV\Provisioning\protection-report.json'
            if(Test-Path -LiteralPath $protectionPath){
                $protection=Get-Content -LiteralPath $protectionPath -Raw|ConvertFrom-Json
                if(($protection.Updates -and $protection.Updates.Count -gt 0) -or $protection.Failure -match 'restart.*pending|PendingRestart'){$state.Stage='Updates'}
            }
            Save-Finalization;exit 0
        }
        $state.Stage='PostBoot';Save-Finalization
    }
    if($state.Stage -eq 'ProtectionPending' -or $state.Stage -eq 'PostBoot') {
        $code=Run-Component 'Provisioning\Finish-Protection.ps1' @('-Stage','PostBoot')
        if($code -ne 0){throw 'Protection was scheduled but did not verify after restart. Staff review required.'}
        $state.Stage='Complete';$state.Complete=$true;Save-Finalization
        Disable-ScheduledTask -TaskName 'UEPLV-FinalizeDeployment' | Out-Null
    }
} catch {
    $state.Failure=$_.Exception.Message;Save-Finalization
    Disable-ScheduledTask -TaskName 'UEPLV-FinalizeDeployment' | Out-Null
    exit 1
}
