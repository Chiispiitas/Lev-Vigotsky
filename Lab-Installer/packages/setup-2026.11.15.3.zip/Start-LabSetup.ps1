﻿param([ValidateRange(0,33)][int]$ComputerNumber=0)
# First-login wrapper: log errors from the first instruction and keep failure visible.
$ErrorActionPreference='Stop'
$started=$false;$success=$false
$folder=Join-Path $env:ProgramData 'UEPLV\Reports'
$log=Join-Path $folder ('first-login-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.log')
try {
    [IO.Directory]::CreateDirectory($folder)|Out-Null
    Start-Transcript -LiteralPath $log -Force|Out-Null;$started=$true
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
    $admin=([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    Write-Host ('UEPLV initial setup | user='+$env:USERNAME+' | administrator='+$admin)
    & (Join-Path $PSScriptRoot 'Install-Lab.ps1') -ComputerNumber $ComputerNumber
    $success=$true
} catch {
    Write-Host 'UEPLV SETUP FAILED. The error and log path stay visible below.' -ForegroundColor Red
    Write-Host ($_|Format-List * -Force|Out-String) -ForegroundColor Red
    Write-Host $_.ScriptStackTrace
    Write-Host ('LOG: '+$log) -ForegroundColor Yellow
} finally {
    if($started){Stop-Transcript|Out-Null}
}
if(-not $success){
    Write-Host 'Creating a diagnostics ZIP on the MAINTENANCE desktop...' -ForegroundColor Yellow
    $support=Join-Path $PSScriptRoot 'Support\Invoke-LabSupport.ps1'
    try {
        if(Test-Path -LiteralPath $support -PathType Leaf){
            $previousPreference=$ErrorActionPreference;$ErrorActionPreference='Continue'
            & (Join-Path $env:windir 'System32\WindowsPowerShell\v1.0\powershell.exe') -NoProfile -ExecutionPolicy Bypass -File $support -Action Collect -NoPause 2>&1|ForEach-Object {Write-Host ($_|Out-String)}
            $collectExit=$LASTEXITCODE;$ErrorActionPreference=$previousPreference
            if($collectExit -ne 0){Write-Host ('Diagnostics collector returned '+$collectExit+'. Original log: '+$log) -ForegroundColor Yellow}
        }else{Write-Host ('Diagnostics collector missing. Original log: '+$log) -ForegroundColor Yellow}
    } catch {Write-Host ('Diagnostics collection failed: '+$_.Exception.Message+' | Original log: '+$log) -ForegroundColor Yellow}
    Write-Host 'Keep the installation USB connected. The error window remains open; do not reinstall other PCs yet.' -ForegroundColor Yellow
}
