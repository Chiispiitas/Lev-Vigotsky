[CmdletBinding()]
param(
    [ValidateSet('Prepare','Verify','Enable','PostBoot')][string]$Stage='Verify',
    [ValidateRange(2048,32768)][int]$OverlayMB=8192,
    [string]$StateRoot=(Join-Path $env:ProgramData 'UEPLV\Provisioning')
)
. (Join-Path $PSScriptRoot 'Common.ps1')
Assert-LabAdministrator
Assert-LabMachineName
Set-PrivateDirectory $StateRoot
$reportPath=Join-Path $StateRoot 'protection-report.json'
$report=[ordered]@{SchemaVersion=1;ComputerName=$env:COMPUTERNAME;Utc=[datetime]::UtcNow.ToString('o');Stage=$Stage;Success=$false;RequiresRestart=$false;ProtectedNow=$false;Checks=$null;Updates=$null;Uwf=$null;Commands=@();Failure=$null}
function Save-ProtectionReport { Write-LabJson $reportPath $report }
try {
    $edition=(Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').EditionID
    if($edition -notin @('Education','EducationN','Enterprise','EnterpriseN','EnterpriseS','EnterpriseSN','IoTEnterprise','IoTEnterpriseS')) { throw ('UWF requires a supported Education/Enterprise edition. Actual edition: '+$edition) }
    $feature=Get-WindowsOptionalFeature -Online -FeatureName Client-UnifiedWriteFilter
    if($Stage -eq 'Prepare') {
        if($feature.State -ne 'Enabled') {
            $enabled=Enable-WindowsOptionalFeature -Online -FeatureName Client-UnifiedWriteFilter -All -NoRestart
            $report.RequiresRestart=[bool]$enabled.RestartNeeded
        }
        $report.Commands += 'UWF optional component prepared with no automatic restart. Protection remains disabled until readiness passes.'
        $report.Success=$true
        Save-ProtectionReport
        if($report.RequiresRestart) { Write-Host 'UWF component installed. Restart before continuing.';exit 3010 }
        Write-Host 'UWF component ready. Continue with updates and verification.';exit 0
    }
    if($feature.State -ne 'Enabled') { throw 'UWF optional component is not enabled. Run -Stage Prepare and complete the required restart first.' }
    $report.Uwf=Get-LabUwfState
    if($Stage -eq 'PostBoot') {
        $report.ProtectedNow=[bool]($report.Uwf.CurrentEnabled -and $report.Uwf.CurrentCProtected -and -not $report.Uwf.CurrentServicing)
        $report.Success=[bool]($report.ProtectedNow -and $report.Uwf.NextEnabled -and $report.Uwf.NextCProtected)
        Save-ProtectionReport
        if(-not $report.Success) { throw 'Post-restart verification did not find C: protected in both current and next sessions.' }
        Write-Host 'Verified: UWF is active and C: is protected. Current and next-session states agree.';exit 0
    }
    if($report.Uwf.CurrentServicing -or $report.Uwf.NextServicing) { throw 'UWF servicing is active or scheduled. Finish servicing and restart before enabling protection.' }
    if($report.Uwf.CurrentEnabled) {
        if($report.Uwf.CurrentCProtected -and $report.Uwf.NextEnabled -and $report.Uwf.NextCProtected) {
            $report.ProtectedNow=$true;$report.Success=$true;Save-ProtectionReport
            Write-Host 'Already protected. Use the PostBoot stage for status; use servicing mode for further updates.';exit 0
        }
        throw 'UWF is enabled with inconsistent volume/next-session state. Resolve through documented UWF commands before continuing.'
    }
    $report.Checks=Get-LabReadiness
    $failed=@($report.Checks.PSObject.Properties | Where-Object {-not [bool]$_.Value} | ForEach-Object {$_.Name})
    if($failed.Count) { throw ('Protection deferred; failed readiness checks: '+($failed -join ', ')) }
    # Live successful scan is mandatory; offline or failed searches never count as fully updated.
    $report.Updates=Get-LabRequiredUpdates
    if($report.Updates.Count -gt 0) { throw ('Protection deferred; required software updates remain: '+($report.Updates.Titles -join '; ')) }
    if(@(Get-LabPendingRestart).Count) { throw 'A restart became pending during update verification. Restart, then verify again.' }
    if($Stage -eq 'Verify') { $report.Success=$true;Save-ProtectionReport;Write-Host 'Ready for protection. Run with -Stage Enable to configure the next protected boot.';exit 0 }
    $freeMB=[math]::Floor((Get-Volume -DriveLetter C).SizeRemaining/1MB)
    if($freeMB -lt ($OverlayMB+16384)) { throw ('At least overlay size plus 16 GB free headroom is required. Available MB: '+$freeMB) }
    $agentState=Join-Path $env:ProgramData 'UEPLV\Management\agent-state.json'
    if(-not(Test-Path -LiteralPath $agentState -PathType Leaf)) { throw 'Management identity file must exist before adding the exact-file exclusion.' }
    # No broad folder, user-profile, driver, system hive or Windows Update exclusions.
    foreach($uwfArguments in @(
        @('overlay','set-type','DISK'),
        @('overlay','set-size',[string]$OverlayMB),
        @('overlay','set-warningthreshold',[string][int]($OverlayMB*0.75)),
        @('overlay','set-criticalthreshold',[string][int]($OverlayMB*0.90)),
        @('overlay','set-passthrough','on'),
        @('overlay','set-persistent','off'),
        @('volume','protect','C:')
    )) { $report.Commands += Invoke-LabUwf $uwfArguments }
    # WMI FindExclusion avoids treating a duplicate exclusion as an error on repeat runs.
    $volume=Get-CimInstance -Namespace 'root\standardcimv2\embedded' -ClassName UWF_Volume | Where-Object {-not $_.CurrentSession -and $_.DriveLetter -eq 'C:'} | Select-Object -First 1
    if(-not $volume) { throw 'UWF next-session C: configuration not found after protection request.' }
    foreach($stateFile in @($agentState,(Join-Path $env:ProgramData 'UEPLV\finalization-state.json'),(Join-Path $env:ProgramData 'UEPLV\Update\pending-package.json'),(Join-Path $env:ProgramData 'UEPLV\Update\update-state.json'),(Join-Path $env:ProgramData 'UEPLV\Update\update-checkpoint.json'))) {
        if(-not(Test-LabPrivateFile $stateFile)) { throw ('Persistent state file must exist with SYSTEM/Administrators-only permissions: '+$stateFile) }
        $relativeState=$stateFile.Substring(2)
        $found=Invoke-CimMethod -InputObject $volume -MethodName FindExclusion -Arguments @{FileName=$relativeState}
        if($found.ReturnValue -ne 0) { throw ('Cannot verify exact state exclusion: '+$found.ReturnValue) }
        if(-not $found.bFound) { $report.Commands += Invoke-LabUwf @('file','add-exclusion',$stateFile) }
        $found=Invoke-CimMethod -InputObject $volume -MethodName FindExclusion -Arguments @{FileName=$relativeState}
        if($found.ReturnValue -ne 0 -or -not $found.bFound) { throw ('Exact state exclusion was not confirmed: '+$stateFile) }
    }
    $report.Commands += Invoke-LabUwf @('filter','enable')
    $report.Uwf=Get-LabUwfState
    $nextOverlay=@($report.Uwf.NextOverlay)[0]
    if(-not $report.Uwf.NextEnabled -or -not $report.Uwf.NextCProtected -or $nextOverlay.Type -ne 1 -or $nextOverlay.MaximumSize -ne $OverlayMB) { throw 'Next-session protection or disk-overlay verification failed. Do not declare deployment complete.' }
    $report.RequiresRestart=$true;$report.Success=$true
    Save-ProtectionReport
    Write-Host 'Protection is scheduled, not yet active. Restart once, then run -Stage PostBoot. No restart was forced by this script.'
    exit 3010
} catch {
    $report.Failure=$_.Exception.Message
    Save-ProtectionReport
    Write-Error $report.Failure
    exit 1
}
