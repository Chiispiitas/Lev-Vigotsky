﻿[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$PayloadRoot,
    [string]$StateRoot = (Join-Path $env:ProgramData 'UEPLV\Provisioning')
)
. (Join-Path $PSScriptRoot 'Common.ps1')
Assert-LabAdministrator
$PayloadRoot = (Resolve-Path -LiteralPath $PayloadRoot).Path
$sourceWallpaper = Join-Path $PayloadRoot 'Wallpaper.png'
if (-not (Test-Path -LiteralPath $sourceWallpaper -PathType Leaf)) { throw 'PayloadRoot must contain Wallpaper.png.' }
if (-not (Get-LocalUser -Name 'MAINTENANCE' -ErrorAction SilentlyContinue)) { throw 'MAINTENANCE must be created by Windows Setup first.' }
if (-not (Get-LocalUser -Name 'LEV VIGOTSKY' -ErrorAction SilentlyContinue)) { throw 'LEV VIGOTSKY must be created by Windows Setup first.' }
Set-PrivateDirectory $StateRoot
$reportFile = Join-Path $StateRoot 'install-settings-report.json'
$report = [ordered]@{ SchemaVersion=1; ComputerName=$env:COMPUTERNAME; Utc=[datetime]::UtcNow.ToString('o'); Success=$false; Steps=@(); Notes=@(); Failure=$null }
$script:Backups = New-Object 'System.Collections.Generic.List[object]'
$backupManifest = Join-Path $StateRoot 'registry-before.json'
if (Test-Path -LiteralPath $backupManifest) { $loadedBackups=Get-Content -LiteralPath $backupManifest -Raw | ConvertFrom-Json; foreach ($entry in $loadedBackups) { $script:Backups.Add($entry) } }
function Set-LabValue([string]$Path,[string]$Name,$Value,[string]$Type='DWord') {
    if (-not @($script:Backups | Where-Object { $_.Path -eq $Path -and $_.Name -eq $Name }).Count) {
        $exists = $false; $oldValue=$null; $oldType=$null
        if (Test-Path -LiteralPath $Path) {
            $key=Get-Item -LiteralPath $Path
            if ($key.GetValueNames() -contains $Name) { $exists=$true; $oldValue=$key.GetValue($Name); $oldType=$key.GetValueKind($Name).ToString() }
            $key.Close()
        }
        $script:Backups.Add([pscustomobject]@{Path=$Path;Name=$Name;Existed=$exists;Value=$oldValue;Type=$oldType})
        Write-LabJson $backupManifest @($script:Backups.ToArray())
    }
    if (-not (Test-Path -LiteralPath $Path)) { New-Item -Path $Path -Force | Out-Null }
    New-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -PropertyType $Type -Force | Out-Null
    $actual=Get-ItemPropertyValue -LiteralPath $Path -Name $Name
    if ([string]$actual -ne [string]$Value) { throw ('Registry verification failed: '+$Path+' '+$Name) }
}
function Move-DesktopContentsToBackup([string]$Desktop,[string]$Label) {
    if (-not (Test-Path -LiteralPath $Desktop -PathType Container)) { return }
    $resolved=(Resolve-Path -LiteralPath $Desktop).Path
    if ($resolved -notmatch '^[A-Za-z]:\\Users\\' -or $resolved -notmatch '\\Desktop$') { throw ('Unexpected desktop path: '+$resolved) }
    $backup=Join-Path $StateRoot ('Desktop-backup\'+$Label)
    [IO.Directory]::CreateDirectory($backup) | Out-Null
    foreach ($item in @(Get-ChildItem -LiteralPath $resolved -Force)) {
        if ($item.Name -eq 'desktop.ini') { continue }
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw ('Desktop contains a link/junction; resolve manually before continuing: '+$item.FullName) }
        $target=Join-Path $backup $item.Name
        if (Test-Path -LiteralPath $target) { $target=Join-Path $backup (([guid]::NewGuid().ToString('N'))+'-'+$item.Name) }
        Move-Item -LiteralPath $item.FullName -Destination $target
    }
}
function Set-LabUserHive([string]$Root,[bool]$Student) {
    Set-LabValue ($Root+'\Software\Microsoft\Windows\CurrentVersion\Search') SearchboxTaskbarMode 2
    Set-LabValue ($Root+'\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced') ShowTaskViewButton 0
    foreach($runKey in @('Run','RunOnce')){foreach($entry in @('OneDriveSetup','OneDrive')){Remove-ItemProperty -LiteralPath ($Root+'\Software\Microsoft\Windows\CurrentVersion\'+$runKey) -Name $entry -ErrorAction SilentlyContinue}}
    Set-LabValue ($Root+'\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize') AppsUseLightTheme 0
    Set-LabValue ($Root+'\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize') SystemUsesLightTheme 0
    Set-LabValue ($Root+'\Control Panel\Desktop') Wallpaper $script:Wallpaper String
    Set-LabValue ($Root+'\Control Panel\Desktop') WallpaperStyle '10' String
    Set-LabValue ($Root+'\Control Panel\Desktop') TileWallpaper '0' String
    foreach($panel in @('NewStartPanel','ClassicStartMenu')) {
        $key=$Root+'\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\'+$panel
        foreach($id in @('{20D04FE0-3AEA-1069-A2D8-08002B30309D}','{59031a47-3f72-44a7-89c5-5595fe6b30ee}','{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}','{5399E694-6CE5-4D6C-8FCE-1D8870FDCBA0}')) { Set-LabValue $key $id 1 }
        Set-LabValue $key '{645FF040-5081-101B-9F08-00AA002F954E}' 0
    }
    $run='"'+(Join-Path $env:windir 'System32\WindowsPowerShell\v1.0\powershell.exe')+'" -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+(Join-Path $script:InstallRoot 'Apply-UserSettings.ps1')+'"'
    Set-LabValue ($Root+'\Software\Microsoft\Windows\CurrentVersion\Run') UEPLVUserSettings $run String
    Set-LabValue ($Root+'\Software\Policies\Microsoft\Windows\CloudContent') DisableSpotlightCollectionOnDesktop 1
    Set-LabValue ($Root+'\Software\Policies\Microsoft\Windows\CloudContent') DisableWindowsSpotlightFeatures 1
    if($Student) {
        Set-LabValue ($Root+'\Software\Microsoft\Windows\CurrentVersion\Policies\ActiveDesktop') NoChangingWallPaper 1
        Set-LabValue ($Root+'\Software\Microsoft\Windows\CurrentVersion\Policies\System') Wallpaper $script:Wallpaper String
        Set-LabValue ($Root+'\Software\Microsoft\Windows\CurrentVersion\Policies\System') WallpaperStyle '10' String
    }
}
function Use-LabUserHive([string]$HiveFile,[string]$Sid,[bool]$Student) {
    $hiveRoot='Registry::HKEY_USERS\'+$Sid
    $loadedHere=$false
    if(-not(Test-Path -LiteralPath $hiveRoot)) {
        if(-not(Test-Path -LiteralPath $HiveFile -PathType Leaf)) { return }
        & reg.exe load ('HKU\'+$Sid) $HiveFile | Out-Null
        if($LASTEXITCODE -ne 0) { throw ('Cannot load user settings hive: '+$HiveFile) }
        $loadedHere=$true
    }
    try { Set-LabUserHive $hiveRoot $Student }
    finally {
        if($loadedHere) {
            [GC]::Collect();[GC]::WaitForPendingFinalizers()
            & reg.exe unload ('HKU\'+$Sid) | Out-Null
            if($LASTEXITCODE -ne 0) { throw ('Cannot unload temporary user hive: '+$Sid) }
        }
    }
}
try {
    $script:InstallRoot=Join-Path $env:ProgramFiles 'UEPLV\Provisioning'
    [IO.Directory]::CreateDirectory($script:InstallRoot) | Out-Null
    $script:Wallpaper=Join-Path $script:InstallRoot 'Wallpaper.png'
    Copy-Item -LiteralPath $sourceWallpaper -Destination $script:Wallpaper -Force
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Apply-UserSettings.ps1') -Destination (Join-Path $script:InstallRoot 'Apply-UserSettings.ps1') -Force
    Get-ChildItem -LiteralPath $script:InstallRoot -File | ForEach-Object { $_.IsReadOnly=$false }
    if((Get-FileHash -LiteralPath $sourceWallpaper).Hash -ne (Get-FileHash -LiteralPath $script:Wallpaper).Hash) { throw 'Wallpaper copy verification failed.' }
    $report.Steps += 'Wallpaper installed and hash verified.'

    $student=Get-LocalUser -Name 'LEV VIGOTSKY';$maintenance=Get-LocalUser -Name 'MAINTENANCE'
    $adminGroup=Get-LocalGroup -SID 'S-1-5-32-544';$usersGroup=Get-LocalGroup -SID 'S-1-5-32-545'
    $adminSids=@(Get-LocalGroupMember -Group $adminGroup.Name | ForEach-Object {$_.SID.Value})
    if($adminSids -notcontains $maintenance.SID.Value) { Add-LocalGroupMember -Group $adminGroup.Name -Member $maintenance }
    if($adminSids -contains $student.SID.Value) { Remove-LocalGroupMember -Group $adminGroup.Name -Member $student }
    if(@(Get-LocalGroupMember -Group $usersGroup.Name | ForEach-Object {$_.SID.Value}) -notcontains $student.SID.Value) { Add-LocalGroupMember -Group $usersGroup.Name -Member $student }
    $report.Steps += 'MAINTENANCE administrator and LEV VIGOTSKY standard account memberships verified.'

    $uac='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'
    Set-LabValue $uac EnableLUA 1
    Set-LabValue $uac ConsentPromptBehaviorAdmin 0
    Set-LabValue $uac ConsentPromptBehaviorUser 0
    Set-LabValue $uac PromptOnSecureDesktop 0
    Set-LabValue 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' HiberbootEnabled 0
    $report.Steps += 'Never Notify for administrator; student elevation denied; Fast Startup disabled.'

    $edge='HKLM:\SOFTWARE\Policies\Microsoft\Edge'
    $strings=@{DefaultSearchProviderName='Google';DefaultSearchProviderKeyword='google.com';DefaultSearchProviderSearchURL='https://www.google.com/search?q={searchTerms}';DefaultSearchProviderSuggestURL='https://www.google.com/complete/search?output=chrome&q={searchTerms}';NewTabPageSearchBox='redirect';ManagedFavorites='[]'}
    foreach($item in $strings.GetEnumerator()) { Set-LabValue $edge $item.Key $item.Value String }
    $numbers=@{Microsoft365CopilotChatIconEnabled=0;HubsSidebarEnabled=0;StartupBoostEnabled=0;BackgroundModeEnabled=0;DefaultSearchProviderEnabled=1;FavoritesBarEnabled=0;EditFavoritesEnabled=0;ImportFavorites=0;AutoImportAtFirstRun=4;HideFirstRunExperience=1;BrowserSignin=0;SyncDisabled=1;NewTabPageContentEnabled=0;NewTabPageQuickLinksEnabled=0;NewTabPageAllowedBackgroundTypes=3;NewTabPageAppLauncherEnabled=0;ShowHomeButton=0}
    foreach($item in $numbers.GetEnumerator()) { Set-LabValue $edge $item.Key $item.Value }
    $report.Steps += 'Edge Google search and minimal supported new-tab policies installed.'
    $report.Notes += 'The Edge desktop shortcut opens https://www.google.com/. NewTabPageLocation/RestoreOnStartupURLs are intentionally not relied on: Microsoft restricts these to AD/Entra/MDM-managed devices. New tabs instead hide content, quick links, background pictures and app launcher.'

    $default=Join-Path $env:SystemDrive 'Users\Default'
    Use-LabUserHive (Join-Path $default 'NTUSER.DAT') 'UEPLV_Default' $true
    Move-DesktopContentsToBackup (Join-Path $default 'Desktop') 'Default'
    foreach($account in @($maintenance,$student)) {
        $profile=Get-CimInstance Win32_UserProfile | Where-Object SID -eq $account.SID.Value | Select-Object -First 1
        if($profile) {
            Use-LabUserHive (Join-Path $profile.LocalPath 'NTUSER.DAT') $account.SID.Value ($account.Name -eq 'LEV VIGOTSKY')
            Move-DesktopContentsToBackup (Join-Path $profile.LocalPath 'Desktop') $account.SID.Value
            # Fresh installation profiles have no bookmarks. Existing Edge bookmarks, if any, are backed up before removal.
            $edgeProfiles=Join-Path $profile.LocalPath 'AppData\Local\Microsoft\Edge\User Data'
            if(Test-Path -LiteralPath $edgeProfiles) {
                $edgeProcesses=@(Get-Process -Name msedge -ErrorAction SilentlyContinue)
                if(@($edgeProcesses | Where-Object MainWindowHandle -ne 0).Count){throw 'Close the Edge browser window before provisioning existing profiles.'}
                foreach($process in $edgeProcesses){
                    try { $cim=Get-CimInstance Win32_Process -Filter ('ProcessId='+$process.Id)
                    if(-not $cim){continue}
                    $owner=Invoke-CimMethod -InputObject $cim -MethodName GetOwner
                    if($owner.ReturnValue -ne 0 -or $owner.User -notin @('MAINTENANCE','LEV VIGOTSKY')){throw 'Edge is running for another account; close it before setup.'}
                    Stop-Process -Id $process.Id -Force -ErrorAction Stop } catch { if(Get-Process -Id $process.Id -ErrorAction SilentlyContinue){throw} }
                }
                foreach($dir in @(Get-ChildItem -LiteralPath $edgeProfiles -Directory | Where-Object {$_.Name -eq 'Default' -or $_.Name -match '^Profile \d+$'})) {
                    foreach($name in @('Bookmarks','Bookmarks.bak')) {
                        $file=Join-Path $dir.FullName $name
                        if(Test-Path -LiteralPath $file) {
                            $backup=Join-Path $StateRoot ('Bookmarks-backup\'+$account.SID.Value+'\'+$dir.Name)
                            [IO.Directory]::CreateDirectory($backup) | Out-Null
                            $target=Join-Path $backup ($name+'-'+[guid]::NewGuid().ToString('N'))
                            Move-Item -LiteralPath $file -Destination $target
                        }
                    }
                }
            }
        }
    }
    $publicDesktop=Join-Path $env:PUBLIC 'Desktop'
    Move-DesktopContentsToBackup $publicDesktop 'Public'
    $edgeExe=Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'
    if(-not(Test-Path -LiteralPath $edgeExe)) { $edgeExe=Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe' }
    if(-not(Test-Path -LiteralPath $edgeExe)) { throw 'Microsoft Edge was not found.' }
    $shell=New-Object -ComObject WScript.Shell
    $shortcut=$shell.CreateShortcut((Join-Path $publicDesktop 'Microsoft Edge.lnk'))
    $shortcut.TargetPath=$edgeExe;$shortcut.Arguments='--no-first-run --new-window https://www.google.com/';$shortcut.IconLocation=$edgeExe+',0';$shortcut.Save()
    [Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell) | Out-Null
    $icons=@(Get-ChildItem -LiteralPath $publicDesktop -Force | Where-Object Name -ne 'desktop.ini')
    if($icons.Count -ne 1 -or $icons[0].Name -ne 'Microsoft Edge.lnk') { throw 'Public desktop verification failed.' }
    $report.Steps += 'Default and existing target user hives configured; desktop items preserved in private backup; only Edge shortcut plus Recycle Bin shown.'
    $report.Success=$true
    Write-LabJson $reportFile $report
    Write-Host ('Lab appearance and browser settings applied. Report: '+$reportFile)
} catch {
    $report.Failure=$_.Exception.Message
    Write-LabJson $reportFile $report
    throw
}
