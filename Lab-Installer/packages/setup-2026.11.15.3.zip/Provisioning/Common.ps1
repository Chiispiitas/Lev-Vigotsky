﻿# Shared functions. Dot-sourcing this file performs no machine changes.
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Assert-LabAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Run this installation step as an administrator.' }
    if (-not [Environment]::Is64BitProcess) { throw 'Use 64-bit Windows PowerShell.' }
}

function Set-PrivateDirectory([string]$Path) {
    [IO.Directory]::CreateDirectory($Path) | Out-Null
    $acl = New-Object Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($sid in @('S-1-5-18','S-1-5-32-544')) {
        $rule = New-Object Security.AccessControl.FileSystemAccessRule((New-Object Security.Principal.SecurityIdentifier($sid)), 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')
        $acl.AddAccessRule($rule)
    }
    Set-Acl -LiteralPath $Path -AclObject $acl
}

function Write-LabJson([string]$Path, $Value) {
    $json=ConvertTo-Json -InputObject $Value -Depth 20
    if([string]::IsNullOrWhiteSpace($json)){throw ('Refusing to write an empty JSON report: '+$Path)}
    $bytes=[Text.UTF8Encoding]::new($false).GetBytes($json)
    $file=[IO.File]::Open($Path,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::Read)
    try{$preamble=[Text.Encoding]::UTF8.GetPreamble();$file.Write($preamble,0,$preamble.Length);$file.Write($bytes,0,$bytes.Length);$file.Flush($true)}finally{$file.Dispose()}
}

function Get-LabPendingRestart {
    $reasons = New-Object 'System.Collections.Generic.List[string]'
    foreach ($pair in @(
        @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending','Component servicing'),
        @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired','Windows Update')
    )) { if (Test-Path -LiteralPath $pair[0]) { $reasons.Add($pair[1]) } }
    $session = Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -ErrorAction SilentlyContinue
    if ($session -and $session.PSObject.Properties['PendingFileRenameOperations'] -and $session.PendingFileRenameOperations) { $reasons.Add('Pending file operations') }
    $active = (Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName').ComputerName
    $desired = (Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName').ComputerName
    if ($active -ne $desired) { $reasons.Add('Computer rename') }
    return @($reasons.ToArray())
}

function Get-LabUwfState {
    $ns = 'root\standardcimv2\embedded'
    $filter = Get-CimInstance -Namespace $ns -ClassName UWF_Filter
    $volumes = @(Get-CimInstance -Namespace $ns -ClassName UWF_Volume)
    $overlay = @(Get-CimInstance -Namespace $ns -ClassName UWF_OverlayConfig)
    $servicing = @(Get-CimInstance -Namespace $ns -ClassName UWF_Servicing)
    return [pscustomobject]@{
        CurrentEnabled = [bool]$filter.CurrentEnabled
        NextEnabled = [bool]$filter.NextEnabled
        CurrentCProtected = [bool](@($volumes | Where-Object { $_.CurrentSession -and $_.DriveLetter -eq 'C:' -and $_.Protected }).Count -gt 0)
        NextCProtected = [bool](@($volumes | Where-Object { -not $_.CurrentSession -and $_.DriveLetter -eq 'C:' -and $_.Protected }).Count -gt 0)
        CurrentOverlay = @($overlay | Where-Object CurrentSession | Select-Object Type,MaximumSize)
        NextOverlay = @($overlay | Where-Object { -not $_.CurrentSession } | Select-Object Type,MaximumSize)
        CurrentServicing = [bool](@($servicing | Where-Object { $_.CurrentSession -and $_.ServicingEnabled }).Count -gt 0)
        NextServicing = [bool](@($servicing | Where-Object { -not $_.CurrentSession -and $_.ServicingEnabled }).Count -gt 0)
    }
}

function Invoke-LabUwf([string[]]$Arguments) {
    $exe = Join-Path $env:windir 'System32\uwfmgr.exe'
    if (-not (Test-Path -LiteralPath $exe)) { throw 'UWF command tool is not installed.' }
    $result = & $exe @Arguments 2>&1 | Out-String
    $code = $LASTEXITCODE
    if ($code -ne 0) { throw ('UWF command failed ({0}): {1}' -f $code,$result.Trim()) }
    return $result.Trim()
}

function Get-LabManagementName([string]$ComputerName=$env:COMPUTERNAME) {
    if($ComputerName -notmatch '^(?:UEPLV-|LEV-VIGOTSKY-)(0[1-9]|[12][0-9]|3[0-3])$'){throw 'Invalid classroom computer name.'}
    return ('UEPLV-'+$matches[1])
}

function Assert-LabMachineName {
    if ($env:COMPUTERNAME -notmatch '^(?:UEPLV-|LEV-VIGOTSKY-)(0[1-9]|[12][0-9]|3[0-3])$') { throw 'The computer must have its assigned LEV-VIGOTSKY-01 through LEV-VIGOTSKY-33 name before protection is enabled.' }
}

function Test-LabPrivateFile([string]$Path) {
    if(-not(Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    $acl=Get-Acl -LiteralPath $Path
    $bad=@($acl.Access | Where-Object {
        $sid=try { $_.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value } catch { '' }
        $_.AccessControlType -eq 'Allow' -and $sid -notin @('S-1-5-18','S-1-5-32-544')
    })
    return ($bad.Count -eq 0)
}

function Test-LabAgentState($Agent,[string]$ComputerName,[datetime]$NowUtc=[datetime]::UtcNow) {
    if(-not $Agent) { return $false }
    foreach($property in @('deviceId','computerName','enrolled','lastSuccessUtc','policiesApplied')) { if(-not $Agent.PSObject.Properties[$property]) { return $false } }
    if(-not $Agent.enrolled -or -not $Agent.lastSuccessUtc -or $Agent.policiesApplied -ne $true) { return $false }
    if($Agent.PSObject.Properties['maintenanceBlocked'] -and $Agent.maintenanceBlocked) { return $false }
    if($Agent.PSObject.Properties['activeAction'] -and $Agent.activeAction -and $Agent.activeAction -notin @('uwf-enable','status','uwf-status')) { return $false }
    $connected=[datetime]::MinValue;$deviceId=[guid]::Empty
    if(-not [datetime]::TryParse([string]$Agent.lastSuccessUtc,[ref]$connected)) { return $false }
    if(-not [guid]::TryParse([string]$Agent.deviceId,[ref]$deviceId)) { return $false }
    $age=$NowUtc.ToUniversalTime()-$connected.ToUniversalTime()
    try { $managementName=Get-LabManagementName $ComputerName } catch { return $false }
    return [bool]($Agent.computerName -ceq $managementName -and $deviceId -ne [guid]::Empty -and $age.TotalMinutes -ge -2 -and $age.TotalMinutes -lt 15)
}

function Test-LabUpdateState($State) {
    if(-not $State -or -not $State.PSObject.Properties['schemaVersion'] -or $State.schemaVersion -ne 1 -or -not $State.PSObject.Properties['phase']) { return $false }
    if($State.PSObject.Properties['requiresStaffReview'] -and $State.requiresStaffReview) { return $false }
    return [bool]($State.phase -in @('idle','complete','failed'))
}

function Get-LabReadiness {
    $checks = [ordered]@{}
    $checks.ComputerName = $env:COMPUTERNAME -match '^(?:UEPLV-|LEV-VIGOTSKY-)(0[1-9]|[12][0-9]|3[0-3])$'
    $admin = Get-LocalUser -Name 'MAINTENANCE' -ErrorAction SilentlyContinue
    $student = Get-LocalUser -Name 'LEV VIGOTSKY' -ErrorAction SilentlyContinue
    $adminGroup = Get-LocalGroup -SID 'S-1-5-32-544'
    $adminMembers = @(Get-LocalGroupMember -Group $adminGroup.Name | ForEach-Object { $_.SID.Value })
    $checks.AdminAccount = [bool]($admin -and $admin.Enabled -and $adminMembers -contains $admin.SID.Value)
    $checks.StudentStandard = [bool]($student -and $student.Enabled -and $adminMembers -notcontains $student.SID.Value)
    $uac = Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'
    $checks.UacNeverNotifyAdminAndDenyStudentElevation = ($uac.EnableLUA -eq 1 -and $uac.ConsentPromptBehaviorAdmin -eq 0 -and $uac.ConsentPromptBehaviorUser -eq 0 -and $uac.PromptOnSecureDesktop -eq 0)
    $checks.FastStartupDisabled = ((Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power').HiberbootEnabled -eq 0)
    $settingsReport = Join-Path $env:ProgramData 'UEPLV\Provisioning\install-settings-report.json'
    $checks.Settings = $false
    $checks.TaskbarAndAppCleanup=$false
    $declutterReport=Join-Path $env:ProgramData 'UEPLV\Provisioning\declutter-report.json'
    if(Test-Path -LiteralPath $declutterReport){try{$declutter=Get-Content -LiteralPath $declutterReport -Raw|ConvertFrom-Json;$checks.TaskbarAndAppCleanup=[bool]($declutter.Success -and $declutter.Taskbar)}catch{}}
    if (Test-Path -LiteralPath $settingsReport) { $settings = Get-Content -LiteralPath $settingsReport -Raw | ConvertFrom-Json; $checks.Settings = [bool]$settings.Success }
    $veyonService = Get-Service -Name VeyonService -ErrorAction SilentlyContinue
    $checks.VeyonService = [bool]($veyonService -and $veyonService.Status -eq 'Running')
    $veyonExe = Join-Path $env:ProgramFiles 'Veyon\veyon-cli.exe'
    $checks.VeyonCli = Test-Path -LiteralPath $veyonExe
    # The caller records its actual imported config/key verification; this is not a mere installer exit-code flag.
    $veyonReport = Join-Path $env:ProgramData 'UEPLV\Reports\veyon-installation.json'
    $checks.VeyonConfigurationAndPublicKey = $false
    if (Test-Path -LiteralPath $veyonReport) {
        $v = Get-Content -LiteralPath $veyonReport -Raw | ConvertFrom-Json
        $checks.VeyonConfigurationAndPublicKey = [bool]($v.Passed -and $v.PublicKeyVerified -and $v.ConfigurationVerified -and $v.PrivateKeyAbsent -and (Get-LabManagementName $v.ComputerName) -eq (Get-LabManagementName $env:COMPUTERNAME))
    }
    $managementService = Get-Service -Name UEPLVAgent -ErrorAction SilentlyContinue
    $checks.ManagementService = [bool]($managementService -and $managementService.Status -eq 'Running')
    $stateFile = Join-Path $env:ProgramData 'UEPLV\Management\agent-state.json'
    $checks.ManagementEnrolledAndRecentlyConnected = $false
    $checks.ManagementIdentityPrivate = $false
    if (Test-Path -LiteralPath $stateFile) {
        $agent = Get-Content -LiteralPath $stateFile -Raw | ConvertFrom-Json
        $checks.ManagementEnrolledAndRecentlyConnected = Test-LabAgentState $agent $env:COMPUTERNAME
        $checks.ManagementIdentityPrivate = Test-LabPrivateFile $stateFile
    }
    $checks.FinalizationStatePrivate = Test-LabPrivateFile (Join-Path $env:ProgramData 'UEPLV\finalization-state.json')
    $updateRoot=Join-Path $env:ProgramData 'UEPLV\Update'
    $checks.AutomaticUpdateStatePrivate=Test-LabPrivateFile (Join-Path $updateRoot 'update-state.json')
    $checks.AutomaticUpdateCheckpointPrivate=Test-LabPrivateFile (Join-Path $updateRoot 'update-checkpoint.json')
    $checks.AutomaticUpdatePackagePrivate=Test-LabPrivateFile (Join-Path $updateRoot 'pending-package.json')
    $checks.AutomaticUpdateNotInstalling=$false
    if($checks.AutomaticUpdateStatePrivate) {
        try { $checks.AutomaticUpdateNotInstalling=Test-LabUpdateState (Get-Content -LiteralPath (Join-Path $updateRoot 'update-state.json') -Raw|ConvertFrom-Json) } catch {}
    }
    $coordinator=Join-Path $env:ProgramFiles 'UEPLV\Management\Update\Invoke-AutomaticUpdate.ps1'
    $expectedArguments='-NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+$coordinator+'"'
    $checks.AutomaticUpdateTask=$false
    try {
        $task=Get-ScheduledTask -TaskName 'UEPLV-AutomaticUpdate' -ErrorAction Stop
        $actions=@($task.Actions)
        $checks.AutomaticUpdateTask=[bool]($task.State -ne 'Disabled' -and $task.Principal.UserId -in @('SYSTEM','S-1-5-18') -and $task.Principal.RunLevel -eq 'Highest' -and $actions.Count -eq 1 -and $actions[0].Execute -ieq (Join-Path $env:windir 'System32\WindowsPowerShell\v1.0\powershell.exe') -and $actions[0].Arguments -ceq $expectedArguments -and (Test-Path -LiteralPath $coordinator -PathType Leaf))
    } catch {}
    $installedKey=Join-Path $env:ProgramFiles 'UEPLV\Management\Update\release-public.xml'
    $payloadKey=Join-Path $PSScriptRoot '..\Management\Update\release-public.xml'
    $checks.AutomaticUpdateKeyPinned=$false
    if((Test-Path -LiteralPath $installedKey -PathType Leaf) -and (Test-Path -LiteralPath $payloadKey -PathType Leaf)) {
        $checks.AutomaticUpdateKeyPinned=((Get-FileHash -LiteralPath $installedKey).Hash -ceq (Get-FileHash -LiteralPath $payloadKey).Hash)
    }
    $checks.NoPendingRestart = (@(Get-LabPendingRestart).Count -eq 0)
    return [pscustomobject]$checks
}

function Get-LabRequiredUpdates {
    $session=New-Object -ComObject Microsoft.Update.Session
    $session.ClientApplicationID='UEPLV Deployment Readiness'
    $searcher=$session.CreateUpdateSearcher()
    $result=$searcher.Search("IsInstalled=0 and IsHidden=0 and Type='Software' and BrowseOnly=0")
    if($result.ResultCode -ne 2) { throw ('Windows Update search did not succeed. Result code: '+$result.ResultCode) }
    $titles=@();for($i=0;$i -lt $result.Updates.Count;$i++) { $titles += [string]$result.Updates.Item($i).Title }
    return [pscustomobject]@{Count=[int]$result.Updates.Count;Titles=$titles;CheckedUtc=[datetime]::UtcNow.ToString('o');ResultCode=[int]$result.ResultCode}
}
