[CmdletBinding()]
param([string]$StateRoot=(Join-Path $env:ProgramData 'UEPLV\Provisioning'))
. (Join-Path $PSScriptRoot 'Common.ps1')
Assert-LabAdministrator
Assert-LabMachineName
Set-PrivateDirectory $StateRoot
$report=[ordered]@{SchemaVersion=1;ComputerName=$env:COMPUTERNAME;Utc=[datetime]::UtcNow.ToString('o');Success=$false;RequiresRestart=$false;Updates=@();ResultCode=$null;RemainingCount=$null;Failure=$null}
$reportPath=Join-Path $StateRoot 'update-report.json'
try {
    try { $uwf=Get-LabUwfState } catch {
        $feature=Get-WindowsOptionalFeature -Online -FeatureName Client-UnifiedWriteFilter
        if($feature.State -eq 'Enabled') { throw }
        $uwf=$null
    }
    if($uwf -and ($uwf.CurrentEnabled -or $uwf.NextEnabled -or $uwf.CurrentServicing -or $uwf.NextServicing)) { throw 'This deployment updater runs only while UWF is disabled now and for the next boot. On protected devices use UWF servicing mode instead.' }
    if(@(Get-LabPendingRestart).Count) { $report.RequiresRestart=$true;Write-LabJson $reportPath $report;Write-Host 'Restart first; no update installation was started.';exit 3010 }
    $session=New-Object -ComObject Microsoft.Update.Session
    $session.ClientApplicationID='UEPLV First Installation'
    $searcher=$session.CreateUpdateSearcher()
    $search=$searcher.Search("IsInstalled=0 and IsHidden=0 and Type='Software' and BrowseOnly=0")
    if($search.ResultCode -ne 2) { throw ('Windows Update scan failed. Result code: '+$search.ResultCode) }
    if($search.Updates.Count -eq 0) { $report.Success=$true;$report.ResultCode=2;$report.RemainingCount=0;Write-LabJson $reportPath $report;Write-Host 'No required software updates remain.';exit 0 }
    $collection=New-Object -ComObject Microsoft.Update.UpdateColl
    for($i=0;$i -lt $search.Updates.Count;$i++) {
        $update=$search.Updates.Item($i)
        if(-not $update.EulaAccepted) { $update.AcceptEula() }
        [void]$collection.Add($update)
    }
    $downloader=$session.CreateUpdateDownloader();$downloader.Updates=$collection
    $download=$downloader.Download()
    if($download.ResultCode -ne 2) { throw ('Update download did not fully succeed. Result code: '+$download.ResultCode) }
    $installer=$session.CreateUpdateInstaller();$installer.Updates=$collection
    $installed=$installer.Install()
    $report.ResultCode=[int]$installed.ResultCode
    $report.RequiresRestart=[bool]$installed.RebootRequired
    for($i=0;$i -lt $collection.Count;$i++) {
        $item=$installed.GetUpdateResult($i)
        $report.Updates += [pscustomobject]@{Title=[string]$collection.Item($i).Title;ResultCode=[int]$item.ResultCode;HResult=[int]$item.HResult;RebootRequired=[bool]$item.RebootRequired}
    }
    if($installed.ResultCode -ne 2 -or @($report.Updates | Where-Object ResultCode -ne 2).Count) { throw 'One or more updates failed. Review update-report.json; protection remains disabled.' }
    if($report.RequiresRestart -or @(Get-LabPendingRestart).Count) { $report.RequiresRestart=$true;Write-LabJson $reportPath $report;Write-Host 'Updates installed. Restart, then repeat the update check. No automatic restart was forced.';exit 3010 }
    $remaining=Get-LabRequiredUpdates
    $report.RemainingCount=$remaining.Count
    $report.Success=($remaining.Count -eq 0)
    Write-LabJson $reportPath $report
    if(-not $report.Success) { Write-Host 'Additional updates were discovered. Repeat the updater; protection remains disabled.';exit 2 }
    Write-Host 'Updates installed and follow-up scan passed.';exit 0
} catch {
    $report.Failure=$_.Exception.Message;Write-LabJson $reportPath $report
    Write-Error $report.Failure;exit 1
}
