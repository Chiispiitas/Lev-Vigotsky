﻿[CmdletBinding()]
param([switch]$LibraryOnly)
$ErrorActionPreference='Stop'
function Get-UnwantedLabApps {
    @('Microsoft.OneDriveSync','Microsoft.Copilot','Microsoft.MicrosoftOfficeHub','Microsoft.Office.OneNote','Microsoft.OutlookForWindows','MSTeams','MicrosoftTeams','Clipchamp.Clipchamp','Microsoft.GamingApp','Microsoft.XboxApp','Microsoft.Xbox.TCUI','Microsoft.XboxGameOverlay','Microsoft.XboxGamingOverlay','Microsoft.XboxIdentityProvider','Microsoft.XboxSpeechToTextOverlay','Microsoft.BingNews','Microsoft.BingWeather','Microsoft.MicrosoftSolitaireCollection','Microsoft.Getstarted','Microsoft.SkypeApp','Microsoft.People','Microsoft.WindowsMaps','Microsoft.Microsoft3DViewer','Microsoft.MixedReality.Portal','Microsoft.PowerAutomateDesktop','Microsoft.Todos','Microsoft.WindowsFeedbackHub')
}
function Remove-UnwantedLabApps {
    $errors=[Collections.Generic.List[string]]::new();$removed=[Collections.Generic.List[string]]::new()
    $targets=@(Get-UnwantedLabApps)
    foreach($package in Get-AppxProvisionedPackage -Online){
        if($targets -contains $package.DisplayName){try{Remove-AppxProvisionedPackage -Online -PackageName $package.PackageName -AllUsers -ErrorAction Stop|Out-Null;$removed.Add($package.DisplayName)}catch{$errors.Add($_.Exception.Message)}}
    }
    foreach($package in Get-AppxPackage -AllUsers){
        if($targets -contains $package.Name){try{Remove-AppxPackage -Package $package.PackageFullName -AllUsers -ErrorAction Stop;$removed.Add($package.Name)}catch{$errors.Add($_.Exception.Message)}}
    }
    [pscustomobject]@{Removed=@($removed.ToArray()|Sort-Object -Unique);Errors=$errors.ToArray()}
}
if($LibraryOnly){return}
. (Join-Path $PSScriptRoot 'Common.ps1')
Assert-LabAdministrator
if($env:USERNAME -ine 'MAINTENANCE'){throw 'Lab shell setup is only for MAINTENANCE on a new lab PC.'}
$state=Join-Path $env:ProgramData 'UEPLV\Provisioning';Set-PrivateDirectory $state
$report=[ordered]@{Utc=[datetime]::UtcNow.ToString('o');Success=$false;Taskbar=$false;Removed=@();Errors=@();OneDrive=$null}
try{
    $program=Join-Path $env:ProgramFiles 'UEPLV\Provisioning';[IO.Directory]::CreateDirectory($program)|Out-Null
    $layout=Join-Path $program 'TaskbarLayout.xml'
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'TaskbarLayout.xml') -Destination $layout -Force
    $links=Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\UEPLV';[IO.Directory]::CreateDirectory($links)|Out-Null
    $edge=Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'
    if(-not(Test-Path -LiteralPath $edge)){$edge=Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'}
    $explorer=Join-Path $env:windir 'explorer.exe'
    $shell=New-Object -ComObject WScript.Shell
    try{foreach($entry in @(@('Microsoft Edge.lnk',$edge),@('File Explorer.lnk',$explorer))){
        if(-not(Test-Path -LiteralPath $entry[1] -PathType Leaf)){throw ('Required pinned application missing: '+$entry[1])}
        $link=$shell.CreateShortcut((Join-Path $links $entry[0]));$link.TargetPath=$entry[1];if($entry[0] -eq 'Microsoft Edge.lnk'){$link.Arguments='--no-first-run --new-window https://www.google.com/'};$link.IconLocation=$entry[1]+',0';$link.WorkingDirectory=[IO.Path]::GetDirectoryName($entry[1]);$link.Save()
        $check=$shell.CreateShortcut((Join-Path $links $entry[0]));if($check.TargetPath -ine $entry[1] -or $check.IconLocation -notlike ($entry[1]+'*')){throw 'Taskbar shortcut verification failed.'}
    }}finally{[Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell)|Out-Null}
    function Policy([string]$Key,[string]$Name,$Value,[string]$Type='DWord'){if(-not(Test-Path -LiteralPath $Key)){New-Item -Path $Key -Force|Out-Null};New-ItemProperty -LiteralPath $Key -Name $Name -Value $Value -PropertyType $Type -Force|Out-Null}
    Policy 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' StartLayoutFile $layout ExpandString
    Policy 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' LockedStartLayout 1
    Policy 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' HideTaskViewButton 1
    Policy 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' SearchOnTaskbarMode 3
    Policy 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' EnableDynamicContentInWSB 0
    Policy 'HKLM:\SOFTWARE\Policies\Microsoft\Dsh' AllowNewsAndInterests 0
    Policy 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' DisableWindowsConsumerFeatures 1
    Policy 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\OneDrive' DisableFileSyncNGSC 1
    Policy 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot' TurnOffWindowsCopilot 1
    $defaultShell=Join-Path $env:SystemDrive 'Users\Default\AppData\Local\Microsoft\Windows\Shell'
    [IO.Directory]::CreateDirectory($defaultShell)|Out-Null
    Copy-Item -LiteralPath $layout -Destination (Join-Path $defaultShell 'LayoutModification.xml') -Force
    $report.Taskbar=$true
    $cleanup=Remove-UnwantedLabApps;$report.Removed=$cleanup.Removed;$report.Errors=$cleanup.Errors
    $oneDrive=Get-Process -Name OneDrive -ErrorAction SilentlyContinue
    if($oneDrive){$oneDrive|Stop-Process -Force}
    $setup=@((Join-Path $env:windir 'SysWOW64\OneDriveSetup.exe'),(Join-Path $env:windir 'System32\OneDriveSetup.exe'))|Where-Object {Test-Path -LiteralPath $_ -PathType Leaf}|Select-Object -First 1
    $oneDriveExecutables=@((Join-Path $env:ProgramFiles 'Microsoft OneDrive\OneDrive.exe'),(Join-Path ${env:ProgramFiles(x86)} 'Microsoft OneDrive\OneDrive.exe'))
    foreach($profile in @(Get-CimInstance Win32_UserProfile | Where-Object {-not $_.Special -and $_.LocalPath})){$oneDriveExecutables+=Join-Path $profile.LocalPath 'AppData\Local\Microsoft\OneDrive\OneDrive.exe'}
    $installedOneDrive=@($oneDriveExecutables|Where-Object {Test-Path -LiteralPath $_ -PathType Leaf}).Count -gt 0
    $registeredOneDrive=@(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue|Where-Object {$_.PSObject.Properties['DisplayName'] -and $_.DisplayName -like '*OneDrive*'}).Count -gt 0
    if(-not $installedOneDrive -and -not $registeredOneDrive){$report.OneDrive='Already absent; no executable or machine uninstall registration found.'}
    elseif($setup){$p=Start-Process -FilePath $setup -ArgumentList '/uninstall' -Wait -PassThru -WindowStyle Hidden;$report.OneDrive='Uninstaller exit '+$p.ExitCode;if($p.ExitCode -notin @(0,3010)){$report.Errors+=('OneDrive uninstaller exit '+$p.ExitCode)}}else{$report.OneDrive='No bundled machine uninstaller present; sync and first-login installer disabled.'}
    $report.Success=($report.Errors.Count -eq 0)
}catch{$report.Errors+=$_.Exception.Message}
Write-LabJson (Join-Path $state 'declutter-report.json') $report
if(-not $report.Taskbar){throw ('Taskbar configuration failed: '+($report.Errors -join '; '))}
if(-not $report.Success){Write-Warning ('Some app removals need review: '+($report.Errors -join '; '));exit 2}
Write-Host 'Taskbar configured with search box, Edge and File Explorer; bundled app cleanup complete.'
