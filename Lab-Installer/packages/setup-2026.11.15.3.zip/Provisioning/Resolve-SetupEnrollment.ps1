﻿function Resolve-LabSetupEnrollment {
param([string]$StateRoot,[string]$ManagementName)
if($ManagementName -cnotmatch '^UEPLV-(0[1-9]|[12][0-9]|3[0-3])$'){throw 'Numero de equipo no valido.'}
$enrollmentRoot=Join-Path $StateRoot 'SetupEnrollment'
$enrollment=Join-Path $enrollmentRoot 'selected.json'
$stagedProfiles=Join-Path $StateRoot 'Bootstrap\Enrollment'
if(-not(Test-Path -LiteralPath $enrollment)){
    $candidate=Join-Path $stagedProfiles ($ManagementName+'.json')
    if(-not(Test-Path -LiteralPath $candidate)){
        $candidate=Join-Path $StateRoot 'Management\agent-config.json'
        if(-not(Test-Path -LiteralPath $candidate)){
            $usbPackage=Get-PSDrive -PSProvider FileSystem|ForEach-Object {$p=Join-Path $_.Root 'UEPLV-Deployment';if(Test-Path -LiteralPath (Join-Path $p 'UEPLV-PACKAGE.marker')){$p}}|Select-Object -First 1
            if(-not $usbPackage){throw 'No se encontro la credencial privada de este equipo en el instalador local.'}
            $candidate=Join-Path $usbPackage ('Management\Enrollment\'+$ManagementName+'.json')
        }
    }
    $profile=Get-Content -LiteralPath $candidate -Raw|ConvertFrom-Json
    if($profile.name -cne $ManagementName -or ([Convert]::FromBase64String($profile.key)).Length -ne 64 -or ([Convert]::FromBase64String($profile.cloudKey)).Length -ne 64){throw 'La credencial privada no corresponde al numero seleccionado.'}
    New-Item -ItemType Directory -Path $enrollmentRoot -Force|Out-Null
    Copy-Item -LiteralPath $candidate -Destination $enrollment -Force
    if((Get-FileHash -LiteralPath $candidate).Hash -ne (Get-FileHash -LiteralPath $enrollment).Hash){throw 'No se pudo guardar la credencial seleccionada.'}
}
$selected=Get-Content -LiteralPath $enrollment -Raw|ConvertFrom-Json
if($selected.name -cne $ManagementName -or ([Convert]::FromBase64String($selected.key)).Length -ne 64 -or ([Convert]::FromBase64String($selected.cloudKey)).Length -ne 64){throw 'La credencial guardada no es valida para este equipo.'}
# The temporary OEM bundle is staff-only. Keep only the assigned PC's profile.
if(Test-Path -LiteralPath $stagedProfiles){
    foreach($credential in Get-ChildItem -LiteralPath $stagedProfiles -Filter '*.json' -File){Remove-Item -LiteralPath $credential.FullName -Force}
    if(@(Get-ChildItem -LiteralPath $stagedProfiles -Force).Count -eq 0){Remove-Item -LiteralPath $stagedProfiles -Force}
}
return $enrollment
}
