﻿[CmdletBinding()]
param(
    [ValidateSet('Collect','Retry')][string]$Action='Collect',
    [switch]$LibraryOnly,
    [switch]$NoPause
)
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'

function Get-ReportAllowlist {
    return @('Reports\deployment.json','Reports\staging.json','Reports\veyon-installation.json','Reports\finalization.json','Provisioning\install-settings-report.json','Provisioning\declutter-report.json','Provisioning\protection-report.json','Provisioning\update-report.json','Management\install-result.json')
}
function Get-RetryBlockReason([string]$UserName,[bool]$Administrator,$Uwf) {
    if($UserName -ine 'MAINTENANCE'){return 'Inicie sesion como MAINTENANCE para reintentar la configuracion.'}
    if(-not $Administrator){return 'Se requieren permisos de administrador; los registros se recopilaron sin reintentar.'}
    if(-not $Uwf.Known){return 'No se pudo verificar UWF. Solo se recopilaron registros; revise el error antes de reintentar.'}
    if($Uwf.Pending -or $Uwf.CurrentEnabled -or $Uwf.NextEnabled -or $Uwf.Servicing){return 'UWF esta activo, pendiente o en mantenimiento. Solo se recopilaron registros para evitar cambios temporales o conflictos.'}
    return $null
}
function Set-SupportPrivateDirectory([string]$Path) {
    [IO.Directory]::CreateDirectory($Path)|Out-Null
    $acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetAccessRuleProtection($true,$false)
    foreach($sid in @('S-1-5-18','S-1-5-32-544')){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new([Security.Principal.SecurityIdentifier]::new($sid),'FullControl','ContainerInherit,ObjectInherit','None','Allow'))}
    Set-Acl -LiteralPath $Path -AclObject $acl
}
function Get-SupportUwf {
    $state=[ordered]@{Known=$false;Feature=$null;Pending=$false;CurrentEnabled=$false;NextEnabled=$false;Servicing=$false;Error=$null}
    try {
        $feature=Get-WindowsOptionalFeature -Online -FeatureName Client-UnifiedWriteFilter
        $state.Feature=[string]$feature.State
        $state.Pending=$feature.State -in @('EnablePending','DisablePending')
        if($feature.State -eq 'Enabled'){
            $filter=Get-CimInstance -Namespace 'root\standardcimv2\embedded' -ClassName UWF_Filter
            $state.CurrentEnabled=[bool]$filter.CurrentEnabled;$state.NextEnabled=[bool]$filter.NextEnabled
            $servicing=@(Get-CimInstance -Namespace 'root\standardcimv2\embedded' -ClassName UWF_Servicing)
            $state.Servicing=[bool]@($servicing|Where-Object ServicingEnabled).Count
        }
        $state.Known=$true
    } catch {$state.Error=$_.Exception.Message}
    return [pscustomobject]$state
}
function Copy-SupportReports([string]$DataRoot,[string]$Destination) {
    [IO.Directory]::CreateDirectory($Destination)|Out-Null
    $copied=[Collections.Generic.List[string]]::new()
    foreach($relative in Get-ReportAllowlist){
        $source=Join-Path $DataRoot $relative
        if(-not(Test-Path -LiteralPath $source -PathType Leaf)){continue}
        $file=Get-Item -LiteralPath $source -Force
        if(($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $file.Length -gt 2097152){continue}
        $name=$relative.Replace('\','-')
        Copy-Item -LiteralPath $source -Destination (Join-Path $Destination $name) -Force
        $copied.Add($relative)
    }
    $reportRoot=Join-Path $DataRoot 'Reports'
    if(Test-Path -LiteralPath $reportRoot -PathType Container){
        $logs=@(Get-ChildItem -LiteralPath $reportRoot -Filter 'first-login-*.log' -File|Where-Object {($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0 -and $_.Length -le 2097152}|Sort-Object LastWriteTimeUtc -Descending|Select-Object -First 3)
        foreach($file in $logs){Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $Destination ('Reports-'+$file.Name)) -Force;$copied.Add(('Reports\'+$file.Name))}
    }
    return $copied.ToArray()
}
function Invoke-SupportChild([string]$Script) {
    if(-not(Test-Path -LiteralPath $Script -PathType Leaf)){throw ('No se encontro el configurador: '+$Script)}
    $previous=$ErrorActionPreference
    try {
        $ErrorActionPreference='Continue'
        & (Join-Path $env:windir 'System32\WindowsPowerShell\v1.0\powershell.exe') -NoLogo -NoProfile -ExecutionPolicy Bypass -File $Script 2>&1|ForEach-Object {Write-Host ($_|Out-String)}
        $childExit=$LASTEXITCODE
    } finally {$ErrorActionPreference=$previous}
    Write-Host ('Codigo de salida: '+$childExit)
    if($childExit -ne 0){throw ('El configurador termino con error '+$childExit+'. Consulte Retry.log y Reports-deployment.json.')}
}
function Find-SupportPackage {
    $parent=Split-Path -Parent $PSScriptRoot
    if(Test-Path -LiteralPath (Join-Path $parent 'UEPLV-PACKAGE.marker')){return $parent}
    foreach($drive in Get-PSDrive -PSProvider FileSystem){
        $candidate=Join-Path $drive.Root 'UEPLV-Deployment'
        if(Test-Path -LiteralPath (Join-Path $candidate 'UEPLV-PACKAGE.marker')){return $candidate}
    }
    return $null
}
if($LibraryOnly){return}

$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$administrator=([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if(-not $administrator -and $env:USERNAME -ieq 'MAINTENANCE'){
    try {
        $arguments='-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'" -Action '+$Action
        if($NoPause){$arguments+=' -NoPause'}
        $process=Start-Process -FilePath (Join-Path $env:windir 'System32\WindowsPowerShell\v1.0\powershell.exe') -ArgumentList $arguments -Verb RunAs -WindowStyle Normal -Wait -PassThru
        exit $process.ExitCode
    } catch {Write-Host ('No se aprobaron los permisos de administrador: '+$_.Exception.Message) -ForegroundColor Yellow}
}
$dataRoot=Join-Path $env:ProgramData 'UEPLV'
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
$supportRoot=if($administrator){Join-Path $dataRoot 'Support'}else{Join-Path $env:LOCALAPPDATA 'UEPLV-Support'}
$session=Join-Path $supportRoot ($env:COMPUTERNAME+'-'+$stamp)
$transcribing=$false;$exitCode=0;$archive=$null
$summary=[ordered]@{Utc=[datetime]::UtcNow.ToString('o');Computer=$env:COMPUTERNAME;User=$env:USERNAME;Administrator=$administrator;RequestedAction=$Action;Retried=$false;Success=$false;Error=$null;Uwf=$null;Reports=@();Installer=$null;InstallerSHA256=$null;ScriptStackTrace=$null}
try {
    if($administrator){Set-SupportPrivateDirectory $supportRoot}else{[IO.Directory]::CreateDirectory($supportRoot)|Out-Null}
    [IO.Directory]::CreateDirectory($session)|Out-Null
    Start-Transcript -LiteralPath (Join-Path $session 'Retry.log') -Force|Out-Null;$transcribing=$true
    Write-Host 'UEPLV - Diagnostico y reintento de configuracion' -ForegroundColor Cyan
    Write-Host ('Equipo: '+$env:COMPUTERNAME+' | Usuario: '+$env:USERNAME+' | Administrador: '+$administrator)
    $summary.Reports=@(Copy-SupportReports $dataRoot (Join-Path $session 'Reports'))
    $deployment=Join-Path $dataRoot 'Reports\deployment.json'
    if(Test-Path -LiteralPath $deployment){try{$old=Get-Content -LiteralPath $deployment -Raw|ConvertFrom-Json;if($old.Error){Write-Host ('ERROR ANTERIOR: '+$old.Error) -ForegroundColor Red}}catch{Write-Host ('No se pudo leer el informe anterior: '+$_.Exception.Message)}}
    $details=[ordered]@{OS=$null;Hardware=$null;Services=@();Accounts=@();Tasks=@();Errors=@()}
    try {$os=Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion';$details.OS=$os|Select-Object ProductName,EditionID,DisplayVersion,CurrentBuildNumber,UBR}catch{$details.Errors+=$_.Exception.Message}
    try {$details.Hardware=Get-CimInstance Win32_ComputerSystem|Select-Object Manufacturer,Model,TotalPhysicalMemory}catch{$details.Errors+=$_.Exception.Message}
    foreach($serviceName in @('VeyonService','UEPLVAgent')){try{$service=Get-Service -Name $serviceName -ErrorAction Stop;$details.Services+=($service|Select-Object Name,Status,StartType)}catch{$details.Errors+=('Service '+$serviceName+': '+$_.Exception.Message)}}
    foreach($accountName in @('MAINTENANCE','LEV VIGOTSKY')){try{$account=Get-LocalUser -Name $accountName;$details.Accounts+=($account|Select-Object Name,Enabled,SID)}catch{$details.Errors+=('Account '+$accountName+': '+$_.Exception.Message)}}
    foreach($taskName in @('UEPLV-FinalizeDeployment','UEPLV-AutomaticUpdate')){try{$task=Get-ScheduledTask -TaskName $taskName;$info=Get-ScheduledTaskInfo -TaskName $taskName;$details.Tasks+=[pscustomobject]@{Name=$taskName;State=[string]$task.State;LastRunTime=$info.LastRunTime;LastTaskResult=$info.LastTaskResult}}catch{$details.Errors+=('Task '+$taskName+': '+$_.Exception.Message)}}
    $details|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $session 'System.json') -Encoding UTF8
    $summary.Uwf=Get-SupportUwf
    if($Action -eq 'Retry'){
        $blocked=Get-RetryBlockReason $env:USERNAME $administrator $summary.Uwf
        if($blocked){throw $blocked}
        if(-not [Environment]::Is64BitProcess){throw 'Use Windows PowerShell de 64 bits para reintentar.'}
        $installer=Join-Path $dataRoot 'Deployment\Install-Lab.ps1'
        $online=Join-Path $dataRoot 'Bootstrap\Start-OnlineSetup.ps1'
        if(Test-Path -LiteralPath $online){$installer=$online}
        if(-not(Test-Path -LiteralPath $installer)){
            $package=Find-SupportPackage
            if(-not $package){throw 'Conecte el USB con UEPLV-Deployment. No se encontro el paquete ni la copia local.'}
            Write-Host 'La copia local no existe. Preparando la copia protegida desde el USB...'
            Invoke-SupportChild (Join-Path $package 'Stage-UEPLV.ps1')
        }
        $summary.Installer=$installer;$summary.InstallerSHA256=(Get-FileHash -LiteralPath $installer).Hash
        $summary.Retried=$true
        Write-Host 'Reintentando la configuracion inicial.' -ForegroundColor Yellow
        Invoke-SupportChild $installer
    }
    $summary.Success=$true
} catch {
    $exitCode=1;$summary.Error=$_.Exception.Message;$summary.ScriptStackTrace=$_.ScriptStackTrace
    Write-Host 'ERROR CAPTURADO:' -ForegroundColor Red
    Write-Host ($_|Format-List * -Force|Out-String) -ForegroundColor Red
    Write-Host $_.ScriptStackTrace
} finally {
    if(Test-Path -LiteralPath $session){
        try{$summary.Reports=@(Copy-SupportReports $dataRoot (Join-Path $session 'Reports'))}catch{Write-Host ('No se pudieron copiar algunos informes: '+$_.Exception.Message)}
        $summary|ConvertTo-Json -Depth 10|Set-Content -LiteralPath (Join-Path $session 'Summary.json') -Encoding UTF8
    }
    if($transcribing){Stop-Transcript|Out-Null}
    if(Test-Path -LiteralPath $session){
        try {
            $desktop=[Environment]::GetFolderPath('Desktop')
            if(-not $desktop){$desktop=$env:USERPROFILE}
            [IO.Directory]::CreateDirectory($desktop)|Out-Null
            $archive=Join-Path $desktop ('UEPLV-Diagnostics-'+$env:COMPUTERNAME+'-'+$stamp+'.zip')
            Compress-Archive -LiteralPath $session -DestinationPath $archive -CompressionLevel Optimal -Force
            Write-Host ('ARCHIVO PARA ENVIAR: '+$archive) -ForegroundColor Green
        } catch {Write-Host ('No se creo el ZIP. Los registros estan en: '+$session) -ForegroundColor Yellow;Write-Host $_.Exception.Message}
    }
}
Write-Host 'No se incluyen contrasenas, claves de registro ni archivos de credenciales.'
if(-not $NoPause){[void](Read-Host 'Presione Enter para cerrar esta ventana')}
exit $exitCode
