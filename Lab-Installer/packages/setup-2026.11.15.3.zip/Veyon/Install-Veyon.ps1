﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [string]$InstallerPath,
    [string]$PublicKeyPath,
    [string]$ConfigurationPath,
    [string]$ReportPath = 'C:\ProgramData\UEPLV\Reports\veyon-installation.json'
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if(-not $InstallerPath){$InstallerPath=Join-Path $PSScriptRoot 'Payload\veyon-4.11.4.0-win64-setup.exe'}
if(-not $PublicKeyPath){$PublicKeyPath=Join-Path $PSScriptRoot 'Payload\Admin_public_key.pem'}
if(-not $ConfigurationPath){$ConfigurationPath=Join-Path $PSScriptRoot 'Student-Veyon.json'}
$report = [ordered]@{
    SchemaVersion=1; Component='Veyon'; ComputerName=$env:COMPUTERNAME
    CheckedAtUtc=[DateTime]::UtcNow.ToString('o'); Passed=$false
    PublicKeyVerified=$false; ConfigurationVerified=$false
    PrivateKeyAbsent=$false; ServiceRunning=$false
    Authentication='Admin public-key only'; Version=$null; Error=$null
}
$expectedPublicHash = '89422856AD778E627B9AB457279007D861A5E52DE216739442737131914F2476'
function Invoke-VeyonCli {
    param([string[]]$Arguments)
    $previousPreference=$ErrorActionPreference
    try { $ErrorActionPreference='Continue'; $output = & $script:cli @Arguments 2>&1; $code=$LASTEXITCODE } finally { $ErrorActionPreference=$previousPreference }
    if ($code -ne 0) { throw ('Veyon CLI failed: ' + ($Arguments -join ' ') + ' (exit ' + $code + '). ' + ($output -join ' ')) }
    return $output
}
function Set-LabPublicKeyPermissions([string]$Path) {
 if(-not(Test-Path -LiteralPath $Path -PathType Leaf)){return}
 $acl=[Security.AccessControl.FileSecurity]::new();$acl.SetAccessRuleProtection($true,$false)
 foreach($sid in @('S-1-5-18','S-1-5-32-544')){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new([Security.Principal.SecurityIdentifier]::new($sid),'FullControl','Allow'))}
 $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new([Security.Principal.SecurityIdentifier]::new('S-1-5-32-545'),'ReadAndExecute','Allow'))
 Set-Acl -LiteralPath $Path -AclObject $acl
}
try {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    if (-not (New-Object Security.Principal.WindowsPrincipal($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Run this installer as administrator or SYSTEM.'
    }
    if (-not [Environment]::Is64BitProcess) { throw 'Use 64-bit Windows PowerShell for this package.' }
    foreach ($inputFile in @($InstallerPath,$PublicKeyPath,$ConfigurationPath)) {
        if (-not (Test-Path -LiteralPath $inputFile -PathType Leaf)) { throw ('Missing package input: ' + $inputFile) }
    }
    $signature = Get-AuthenticodeSignature -LiteralPath $InstallerPath
    if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'O=Veyon Solutions(?:,|$)') {
        throw 'The Veyon installer signature is not valid for Veyon Solutions.'
    }
    if ((Get-FileHash -LiteralPath $PublicKeyPath -Algorithm SHA256).Hash -ne $expectedPublicHash) {
        throw 'The supplied public key does not match the approved teacher Admin public key.'
    }
    $config = Get-Content -LiteralPath $ConfigurationPath -Raw | ConvertFrom-Json
    if ($config.Authentication.Method -ne 1) { throw 'The package must use key-file authentication.' }
    $reportFolder = Split-Path -Parent $ReportPath
    New-Item -ItemType Directory -Path $reportFolder -Force | Out-Null
    $cli = Join-Path $env:ProgramFiles 'Veyon\veyon-cli.exe'
    if (Test-Path -LiteralPath $cli) {
        $backupDir = Join-Path $env:ProgramData ('UEPLV\Backups\Veyon\' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
        Invoke-VeyonCli -Arguments @('config','export',(Join-Path $backupDir 'previous-config.json')) | Out-Null
    }
    $absoluteConfig = (Resolve-Path -LiteralPath $ConfigurationPath).Path
    $process = Start-Process -FilePath $InstallerPath -ArgumentList @('/S','/NoMaster','/NoStartMenuFolder',('/ApplyConfig="' + $absoluteConfig + '"')) -WindowStyle Hidden -Wait -PassThru
    if ($process.ExitCode -notin @(0,3010)) { throw ('Veyon installer exited with ' + $process.ExitCode) }
    if (-not (Test-Path -LiteralPath $cli)) { throw 'Veyon CLI is missing after installation.' }
    Invoke-VeyonCli -Arguments @('config','import',$absoluteConfig) | Out-Null
    # Do not distribute or silently retain a teacher private key on a student PC.
    $privateRoot = Join-Path $env:ProgramData 'Veyon\keys\private'
    $privateKeys = @(Get-ChildItem -LiteralPath $privateRoot -Recurse -File -Force -ErrorAction SilentlyContinue)
    if ($privateKeys.Count -gt 0) { throw 'A private Veyon key is present on this student PC. Remove it through the staff recovery process before continuing.' }
    $report.PrivateKeyAbsent = $true
    $publicRoot = Join-Path $env:ProgramData 'Veyon\keys\public'
    $otherKeys = @(Get-ChildItem -LiteralPath $publicRoot -Directory -Force -ErrorAction SilentlyContinue | Where-Object Name -ne 'Admin')
    if ($otherKeys.Count -gt 0) { throw 'Unexpected additional public Veyon keys exist. Review the machine before continuing.' }
    Set-LabPublicKeyPermissions (Join-Path $publicRoot 'Admin\key')
    $existingKey=Join-Path $publicRoot 'Admin\key'
    if(Test-Path -LiteralPath $existingKey -PathType Leaf){
        if((Get-FileHash -LiteralPath $existingKey -Algorithm SHA256).Hash -ne $expectedPublicHash){throw 'Existing Admin public key does not match the approved key.'}
    }else{
        Invoke-VeyonCli -Arguments @('authkeys','import','Admin/public',(Resolve-Path -LiteralPath $PublicKeyPath).Path) | Out-Null
    }
    $installedKey = Join-Path $publicRoot 'Admin\key'
    if (-not (Test-Path -LiteralPath $installedKey)) { throw 'Veyon did not create the expected Admin public key.' }
    # Public material may be read by Veyon user-session workers; only staff/SYSTEM may change it.
    & icacls.exe $publicRoot /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-32-545:(OI)(CI)RX' /T /C /Q | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Could not protect the public-key directory permissions.' }
    Set-LabPublicKeyPermissions $installedKey
    $report.PublicKeyVerified = ((Get-FileHash -LiteralPath $installedKey -Algorithm SHA256).Hash -eq $expectedPublicHash)
    $auth = Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Veyon Solutions\Veyon\Authentication'
    $report.ConfigurationVerified = ($auth.Method -eq 1)
    if (-not $report.PublicKeyVerified -or -not $report.ConfigurationVerified) { throw 'Veyon key/configuration read-back failed.' }
    # Replace the installer's application-wide exceptions with explicit lab-subnet rules.
    $veyonDir = [IO.Path]::GetFullPath((Join-Path $env:ProgramFiles 'Veyon'))
    foreach ($rule in @(Get-NetFirewallRule -ErrorAction Stop | Where-Object { $_.DisplayName -like 'Veyon*' })) {
        $filters = @($rule | Get-NetFirewallApplicationFilter)
        if (@($filters | Where-Object { $_.Program -and $_.Program.StartsWith($veyonDir + '\',[StringComparison]::OrdinalIgnoreCase) }).Count -gt 0) {
            $rule | Disable-NetFirewallRule | Out-Null
        }
    }
    foreach ($port in @(11100,11400)) {
        $ruleName = 'UEPLV-Veyon-TCP-' + $port
        Get-NetFirewallRule -Name $ruleName -ErrorAction SilentlyContinue | Remove-NetFirewallRule
        New-NetFirewallRule -Name $ruleName -DisplayName ('UEPLV Veyon lab TCP ' + $port) -Direction Inbound -Action Allow -Protocol TCP -LocalPort $port -RemoteAddress LocalSubnet -Profile Any | Out-Null
    }
    Set-Service -Name VeyonService -StartupType Automatic
    Restart-Service -Name VeyonService -Force
    (Get-Service -Name VeyonService).WaitForStatus('Running',[TimeSpan]::FromSeconds(30))
    $service = Get-Service -Name VeyonService
    $report.ServiceRunning = ($service.Status -eq 'Running' -and $service.StartType -eq 'Automatic')
    $report.Version = (Get-Item -LiteralPath $cli).VersionInfo.ProductVersion
    $report.Passed = ($report.PublicKeyVerified -and $report.ConfigurationVerified -and $report.PrivateKeyAbsent -and $report.ServiceRunning)
    if (-not $report.Passed) { throw 'Veyon installation verification failed.' }
} catch {
    $report.Error = $_.Exception.Message
} finally {
    $report.CheckedAtUtc = [DateTime]::UtcNow.ToString('o')
    $parent = Split-Path -Parent $ReportPath
    if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    $report | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $ReportPath -Encoding UTF8
}
if (-not $report.Passed) { Write-Error $report.Error; exit 1 }
Write-Output ('Veyon verified for ' + $env:COMPUTERNAME + '. Report: ' + $ReportPath)
exit 0


