#requires -Version 5.1
# Reads installed state only and refreshes its result after the renamed boot.
[CmdletBinding()]
param([string]$ReportPath='C:\ProgramData\UEPLV\Reports\veyon-installation.json')
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$report=[ordered]@{
    SchemaVersion=1;Component='Veyon';ComputerName=$env:COMPUTERNAME
    CheckedAtUtc=[DateTime]::UtcNow.ToString('o');Passed=$false
    PublicKeyVerified=$false;ConfigurationVerified=$false;PrivateKeyAbsent=$false
    ServiceRunning=$false;Authentication='Admin public-key only';Version=$null;Error=$null
}
try {
    $cli=Join-Path $env:ProgramFiles 'Veyon\veyon-cli.exe'
    if(-not(Test-Path -LiteralPath $cli -PathType Leaf)){throw 'Installed Veyon CLI is missing.'}
    $auth=Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Veyon Solutions\Veyon\Authentication'
    # Resolve configured public/private directories as Veyon does for GLOBALAPPDATA.
    $publicRoot=Join-Path $env:ProgramData 'Veyon\keys\public'
    $privateRoot=Join-Path $env:ProgramData 'Veyon\keys\private'
    if($auth.PSObject.Properties['PublicKeyBaseDir'] -and $auth.PublicKeyBaseDir){
        $publicRoot=[Environment]::ExpandEnvironmentVariables(([string]$auth.PublicKeyBaseDir).Replace('%GLOBALAPPDATA%',(Join-Path $env:ProgramData 'Veyon')))
    }
    if($auth.PSObject.Properties['PrivateKeyBaseDir'] -and $auth.PrivateKeyBaseDir){
        $privateRoot=[Environment]::ExpandEnvironmentVariables(([string]$auth.PrivateKeyBaseDir).Replace('%GLOBALAPPDATA%',(Join-Path $env:ProgramData 'Veyon')))
    }
    $key=Join-Path $publicRoot 'Admin\key'
    $report.PublicKeyVerified=(Test-Path -LiteralPath $key -PathType Leaf) -and ((Get-FileHash -LiteralPath $key -Algorithm SHA256).Hash -eq '89422856AD778E627B9AB457279007D861A5E52DE216739442737131914F2476')
    $otherKeys=@(Get-ChildItem -LiteralPath $publicRoot -Directory -Force -ErrorAction Stop|Where-Object Name -ne 'Admin')
    $report.ConfigurationVerified=($auth.Method -eq 1 -and $otherKeys.Count -eq 0)
    if(Test-Path -LiteralPath $privateRoot){
        $privateFiles=@(Get-ChildItem -LiteralPath $privateRoot -Recurse -File -Force -ErrorAction Stop)
        $report.PrivateKeyAbsent=($privateFiles.Count -eq 0)
    } else {$report.PrivateKeyAbsent=$true}
    $service=Get-Service -Name VeyonService -ErrorAction Stop
    $report.ServiceRunning=($service.Status -eq 'Running' -and $service.StartType -eq 'Automatic')
    $report.Version=(Get-Item -LiteralPath $cli).VersionInfo.ProductVersion
    $report.Passed=($report.PublicKeyVerified -and $report.ConfigurationVerified -and $report.PrivateKeyAbsent -and $report.ServiceRunning)
    if(-not $report.Passed){throw 'Installed Veyon configuration, public key, absence of private keys, or service verification failed.'}
} catch {$report.Error=$_.Exception.Message}
finally {
    $report.CheckedAtUtc=[DateTime]::UtcNow.ToString('o')
    $folder=Split-Path -Parent $ReportPath
    if(-not(Test-Path -LiteralPath $folder)){New-Item -ItemType Directory -Path $folder -Force|Out-Null}
    $report|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $ReportPath -Encoding UTF8
}
if(-not $report.Passed){Write-Error $report.Error;exit 1}
Write-Output ('Installed Veyon verified for '+$env:COMPUTERNAME)
exit 0

