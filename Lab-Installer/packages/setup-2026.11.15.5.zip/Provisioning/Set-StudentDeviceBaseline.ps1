﻿#requires -Version 5.1
[CmdletBinding()]
param([ValidateSet('class','class-ai','exam','free')][string]$Mode='class',[switch]$LibraryOnly)
$ErrorActionPreference='Stop'
$script:BaselineVersion='1.5.2'
$script:BaselineDefinitionHash=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash
function Set-BaselineValue([string]$Path,[string]$Name,$Value,[string]$Type='DWord'){
 if(-not $Path.StartsWith('HKLM:\',[StringComparison]::OrdinalIgnoreCase)){throw 'Unexpected machine-policy path.'}
 $key=[Microsoft.Win32.Registry]::LocalMachine.CreateSubKey($Path.Substring(6))
 try{$key.SetValue($Name,$Value,[Microsoft.Win32.RegistryValueKind]::$Type)}finally{$key.Close()}
}
function Get-BaselinePowerSettings {
 @(
  @{Group='7516b95f-f776-4464-8c53-06167f40cc99';Setting='3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e';Name='Display'},
  @{Group='7516b95f-f776-4464-8c53-06167f40cc99';Setting='8ec4b3a5-6868-48c2-be75-4f3044be88a7';Name='Locked display'},
  @{Group='238c9fa8-0aad-41ed-83f4-97be242c8f20';Setting='29f6c1db-86da-48c5-9fdb-f2b67b1f44da';Name='Sleep'},
  @{Group='238c9fa8-0aad-41ed-83f4-97be242c8f20';Setting='9d7815a6-7ee4-497e-8888-515a05f02364';Name='Hibernate'},
  @{Group='238c9fa8-0aad-41ed-83f4-97be242c8f20';Setting='7bc4a2f9-d8fc-4469-b07b-33eb785aaca0';Name='Unattended sleep'},
  @{Group='238c9fa8-0aad-41ed-83f4-97be242c8f20';Setting='94ac6d29-73ce-41a6-809f-6363ba21b47e';Name='Hybrid sleep'},
  @{Group='4f971e89-eebd-4455-a8de-9e59040e7347';Setting='5ca83367-6e45-459f-a27b-476b1d01c936';Name='Lid close'},
  @{Group='4f971e89-eebd-4455-a8de-9e59040e7347';Setting='96996bc0-ad50-47ec-923b-6f41874dd9eb';Name='Sleep button'},
  @{Group='4f971e89-eebd-4455-a8de-9e59040e7347';Setting='7648efa3-dd9c-4e3e-b566-50f929386280';Name='Power button'}
 )
}
function Set-LabAlwaysOn {
 $power=Join-Path $env:SystemRoot 'System32\powercfg.exe'
 $active=(Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes').ActivePowerScheme
 if($active -notmatch '^[a-fA-F0-9-]{36}$'){throw 'No se pudo leer el plan de energia activo.'}
 $changed=$false
 foreach($item in Get-BaselinePowerSettings){
  $policy='HKLM:\SOFTWARE\Policies\Microsoft\Power\PowerSettings\'+$item.Setting
  $scheme='HKLM:\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes\'+$active+'\'+$item.Group+'\'+$item.Setting
  $values=Get-ItemProperty $scheme -ErrorAction SilentlyContinue
  foreach($kind in @('AC','DC')){
   if(-not $values -or $values.($kind+'SettingIndex') -ne 0){
    & $power ('/set'+$kind.ToLowerInvariant()+'valueindex') $active $item.Group $item.Setting 0|Out-Null
    if($LASTEXITCODE -ne 0){throw ('No se pudo configurar energia: '+$item.Name+' '+$kind)};$changed=$true
   }
   Set-BaselineValue $policy ($kind+'SettingIndex') 0
  }
 }
 Set-BaselineValue 'HKLM:\SOFTWARE\Policies\Microsoft\Power\PowerSettings' ActivePowerScheme $active String
 Set-BaselineValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FlyoutMenuSettings' ShowSleepOption 0
 Set-BaselineValue 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FlyoutMenuSettings' ShowHibernateOption 0
 if((Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' -ErrorAction SilentlyContinue).HibernateEnabled -ne 0){& $power /hibernate off|Out-Null;if($LASTEXITCODE){throw 'No se pudo desactivar hibernacion.'};$changed=$true}
 if($changed){& $power /setactive $active|Out-Null;if($LASTEXITCODE){throw 'No se pudo activar el plan de energia.'}}
 return $active
}
function Get-BaselineRuleId([string]$Text){$sha=[Security.Cryptography.SHA256]::Create();try{$bytes=$sha.ComputeHash([Text.Encoding]::UTF8.GetBytes('UEPLV-baseline-v1:'+ $Text));$first=New-Object byte[] 16;[Array]::Copy($bytes,$first,16);([guid]::new($first)).ToString()}finally{$sha.Dispose()}}
function Add-BaselinePathRule($Document,$Collection,[string]$Sid,[string]$Name,[string]$Action,[string]$Path,[string[]]$Exceptions=@()){
 $rule=$Document.CreateElement('FilePathRule');foreach($pair in @{Id=(Get-BaselineRuleId ($Collection.Type+':'+$Sid+':'+$Name));Name=('UEPLV '+$Name);Description='UEPLV student baseline v1';UserOrGroupSid=$Sid;Action=$Action}.GetEnumerator()){$rule.SetAttribute($pair.Key,$pair.Value)}
 $conditions=$Document.CreateElement('Conditions');$condition=$Document.CreateElement('FilePathCondition');$condition.SetAttribute('Path',$Path);[void]$conditions.AppendChild($condition);[void]$rule.AppendChild($conditions)
 if($Exceptions.Count){$except=$Document.CreateElement('Exceptions');foreach($path in $Exceptions){$node=$Document.CreateElement('FilePathCondition');$node.SetAttribute('Path',$path);[void]$except.AppendChild($node)};[void]$rule.AppendChild($except)}
 [void]$Collection.AppendChild($rule)
}
function Add-BaselinePublisherRule($Document,$Collection,[string]$Sid,[string]$Name,[string]$Publisher,[string]$Product){
 $rule=$Document.CreateElement('FilePublisherRule');foreach($pair in @{Id=(Get-BaselineRuleId ($Collection.Type+':'+$Sid+':'+$Name));Name=('UEPLV '+$Name);Description='UEPLV student baseline v1';UserOrGroupSid=$Sid;Action='Allow'}.GetEnumerator()){$rule.SetAttribute($pair.Key,$pair.Value)}
 $conditions=$Document.CreateElement('Conditions');$condition=$Document.CreateElement('FilePublisherCondition');$condition.SetAttribute('PublisherName',$Publisher);$condition.SetAttribute('ProductName',$Product);$condition.SetAttribute('BinaryName','*');$versions=$Document.CreateElement('BinaryVersionRange');$versions.SetAttribute('LowSection','0.0.0.0');$versions.SetAttribute('HighSection','*');[void]$condition.AppendChild($versions);[void]$conditions.AppendChild($condition);[void]$rule.AppendChild($conditions);[void]$Collection.AppendChild($rule)
}
function New-LabApplicationPolicy([string]$StudentSid,[bool]$Free,$Packages){
 if($StudentSid -notmatch '^S-1-5-21-\d+-\d+-\d+-\d+$'){throw 'SID de estudiante invalido.'}
 [xml]$doc='<AppLockerPolicy Version="1" />'
 $privileged=@('S-1-5-32-544','S-1-5-18','S-1-5-19','S-1-5-20')
 foreach($type in @('Exe','Msi','Script','Appx')){
  $collection=$doc.CreateElement('RuleCollection');$collection.SetAttribute('Type',$type);$collection.SetAttribute('EnforcementMode','Enabled');[void]$doc.DocumentElement.AppendChild($collection)
  foreach($sid in $privileged){if($type -eq 'Appx'){Add-BaselinePublisherRule $doc $collection $sid ('staff-'+$sid) '*' '*'}else{Add-BaselinePathRule $doc $collection $sid ('staff-'+$sid) Allow '*'}}
  if($type -eq 'Exe'){
   $trusted=@('%WINDIR%\*','%PROGRAMFILES%\*')
   Add-BaselinePathRule $doc $collection 'S-1-1-0' 'trusted Windows and staff-installed programs' Allow '%WINDIR%\*'
   Add-BaselinePathRule $doc $collection 'S-1-1-0' 'staff-installed programs' Allow '%PROGRAMFILES%\*'
   Add-BaselinePathRule $doc $collection $StudentSid 'no downloaded portable or USB programs' Deny '*' $trusted
   foreach($path in @('%WINDIR%\Temp\*','%WINDIR%\Tasks\*','%WINDIR%\Tracing\*','%WINDIR%\Registration\CRMLog\*','%WINDIR%\System32\spool\*','%WINDIR%\System32\Com\dmp\*','%WINDIR%\SysWOW64\Com\dmp\*','%WINDIR%\System32\FxsTmp\*','%WINDIR%\System32\Tasks\*')){Add-BaselinePathRule $doc $collection $StudentSid ('writable '+$path) Deny $path}
   foreach($binary in @('msiexec.exe','cmd.exe','regedit.exe','reg.exe','wscript.exe','cscript.exe','mshta.exe','rundll32.exe','regsvr32.exe','installutil.exe','msbuild.exe','iexpress.exe','powercfg.exe')){
    Add-BaselinePathRule $doc $collection $StudentSid ('restricted host '+$binary) Deny ('%WINDIR%\*\'+$binary)
   }
   Add-BaselinePathRule $doc $collection $StudentSid 'registry editor' Deny '%WINDIR%\regedit.exe'
   foreach($package in @('Microsoft.DesktopAppInstaller','Microsoft.WindowsStore')){Add-BaselinePathRule $doc $collection $StudentSid ('no '+$package+' executables') Deny ('%PROGRAMFILES%\WindowsApps\'+$package+'*\*')}
   if(-not $Free){foreach($path in @('%WINDIR%\System32\Taskmgr.exe','%WINDIR%\SysWOW64\Taskmgr.exe')){Add-BaselinePathRule $doc $collection $StudentSid ('Task Manager '+$path) Deny $path}}
  }elseif($type -eq 'Msi'){Add-BaselinePathRule $doc $collection $StudentSid 'no student MSI MSP or MST installation' Deny '*'}
  elseif($type -eq 'Script'){
   $helper='%PROGRAMFILES%\UEPLV\Provisioning\Apply-UserSettings.ps1'
   Add-BaselinePathRule $doc $collection $StudentSid 'trusted school appearance helper' Allow $helper
   Add-BaselinePathRule $doc $collection $StudentSid 'no student scripts' Deny '*' @($helper)
  }else{
   foreach($package in @($Packages|Sort-Object Name -Unique)){
    if($package.Name -notmatch '^(Microsoft\.|MicrosoftWindows\.|Windows\.)' -or $package.Name -match '(?i)WindowsStore|StorePurchaseApp|DesktopAppInstaller|Xbox|Gaming|Minecraft|Solitaire|Copilot|MicrosoftOfficeHub'){continue}
    Add-BaselinePublisherRule $doc $collection 'S-1-1-0' ('Windows package '+$package.Name) $package.Publisher $package.Name
   }
  }
 }
 return $doc
}
function Invoke-LabStudentBaseline([string]$SelectedMode){
 $student=Get-LocalUser -Name 'LEV VIGOTSKY' -ErrorAction Stop
 if(@(Get-LocalGroupMember -SID 'S-1-5-32-544'|Where-Object {$_.SID.Value -eq $student.SID.Value}).Count){throw 'La cuenta de estudiante no puede ser administradora.'}
 $root=Join-Path $env:ProgramData 'UEPLV\Management\Security';[IO.Directory]::CreateDirectory($root)|Out-Null
 Import-Module AppLocker -ErrorAction Stop
 $policyPath=Join-Path $root 'student-policy.xml';$stampPath=Join-Path $root 'baseline.json';$stamp=$null
 if(Test-Path $stampPath){try{$stamp=Get-Content $stampPath -Raw|ConvertFrom-Json}catch{}}
 $free=$SelectedMode -eq 'free'
 $plan=Set-LabAlwaysOn
 Set-BaselineValue 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer' AlwaysInstallElevated 0
 $policy=(Get-AppLockerPolicy -Local -Xml)
 if(-not $stamp -or $stamp.Version -ne $script:BaselineVersion -or $stamp.DefinitionHash -ne $script:BaselineDefinitionHash -or $stamp.StudentSid -ne $student.SID.Value -or [bool]$stamp.Free -ne $free -or $stamp.PolicySHA256 -ne (Get-BaselineTextHash $policy)){
  if(-not(Test-Path (Join-Path $root 'before-policy.xml'))){[IO.File]::WriteAllText((Join-Path $root 'before-policy.xml'),$policy,[Text.UTF8Encoding]::new($false))}
  [xml]$old=$policy
  $foreign=@($old.AppLockerPolicy.RuleCollection.ChildNodes|Where-Object {$_.NodeType -eq 'Element' -and $_.Description -ne 'UEPLV student baseline v1'})
  if($foreign.Count){throw 'Existe otra directiva AppLocker. Revise la directiva local antes de reemplazarla.'}
  $doc=New-LabApplicationPolicy $student.SID.Value $free @(Get-AppxPackage -AllUsers)
  $doc.Save($policyPath)
  $checks=@((Join-Path $env:SystemRoot 'explorer.exe'),(Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'))|Where-Object {Test-Path $_}
  $evaluated=@(Test-AppLockerPolicy -XmlPolicy $policyPath -Path $checks -User $student.SID.Value)
  if(@($evaluated|Where-Object PolicyDecision -ne 'Allowed').Count){throw 'La directiva bloquearia el escritorio o Edge.'}
  Set-AppLockerPolicy -XmlPolicy $policyPath -ErrorAction Stop
  & sc.exe config appidsvc start= auto|Out-Null;if($LASTEXITCODE){throw 'No se pudo activar Application Identity.'}
  Start-Service AppIDSvc -ErrorAction Stop
  if((Get-Service AppIDSvc).Status -ne 'Running'){throw 'AppLocker no esta ejecutandose.'}
  $stamp=[ordered]@{Version=$script:BaselineVersion;DefinitionHash=$script:BaselineDefinitionHash;StudentSid=$student.SID.Value;Free=$free;PolicySHA256=(Get-BaselineTextHash (Get-AppLockerPolicy -Local -Xml));PowerPlan=$plan;Utc=[datetime]::UtcNow.ToString('o');StudentInstallationsBlocked=$true;MaintenanceUnrestricted=$true}
  $stamp|ConvertTo-Json|Set-Content $stampPath -Encoding UTF8
 }
 return $stamp
}
function Get-BaselineTextHash([string]$Text){$sha=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text)))).Replace('-','')}finally{$sha.Dispose()}}
function Protect-StudentTaskPolicy([string]$Path,[string]$StudentSid){
 $acl=[Security.AccessControl.RegistrySecurity]::new();$acl.SetAccessRuleProtection($true,$false);$acl.SetOwner([Security.Principal.SecurityIdentifier]::new('S-1-5-32-544'))
 foreach($sid in @('S-1-5-18','S-1-5-32-544')){$acl.AddAccessRule([Security.AccessControl.RegistryAccessRule]::new([Security.Principal.SecurityIdentifier]::new($sid),'FullControl','ContainerInherit','None','Allow'))}
 $acl.AddAccessRule([Security.AccessControl.RegistryAccessRule]::new([Security.Principal.SecurityIdentifier]::new($StudentSid),'ReadKey','ContainerInherit','None','Allow'))
 Set-Acl -LiteralPath $Path -AclObject $acl
}
if($LibraryOnly){return}
$principal=[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Se requieren permisos de MAINTENANCE o SYSTEM.'}
Invoke-LabStudentBaseline $Mode|ConvertTo-Json -Depth 4
